import streamlit as st
import plotly.graph_objects as go
from datetime import datetime, timedelta
import time
import random
import math

# Configure page
st.set_page_config(
    page_title="AllServ - Real-Time Service Platform",
    page_icon="🚗",
    layout="wide"
)

# Initialize session state
if 'current_service' not in st.session_state:
    st.session_state.current_service = None
if 'booking_stage' not in st.session_state:
    st.session_state.booking_stage = 'service_selection'
if 'user_location' not in st.session_state:
    st.session_state.user_location = {'lat': 40.4406, 'lng': -79.9959}
if 'booking_details' not in st.session_state:
    st.session_state.booking_details = {}
if 'tracking_active' not in st.session_state:
    st.session_state.tracking_active = False
if 'provider_location' not in st.session_state:
    st.session_state.provider_location = None
if 'notifications' not in st.session_state:
    st.session_state.notifications = []
if 'last_update_time' not in st.session_state:
    st.session_state.last_update_time = datetime.now()

# Real-time notification system
def add_notification(message, notification_type="info", show_time=True):
    """Add a real-time notification"""
    timestamp = datetime.now()
    notification = {
        'message': message,
        'type': notification_type,
        'timestamp': timestamp,
        'id': f"notif_{int(timestamp.timestamp())}"
    }
    st.session_state.notifications.append(notification)
    # Keep only last 10 notifications
    if len(st.session_state.notifications) > 10:
        st.session_state.notifications.pop(0)

def show_notifications():
    """Display real-time notifications"""
    if st.session_state.notifications:
        st.markdown("### 🔔 Live Notifications")
        for notif in reversed(st.session_state.notifications[-5:]):  # Show last 5
            time_str = notif['timestamp'].strftime("%I:%M:%S %p")
            if notif['type'] == 'success':
                st.success(f"✅ {notif['message']} - {time_str}")
            elif notif['type'] == 'warning':
                st.warning(f"⚠️ {notif['message']} - {time_str}")
            elif notif['type'] == 'error':
                st.error(f"❌ {notif['message']} - {time_str}")
            else:
                st.info(f"ℹ️ {notif['message']} - {time_str}")

def simulate_provider_movement():
    """Simulate real-time provider movement with notifications"""
    if not st.session_state.tracking_active or not st.session_state.provider_location:
        return
    
    provider_loc = st.session_state.provider_location
    user_loc = st.session_state.user_location
    
    # Calculate progress based on time elapsed
    elapsed_time = (datetime.now() - provider_loc['start_time']).seconds
    progress_rate = 0.008  # Adjust movement speed
    
    old_progress = provider_loc.get('progress', 0)
    new_progress = min(1.0, old_progress + progress_rate)
    
    # Update location with movement toward user
    start_lat, start_lng = provider_loc['start_lat'], provider_loc['start_lng']
    end_lat, end_lng = user_loc['lat'], user_loc['lng']
    
    # Linear interpolation with slight randomness
    current_lat = start_lat + (end_lat - start_lat) * new_progress
    current_lng = start_lng + (end_lng - start_lng) * new_progress
    current_lat += random.uniform(-0.0003, 0.0003)
    current_lng += random.uniform(-0.0003, 0.0003)
    
    provider_loc.update({
        'lat': current_lat,
        'lng': current_lng,
        'progress': new_progress
    })
    
    # Calculate ETA
    distance = calculate_distance(current_lat, current_lng, end_lat, end_lng)
    eta_minutes = max(1, int(distance * 30))  # Rough ETA calculation
    provider_loc['eta'] = eta_minutes
    
    # Status updates with notifications
    if new_progress >= 0.9 and provider_loc.get('status') != 'arriving':
        provider_loc['status'] = 'arriving'
        add_notification("Your provider is arriving soon!", "success")
    elif new_progress >= 0.99 and provider_loc.get('status') != 'arrived':
        provider_loc['status'] = 'arrived'
        add_notification("Your provider has arrived!", "success")
        st.session_state.tracking_active = False
    elif new_progress >= 0.5 and provider_loc.get('status') == 'en_route':
        provider_loc['status'] = 'halfway'
        add_notification("Your provider is halfway to you", "info")

def calculate_distance(lat1, lng1, lat2, lng2):
    """Calculate distance between coordinates in miles"""
    R = 3959
    dlat = math.radians(lat2 - lat1)
    dlng = math.radians(lng2 - lng1)
    a = (math.sin(dlat / 2) * math.sin(dlat / 2) +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
         math.sin(dlng / 2) * math.sin(dlng / 2))
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c

def create_live_map():
    """Create live tracking map"""
    fig = go.Figure()
    
    # Add user location
    fig.add_trace(go.Scattermapbox(
        lat=[st.session_state.user_location['lat']],
        lon=[st.session_state.user_location['lng']],
        mode='markers',
        marker=dict(size=15, color='blue'),
        text=['Your Location'],
        name="You"
    ))
    
    # Add provider if tracking
    if st.session_state.tracking_active and st.session_state.provider_location:
        provider = st.session_state.provider_location
        fig.add_trace(go.Scattermapbox(
            lat=[provider['lat']],
            lon=[provider['lng']],
            mode='markers',
            marker=dict(size=18, color='green'),
            text=[f"Provider - ETA: {provider.get('eta', 'N/A')} min"],
            name="Provider"
        ))
        
        # Add route line
        fig.add_trace(go.Scattermapbox(
            lat=[provider['lat'], st.session_state.user_location['lat']],
            lon=[provider['lng'], st.session_state.user_location['lng']],
            mode='lines',
            line=dict(width=3, color='red'),
            showlegend=False
        ))
    
    fig.update_layout(
        mapbox=dict(
            style="open-street-map",
            center=dict(
                lat=st.session_state.user_location['lat'],
                lon=st.session_state.user_location['lng']
            ),
            zoom=13
        ),
        height=400,
        margin=dict(l=0, r=0, t=0, b=0)
    )
    
    return fig

def main():
    # Header with real-time clock
    current_time = datetime.now().strftime("%I:%M:%S %p")
    st.markdown(f"""
    <div style="text-align: center; margin-bottom: 2rem;">
        <h1 style="color: #667eea; font-size: 3rem; margin-bottom: 0.5rem;">🚗 AllServ Real-Time</h1>
        <p style="color: #6b7280; font-size: 1.2rem;">Live Updates & Push Notifications</p>
        <p style="color: #059669; font-weight: 600;">🕒 {current_time}</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Show notifications at top
    show_notifications()
    
    # Update provider location and trigger notifications
    if st.session_state.tracking_active:
        simulate_provider_movement()
    
    # Main content based on stage
    if st.session_state.booking_stage == 'service_selection':
        show_service_selection()
    elif st.session_state.booking_stage == 'service_details':
        show_service_details()
    elif st.session_state.booking_stage == 'confirmation':
        show_confirmation()
    elif st.session_state.booking_stage == 'tracking':
        show_live_tracking()
    
    # Auto-refresh every 3 seconds for real-time updates
    if st.session_state.tracking_active:
        time.sleep(2)
        st.rerun()

def show_service_selection():
    st.markdown("### 🛍️ Choose Your Service")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("🚗 Ride-Hailing", use_container_width=True, type="primary"):
            st.session_state.current_service = 'ride_hailing'
            st.session_state.booking_stage = 'service_details'
            add_notification("Ride-hailing service selected", "info")
            st.rerun()
    
    with col2:
        if st.button("📦 Deliveries", use_container_width=True):
            st.session_state.current_service = 'deliveries'
            st.session_state.booking_stage = 'service_details'
            add_notification("Delivery service selected", "info")
            st.rerun()
    
    with col3:
        if st.button("🏠 Home Services", use_container_width=True):
            st.session_state.current_service = 'home_services'
            st.session_state.booking_stage = 'service_details'
            add_notification("Home service selected", "info")
            st.rerun()

def show_service_details():
    service_type = st.session_state.current_service
    st.markdown(f"### 📋 {service_type.replace('_', ' ').title()} Details")
    
    pickup_address = st.text_input("📍 Pickup Address", "Downtown Pittsburgh")
    
    if service_type == 'ride_hailing':
        dropoff_address = st.text_input("📍 Destination", "Pittsburgh Airport")
        st.session_state.booking_details = {
            'service_type': service_type,
            'pickup_address': pickup_address,
            'dropoff_address': dropoff_address
        }
    else:
        st.session_state.booking_details = {
            'service_type': service_type,
            'pickup_address': pickup_address
        }
    
    col1, col2 = st.columns(2)
    with col1:
        if st.button("← Back", use_container_width=True):
            st.session_state.booking_stage = 'service_selection'
            st.rerun()
    with col2:
        if st.button("Continue →", use_container_width=True, type="primary"):
            st.session_state.booking_stage = 'confirmation'
            add_notification("Service details entered", "info")
            st.rerun()

def show_confirmation():
    st.markdown("### ✅ Confirm Your Booking")
    details = st.session_state.booking_details
    
    st.write(f"**Service:** {details['service_type'].replace('_', ' ').title()}")
    st.write(f"**Pickup:** {details['pickup_address']}")
    if 'dropoff_address' in details:
        st.write(f"**Destination:** {details['dropoff_address']}")
    
    st.write("**Estimated Cost:** $12.50")
    
    col1, col2 = st.columns(2)
    with col1:
        if st.button("← Modify", use_container_width=True):
            st.session_state.booking_stage = 'service_details'
            st.rerun()
    with col2:
        if st.button("✅ Confirm Booking", use_container_width=True, type="primary"):
            start_tracking()
            st.session_state.booking_stage = 'tracking'
            add_notification("Booking confirmed! Searching for provider...", "success")
            st.rerun()

def start_tracking():
    """Initialize real-time tracking"""
    user_lat = st.session_state.user_location['lat']
    user_lng = st.session_state.user_location['lng']
    
    # Provider starts nearby
    provider_lat = user_lat + random.uniform(-0.02, 0.02)
    provider_lng = user_lng + random.uniform(-0.02, 0.02)
    
    st.session_state.provider_location = {
        'lat': provider_lat,
        'lng': provider_lng,
        'start_lat': provider_lat,
        'start_lng': provider_lng,
        'status': 'en_route',
        'progress': 0.0,
        'eta': 15,
        'start_time': datetime.now(),
        'provider_name': 'Mike Rodriguez'
    }
    st.session_state.tracking_active = True
    
    # Initial notifications
    add_notification("Provider found: Mike Rodriguez", "success")
    add_notification("Provider is on the way to pick you up", "info")

def show_live_tracking():
    st.markdown("### 🎉 Live Tracking Active!")
    
    provider = st.session_state.provider_location
    
    if provider:
        # Status display
        status_text = provider['status'].replace('_', ' ').title()
        eta_text = f"{provider.get('eta', 'N/A')} minutes"
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Provider Status", status_text)
        with col2:
            st.metric("ETA", eta_text)
        with col3:
            st.metric("Progress", f"{int(provider.get('progress', 0) * 100)}%")
        
        # Live map
        st.plotly_chart(create_live_map(), use_container_width=True)
        
        # Provider info
        st.markdown(f"""
        **Provider:** {provider.get('provider_name', 'Unknown')}
        
        **Vehicle:** Toyota Camry - ABC 123
        
        **Rating:** ⭐ 4.9 (127 rides)
        """)
    
    # Action buttons
    col1, col2 = st.columns(2)
    with col1:
        if st.button("🔄 Book Another Service", use_container_width=True):
            reset_booking()
            st.rerun()
    with col2:
        if st.button("❌ Cancel Booking", use_container_width=True):
            st.session_state.tracking_active = False
            add_notification("Booking cancelled", "warning")
            reset_booking()
            st.rerun()

def reset_booking():
    """Reset booking state"""
    st.session_state.booking_stage = 'service_selection'
    st.session_state.current_service = None
    st.session_state.booking_details = {}
    st.session_state.tracking_active = False
    st.session_state.provider_location = None

if __name__ == "__main__":
    main()