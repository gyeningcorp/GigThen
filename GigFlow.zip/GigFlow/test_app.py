import streamlit as st

st.set_page_config(
    page_title="AllServ Test",
    page_icon="🚗",
    layout="wide"
)

st.title("AllServ Platform - Test Version")
st.write("This is a test to verify Streamlit is working correctly.")

if st.button("Test Button"):
    st.success("Button clicked successfully!")

st.info("If you see this message, Streamlit is working correctly.")