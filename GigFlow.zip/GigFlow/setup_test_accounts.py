"""Setup test accounts for AllServ platform"""
import hashlib
from database import SessionLocal, User, Provider, engine, Base

# Create all tables
Base.metadata.create_all(bind=engine)

db = SessionLocal()

# Test accounts data
accounts = [
    # Customer accounts
    {
        "name": "Test Customer",
        "email": "test@allserv.com",
        "phone": "412-555-0001",
        "password": "test123",
        "user_type": "customer"
    },
    # Provider accounts
    {
        "name": "John Driver",
        "email": "driver@allserv.com",
        "phone": "412-555-0002",
        "password": "driver123",
        "user_type": "provider",
        "services": ["ride_hailing", "deliveries_errands"],
        "rating": 4.8
    }
]

# Clear existing test accounts (delete providers first to avoid foreign key constraint)
users_to_delete = db.query(User).filter(User.email.in_([
    "test@allserv.com",
    "driver@allserv.com"
])).all()

for user in users_to_delete:
    # Delete provider profile first if exists
    db.query(Provider).filter(Provider.user_id == user.id).delete()
    # Then delete user
    db.query(User).filter(User.id == user.id).delete()

db.commit()

# Create new accounts
for account_data in accounts:
    # Hash password
    password_hash = hashlib.sha256(account_data["password"].encode()).hexdigest()
    
    # Create user
    user = User(
        name=account_data["name"],
        email=account_data["email"],
        phone=account_data["phone"],
        password_hash=password_hash,
        user_type=account_data["user_type"]
    )
    db.add(user)
    db.flush()  # Get the user ID
    
    # If provider, create provider profile
    if account_data["user_type"] == "provider":
        import json
        provider = Provider(
            user_id=user.id,
            services=json.dumps(account_data.get("services", [])),
            is_available=True,
            rating=account_data.get("rating", 4.5),
            total_jobs=0
        )
        db.add(provider)
    
    print(f"Created {account_data['user_type']}: {account_data['email']} / {account_data['password']}")

db.commit()
db.close()

print("\n✅ Test accounts created successfully!")
print("\nYou can now login with:")
print("Customer: test@allserv.com / test123")
print("Provider: driver@allserv.com / driver123")