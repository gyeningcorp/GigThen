import streamlit as st
from datetime import datetime, timedelta

def show_moving_help_page():
    st.title("📦 Moving Help")
    
    # Service type selection
    service_type = st.selectbox(
        "What type of moving help do you need?",
        ["Labor Only (I have a truck)", "Truck + Labor", "Full Service Move", "Loading/Unloading Only"]
    )
    
    # Moving locations
    col1, col2 = st.columns(2)
    
    with col1:
        origin_address = st.text_input("📍 Moving From", placeholder="Origin address")
    
    with col2:
        destination_address = st.text_input("📍 Moving To", placeholder="Destination address")
    
    # Move size
    st.markdown("### 🏠 Move Details")
    
    move_size = st.selectbox(
        "Home Size",
        ["Studio/1 Bedroom", "2 Bedroom", "3 Bedroom", "4+ Bedroom", "Office/Commercial"]
    )
    
    # Item inventory
    st.markdown("### 📋 Items to Move")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Furniture & Large Items**")
        heavy_furniture = st.checkbox("Heavy Furniture (couches, beds, dressers)")
        appliances = st.checkbox("Major Appliances (fridge, washer, dryer)")
        piano = st.checkbox("Piano or Large Instruments")
        electronics = st.checkbox("Large Electronics (TV, sound system)")
    
    with col2:
        st.markdown("**Special Considerations**")
        fragile_items = st.checkbox("Fragile/Valuable Items")
        stairs_involved = st.checkbox("Stairs at pickup or delivery")
        long_carry = st.checkbox("Long carry (50+ feet from truck)")
        disassembly_needed = st.checkbox("Furniture disassembly/assembly needed")
    
    # Box count
    box_count = st.number_input("Approximate number of boxes", min_value=0, max_value=200, value=20)
    
    # Special requirements
    special_requirements = st.text_area(
        "Special Requirements or Instructions",
        placeholder="Elevator reservations, parking restrictions, fragile handling notes, etc."
    )
    
    # Scheduling
    st.markdown("### 📅 Move Scheduling")
    
    col1, col2 = st.columns(2)
    
    with col1:
        move_date = st.date_input("Move Date", min_value=datetime.now().date())
    
    with col2:
        start_time = st.selectbox(
            "Preferred Start Time",
            ["8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "1:00 PM", "2:00 PM"]
        )
    
    # Duration estimate
    duration_options = {
        "Studio/1 Bedroom": "2-3 hours",
        "2 Bedroom": "3-4 hours", 
        "3 Bedroom": "4-6 hours",
        "4+ Bedroom": "6-8 hours",
        "Office/Commercial": "4-8 hours"
    }
    
    estimated_duration = duration_options.get(move_size, "3-4 hours")
    st.info(f"Estimated Duration: {estimated_duration}")
    
    # Cost calculation
    if origin_address and destination_address:
        st.markdown("### 💰 Move Estimate")
        
        # Base costs by move size
        base_costs = {
            "Studio/1 Bedroom": 200,
            "2 Bedroom": 350,
            "3 Bedroom": 500,
            "4+ Bedroom": 750,
            "Office/Commercial": 600
        }
        
        base_cost = base_costs.get(move_size, 400)
        
        # Service type multipliers
        if service_type == "Truck + Labor":
            base_cost *= 1.5
        elif service_type == "Full Service Move":
            base_cost *= 2.0
        
        # Additional costs
        additional_cost = 0
        if stairs_involved:
            additional_cost += 75
        if piano:
            additional_cost += 150
        if long_carry:
            additional_cost += 50
        if disassembly_needed:
            additional_cost += 100
        
        total_cost = base_cost + additional_cost
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Base Cost", f"${base_cost:.0f}")
        
        with col2:
            st.metric("Additional Fees", f"${additional_cost:.0f}")
        
        with col3:
            st.metric("Total Estimate", f"${total_cost:.0f}")
        
        with col4:
            st.metric("Team Size", "2-3 movers")
        
        # Truck size recommendation
        truck_sizes = {
            "Studio/1 Bedroom": "12-14 ft truck",
            "2 Bedroom": "15-17 ft truck",
            "3 Bedroom": "18-20 ft truck",
            "4+ Bedroom": "22-26 ft truck",
            "Office/Commercial": "20+ ft truck"
        }
        
        if service_type in ["Truck + Labor", "Full Service Move"]:
            recommended_truck = truck_sizes.get(move_size, "16-18 ft truck")
            st.info(f"📦 Recommended Truck Size: {recommended_truck}")
        
        # Insurance information
        st.markdown("### 🛡️ Protection & Insurance")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.success("✅ Basic Liability Coverage Included")
            st.write("Covers up to $0.60 per lb per item")
        
        with col2:
            full_coverage = st.checkbox("Add Full Value Protection (+$50)")
            if full_coverage:
                st.write("Covers full replacement value of items")
        
        # Book moving help
        if st.button("📦 Book Moving Help", type="primary", use_container_width=True):
            final_cost = total_cost + (50 if full_coverage else 0)
            st.success(f"Moving help booked for {move_date.strftime('%B %d, %Y')} at {start_time}")
            st.success(f"Total Cost: ${final_cost:.0f}")
            st.info("Your moving team will contact you 24 hours before the move to confirm details.")

if __name__ == "__main__":
    show_moving_help_page()
