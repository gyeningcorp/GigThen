import streamlit as st
from datetime import datetime, timedelta

def show_home_services_page():
    st.title("🏠 Home Services")
    
    # Service category selection
    service_categories = {
        "🌱 Lawn Care": ["Mowing", "Trimming", "Leaf Removal", "Fertilizing"],
        "🧹 Cleaning": ["House Cleaning", "Deep Cleaning", "Move-in/out", "Post-construction"],
        "🔧 Handyman": ["Repairs", "Installation", "Maintenance", "Painting"],
        "🌿 Gardening": ["Planting", "Pruning", "Weeding", "Landscape Design"],
        "❄️ Snow Removal": ["Driveway", "Walkway", "Roof", "Commercial"],
        "💨 Pressure Washing": ["House Exterior", "Driveway", "Deck", "Fence"]
    }
    
    selected_category = st.selectbox("Select Service Category", list(service_categories.keys()))
    
    # Subcategory
    subcategory = st.selectbox("Specific Service", service_categories[selected_category])
    
    # Service address
    service_address = st.text_input("📍 Service Address", placeholder="Where is the work needed?")
    
    # Task description
    st.markdown("### 📝 Task Details")
    task_description = st.text_area(
        "Describe the work needed",
        placeholder="Be specific about what needs to be done, size of area, any special requirements..."
    )
    
    # Property details
    col1, col2 = st.columns(2)
    
    with col1:
        property_type = st.selectbox("Property Type", ["Single Family Home", "Apartment", "Condo", "Commercial"])
    
    with col2:
        property_size = st.selectbox("Property Size", ["Small", "Medium", "Large", "Extra Large"])
    
    # Access information
    access_info = st.text_input("Access Information", placeholder="Gate codes, key location, special instructions")
    
    # Scheduling
    st.markdown("### 📅 Scheduling Preferences")
    
    col1, col2 = st.columns(2)
    
    with col1:
        timing_preference = st.selectbox(
            "When do you need this done?",
            ["This Week", "Next Week", "Within a Month", "Flexible"]
        )
    
    with col2:
        time_of_day = st.selectbox(
            "Preferred Time",
            ["Morning (8AM-12PM)", "Afternoon (12PM-5PM)", "Evening (5PM-8PM)", "Anytime"]
        )
    
    # Recurring service option
    recurring = st.checkbox("This is a recurring service")
    
    if recurring:
        frequency = st.selectbox("How often?", ["Weekly", "Bi-weekly", "Monthly", "Seasonally"])
    
    # Budget
    budget_range = st.selectbox("💰 Budget Range", ["$50-100", "$100-200", "$200-500", "$500+", "Get Quotes"])
    
    # Available providers preview
    if service_address and task_description:
        st.markdown("### 👷‍♂️ Available Service Providers")
        
        # Mock provider data
        providers = [
            {"name": "Mike's Lawn Service", "rating": 4.9, "jobs": 156, "price": "$75-100"},
            {"name": "Pro Clean Team", "rating": 4.8, "jobs": 203, "price": "$80-120"},
            {"name": "Handy Helper Co.", "rating": 4.7, "jobs": 89, "price": "$70-95"}
        ]
        
        for provider in providers:
            col1, col2, col3, col4 = st.columns([2, 1, 1, 1])
            
            with col1:
                st.write(f"**{provider['name']}**")
                st.write(f"⭐ {provider['rating']} ({provider['jobs']} jobs)")
            
            with col2:
                st.write(provider['price'])
            
            with col3:
                st.write("Available")
            
            with col4:
                if st.button("Select", key=provider['name']):
                    st.success(f"Selected {provider['name']}")
        
        # Cost estimate
        st.markdown("### 💰 Service Estimate")
        
        base_costs = {
            "🌱 Lawn Care": 75,
            "🧹 Cleaning": 120,
            "🔧 Handyman": 85,
            "🌿 Gardening": 90,
            "❄️ Snow Removal": 60,
            "💨 Pressure Washing": 150
        }
        
        estimated_cost = base_costs.get(selected_category, 100)
        
        if property_size == "Large":
            estimated_cost *= 1.3
        elif property_size == "Extra Large":
            estimated_cost *= 1.6
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Estimated Cost", f"${estimated_cost:.0f}")
        
        with col2:
            st.metric("Available Providers", "12")
        
        with col3:
            st.metric("Avg Response Time", "2 hours")
        
        # Book service button
        if st.button("🏠 Book Service", type="primary", use_container_width=True):
            st.success(f"Service request submitted for {selected_category}!")
            st.info("Service providers will contact you with quotes within 2 hours.")

if __name__ == "__main__":
    show_home_services_page()
