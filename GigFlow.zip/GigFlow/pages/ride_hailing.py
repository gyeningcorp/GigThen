import streamlit as st
import plotly.graph_objects as go
from datetime import datetime, timedelta

def show_ride_hailing_page():
    st.title("🚗 Ride-Hailing")
    
    # Current location detection
    st.markdown("### 📍 Your Location")
    if st.button("📍 Use Current Location"):
        st.success("Location updated: Pittsburgh, PA")
    
    # Destination search
    destination = st.text_input("Where to?", placeholder="Enter destination address")
    
    if destination:
        # Show ride options
        st.markdown("### 🚙 Available Rides")
        
        ride_options = [
            {"type": "Standard", "price": "$12.50", "eta": "3 min", "description": "Affordable rides"},
            {"type": "Premium", "price": "$18.75", "eta": "5 min", "description": "High-end vehicles"},
            {"type": "XL", "price": "$22.50", "eta": "4 min", "description": "6+ passengers"},
        ]
        
        for option in ride_options:
            col1, col2, col3, col4 = st.columns([2, 1, 1, 1])
            
            with col1:
                st.write(f"**{option['type']}**")
                st.write(option['description'])
            
            with col2:
                st.write(option['price'])
            
            with col3:
                st.write(f"ETA: {option['eta']}")
            
            with col4:
                if st.button(f"Select", key=option['type']):
                    st.success(f"Requesting {option['type']} ride...")
        
        # Map display
        st.markdown("### 🗺️ Route Map")
        fig = go.Figure(go.Scattermapbox(
            lat=[40.4406, 40.4500],
            lon=[-79.9959, -79.9800],
            mode='markers+lines',
            marker=dict(size=10),
            name="Route"
        ))
        
        fig.update_layout(
            mapbox=dict(
                style="open-street-map",
                center=dict(lat=40.4406, lon=-79.9959),
                zoom=12
            ),
            height=400
        )
        
        st.plotly_chart(fig, use_container_width=True)

if __name__ == "__main__":
    show_ride_hailing_page()
