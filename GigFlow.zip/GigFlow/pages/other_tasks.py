import streamlit as st
from datetime import datetime, timedelta

def show_other_tasks_page():
    st.title("⚡ Other Tasks")
    
    # Task categories
    task_categories = {
        "🔧 Furniture Assembly": "IKEA furniture, bed frames, desks, etc.",
        "💻 Tech Setup": "TV mounting, router setup, smart home installation",
        "🐕 Pet Services": "Dog walking, pet sitting, pet grooming",
        "🛒 Errands & Shopping": "Grocery shopping, prescription pickup, returns",
        "📦 Organization": "Closet organizing, garage cleanup, decluttering",
        "🎉 Event Help": "Party setup, event assistance, decorations",
        "🏠 Miscellaneous": "Custom tasks and odd jobs"
    }
    
    # Task selection
    selected_category = st.selectbox("What type of task do you need help with?", list(task_categories.keys()))
    st.info(task_categories[selected_category])
    
    # Task location
    task_location = st.text_input("📍 Task Location", placeholder="Where is the task?")
    
    # Task description
    st.markdown("### 📝 Task Description")
    task_description = st.text_area(
        "Describe what you need help with",
        placeholder="Be as specific as possible about what needs to be done...",
        height=100
    )
    
    # Task requirements
    st.markdown("### 🛠️ Requirements & Preferences")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Skills & Equipment**")
        tools_required = st.checkbox("Tasker should bring tools")
        vehicle_needed = st.checkbox("Vehicle/transportation needed")
        experience_required = st.checkbox("Specific experience required")
        heavy_lifting = st.checkbox("Heavy lifting involved")
    
    with col2:
        st.markdown("**Background & Safety**")
        background_check = st.checkbox("Background check preferred")
        insurance_required = st.checkbox("Insurance required")
        same_day_needed = st.checkbox("Same day completion needed")
        recurring_task = st.checkbox("This is a recurring task")
    
    # Additional details
    additional_details = st.text_area(
        "Additional Details & Instructions",
        placeholder="Access codes, parking info, special requirements, etc."
    )
    
    # Scheduling preferences
    st.markdown("### 📅 Scheduling")
    
    col1, col2 = st.columns(2)
    
    with col1:
        availability = st.selectbox(
            "When do you need this done?",
            ["Today", "Tomorrow", "This Week", "Next Week", "Flexible"]
        )
    
    with col2:
        time_preference = st.selectbox(
            "Time Preference",
            ["Morning (8AM-12PM)", "Afternoon (12PM-5PM)", "Evening (5PM-8PM)", "Anytime"]
        )
    
    # If recurring task
    if recurring_task:
        frequency = st.selectbox("How often?", ["Weekly", "Bi-weekly", "Monthly", "As needed"])
    
    # Budget and pricing
    st.markdown("### 💰 Budget")
    
    budget_type = st.radio("How would you like to price this?", ["Hourly Rate", "Fixed Price", "Get Quotes"])
    
    # Initialize default values
    estimated_hours = 2.0
    
    if budget_type == "Hourly Rate":
        hourly_budget = st.selectbox("Hourly Budget", ["$15-25/hr", "$25-35/hr", "$35-50/hr", "$50+/hr"])
        estimated_hours = st.number_input("Estimated Hours", min_value=0.5, max_value=8.0, value=2.0, step=0.5)
    elif budget_type == "Fixed Price":
        fixed_budget = st.number_input("Total Budget ($)", min_value=25, max_value=500, value=75)
    
    # Task complexity and urgency
    col1, col2 = st.columns(2)
    
    with col1:
        task_complexity = st.selectbox("Task Complexity", ["Simple", "Moderate", "Complex", "Expert Level"])
    
    with col2:
        urgency_level = st.selectbox("Urgency", ["Low", "Medium", "High", "Emergency"])
    
    # Show available taskers if location and description provided
    if task_location and task_description:
        st.markdown("### 👨‍🔧 Available Taskers")
        
        # Filter taskers based on requirements
        available_count = 15
        if background_check:
            available_count = int(available_count * 0.7)
        if experience_required:
            available_count = int(available_count * 0.6)
        if same_day_needed:
            available_count = int(available_count * 0.4)
        
        st.info(f"📊 {available_count} qualified taskers available in your area")
        
        # Mock tasker previews
        if available_count > 0:
            taskers = [
                {"name": "Alex M.", "rating": 4.9, "jobs": 78, "speciality": "Furniture Assembly", "rate": "$25/hr"},
                {"name": "Sarah K.", "rating": 4.8, "jobs": 156, "speciality": "Tech Setup", "rate": "$30/hr"},
                {"name": "Mike R.", "rating": 4.7, "jobs": 203, "speciality": "General Tasks", "rate": "$22/hr"}
            ]
            
            for tasker in taskers[:min(3, available_count)]:
                col1, col2, col3, col4 = st.columns([2, 1, 1, 1])
                
                with col1:
                    st.write(f"**{tasker['name']}**")
                    st.write(f"Specializes in {tasker['speciality']}")
                
                with col2:
                    st.write(f"⭐ {tasker['rating']}")
                    st.write(f"({tasker['jobs']} tasks)")
                
                with col3:
                    st.write(tasker['rate'])
                
                with col4:
                    if st.button("Select", key=f"select_{tasker['name']}"):
                        st.success(f"Selected {tasker['name']}!")
        
        # Cost estimate
        st.markdown("### 💰 Task Estimate")
        
        # Base rates by category
        base_rates = {
            "🔧 Furniture Assembly": 25,
            "💻 Tech Setup": 35,
            "🐕 Pet Services": 20,
            "🛒 Errands & Shopping": 18,
            "📦 Organization": 22,
            "🎉 Event Help": 20,
            "🏠 Miscellaneous": 25
        }
        
        estimated_rate = base_rates.get(selected_category, 25)
        
        # Adjust for complexity and urgency
        if task_complexity == "Moderate":
            estimated_rate *= 1.2
        elif task_complexity == "Complex":
            estimated_rate *= 1.5
        elif task_complexity == "Expert Level":
            estimated_rate *= 2.0
        
        if urgency_level == "High":
            estimated_rate *= 1.3
        elif urgency_level == "Emergency":
            estimated_rate *= 1.8
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Est. Hourly Rate", f"${estimated_rate:.0f}/hr")
        
        with col2:
            if budget_type == "Hourly Rate":
                total_estimate = estimated_rate * estimated_hours
                st.metric("Total Estimate", f"${total_estimate:.0f}")
            else:
                st.metric("Total Estimate", "Quote-based")
        
        with col3:
            response_time = "2-4 hours" if urgency_level in ["High", "Emergency"] else "4-8 hours"
            st.metric("Response Time", response_time)
        
        # Post task button
        if st.button("⚡ Post Task", type="primary", use_container_width=True):
            st.success("Task posted successfully! 🎉")
            st.info("Qualified taskers will start applying within the hour. You'll receive notifications as applications come in.")
            
            # Show next steps
            st.markdown("### ✅ Next Steps")
            st.write("1. **Review Applications** - Taskers will send you offers with their rates and availability")
            st.write("2. **Chat with Taskers** - Ask questions and discuss details before hiring")
            st.write("3. **Choose Your Tasker** - Select based on ratings, price, and availability")
            st.write("4. **Get It Done** - Your tasker will complete the job and you'll pay through the app")

if __name__ == "__main__":
    show_other_tasks_page()
