"""
Payment page for AllServ bookings using Stripe
"""
import streamlit as st
import os
from utils.payment_utils import PaymentProcessor, calculate_pricing_breakdown

def show_payment_page():
    """Display payment page with Stripe integration"""
    
    if 'booking_details' not in st.session_state:
        st.error("No booking details found. Please start a new booking.")
        if st.button("Start New Booking"):
            st.session_state.stage = 'service_selection'
            st.rerun()
        return
    
    booking = st.session_state.booking_details
    
    st.title("💳 Complete Payment")
    st.write(f"**Booking ID:** {booking.get('booking_id', 'N/A')}")
    
    # Display booking summary
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("### Booking Summary")
        st.write(f"**Service:** {booking.get('service_type', '').replace('_', ' ').title()}")
        st.write(f"**From:** {booking.get('pickup_address', 'N/A')}")
        if booking.get('dropoff_address'):
            st.write(f"**To:** {booking.get('dropoff_address')}")
        
        # Service-specific details
        if booking.get('service_details'):
            details = booking.get('service_details', {})
            if isinstance(details, str):
                import json
                try:
                    details = json.loads(details)
                except:
                    details = {}
            
            if details:
                st.markdown("**Service Details:**")
                for key, value in details.items():
                    if key not in ['pickup_address', 'dropoff_address']:
                        st.write(f"- {key.replace('_', ' ').title()}: {value}")
    
    with col2:
        # Pricing breakdown
        service_type = booking.get('service_type', 'other_tasks')
        total_cost = booking.get('final_price', booking.get('estimated_price', 0))
        
        breakdown = calculate_pricing_breakdown(total_cost, service_type)
        
        st.markdown("### Payment Breakdown")
        st.write(f"**Service Total:** ${total_cost:.2f}")
        st.write(f"**Platform Fee ({breakdown['fee_percentage']:.1f}%):** ${breakdown['platform_fee']/100:.2f}")
        st.write(f"**Provider Earnings:** ${breakdown['provider_earnings']/100:.2f}")
        
        st.markdown("---")
        st.markdown(f"**Your Total:** ${total_cost:.2f}")
    
    st.markdown("---")
    
    # Payment methods
    st.markdown("### Choose Payment Method")
    
    payment_method = st.radio(
        "How would you like to pay?",
        ["Credit Card", "Cash (Pay driver directly)"],
        key="payment_method"
    )
    
    if payment_method == "Credit Card":
        # Stripe payment integration
        processor = PaymentProcessor()
        
        st.markdown("### Card Payment")
        st.info("🔒 Secure payment powered by Stripe")
        
        # Simulate Stripe Elements (in real app, would use Stripe.js)
        with st.form("payment_form"):
            col1, col2 = st.columns(2)
            with col1:
                card_number = st.text_input("Card Number", placeholder="1234 1234 1234 1234")
                expiry_date = st.text_input("MM/YY", placeholder="12/25")
            with col2:
                cvv = st.text_input("CVV", placeholder="123", type="password")
                cardholder_name = st.text_input("Cardholder Name")
            
            billing_zip = st.text_input("Billing ZIP Code")
            
            # Terms acceptance
            agree_terms = st.checkbox("I agree to the payment terms and conditions")
            
            payment_submitted = st.form_submit_button(
                "💳 Pay Now", 
                type="primary",
                use_container_width=True
            )
            
            if payment_submitted:
                if not all([card_number, expiry_date, cvv, cardholder_name, billing_zip]):
                    st.error("Please fill in all payment details")
                elif not agree_terms:
                    st.error("Please agree to the payment terms")
                elif len(card_number.replace(" ", "")) != 16:
                    st.error("Please enter a valid 16-digit card number")
                else:
                    # Process payment with Stripe
                    with st.spinner("Processing payment..."):
                        payment_intent = processor.create_payment_intent(
                            amount_cents=int(total_cost * 100),
                            customer_email=st.session_state.user.email,
                            provider_email=booking.get('provider_email', ''),
                            booking_id=booking.get('booking_id', ''),
                            service_type=service_type
                        )
                        
                        if payment_intent:
                            # Update booking with payment info
                            update_booking_payment(
                                booking.get('booking_id'),
                                payment_intent['payment_intent_id'],
                                breakdown['provider_earnings'] / 100,
                                breakdown['platform_fee'] / 100,
                                "processing"
                            )
                            
                            st.success("✅ Payment processed successfully!")
                            st.balloons()
                            
                            # Move to confirmation
                            st.session_state.stage = 'booking_confirmation'
                            st.session_state.payment_completed = True
                            time.sleep(2)
                            st.rerun()
                        else:
                            st.error("Payment failed. Please try again.")
    
    elif payment_method == "Cash":
        st.markdown("### Cash Payment")
        st.info("💵 You'll pay your driver directly in cash")
        
        if st.button("Confirm Cash Payment", type="primary", use_container_width=True):
            # Update booking for cash payment
            update_booking_payment(
                booking.get('booking_id'),
                None,
                breakdown['provider_earnings'] / 100,
                breakdown['platform_fee'] / 100,
                "cash_pending"
            )
            
            st.success("✅ Cash payment confirmed! Your driver will collect payment.")
            st.session_state.stage = 'booking_confirmation'
            st.session_state.payment_completed = True
            time.sleep(2)
            st.rerun()
    
    # Back button
    if st.button("← Back to Booking Details"):
        st.session_state.stage = 'booking_confirmation'
        st.rerun()

def update_booking_payment(booking_id, payment_intent_id, provider_earnings, platform_fee, payment_status):
    """Update booking with payment information"""
    from database import get_db, Booking
    
    db = next(get_db())
    booking = db.query(Booking).filter_by(booking_id=booking_id).first()
    
    if booking:
        booking.payment_intent_id = payment_intent_id
        booking.provider_payout = provider_earnings
        booking.platform_fee = platform_fee
        booking.payment_status = payment_status
        db.commit()
    
    db.close()

if __name__ == "__main__":
    show_payment_page()