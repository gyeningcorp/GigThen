import streamlit as st
from datetime import datetime, timedelta

def show_deliveries_page():
    st.title("📦 Deliveries & Errands")
    
    # Service type selection
    delivery_type = st.selectbox(
        "What do you need delivered?",
        ["Package Delivery", "Food Delivery", "Grocery Shopping", "Marketplace Pickup", "Document Delivery"]
    )
    
    # Location inputs
    col1, col2 = st.columns(2)
    
    with col1:
        pickup_address = st.text_input("📍 Pickup Address")
    
    with col2:
        delivery_address = st.text_input("📍 Delivery Address")
    
    # Item details
    st.markdown("### 📦 Item Information")
    
    item_description = st.text_area(
        "Describe the item(s)",
        placeholder="What needs to be picked up and delivered?"
    )
    
    col1, col2 = st.columns(2)
    
    with col1:
        item_size = st.selectbox("Size", ["Small (envelope/bag)", "Medium (box)", "Large (furniture)"])
    
    with col2:
        item_value = st.selectbox("Estimated Value", ["Under $50", "$50-200", "$200-500", "$500+"])
    
    # Delivery options
    st.markdown("### ⏰ Delivery Options")
    
    urgency = st.radio("When do you need this delivered?", ["ASAP", "Within 2 hours", "Schedule for later"])
    
    if urgency == "Schedule for later":
        delivery_date = st.date_input("Delivery Date", min_value=datetime.now().date())
        delivery_time = st.time_input("Preferred Time")
    
    # Special instructions
    special_instructions = st.text_area(
        "Special Instructions",
        placeholder="Fragile items, apartment access codes, preferred delivery time, etc."
    )
    
    # Pricing estimate
    if pickup_address and delivery_address:
        st.markdown("### 💰 Delivery Estimate")
        
        base_price = 8.99
        if item_size == "Medium (box)":
            base_price += 3.00
        elif item_size == "Large (furniture)":
            base_price += 8.00
        
        if urgency == "ASAP":
            base_price *= 1.5
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Delivery Fee", f"${base_price:.2f}")
        
        with col2:
            st.metric("Pickup Time", "15-30 min" if urgency == "ASAP" else "As scheduled")
        
        with col3:
            st.metric("Delivery Time", "45-90 min")
        
        # Request delivery button
        if st.button("📦 Request Delivery", type="primary", use_container_width=True):
            if item_description:
                st.success(f"Delivery request submitted! Estimated cost: ${base_price:.2f}")
                st.info("You'll receive a confirmation shortly with your courier's details.")
            else:
                st.error("Please describe the item(s) to be delivered")

if __name__ == "__main__":
    show_deliveries_page()
