import streamlit as st
import plotly.graph_objects as go
from datetime import datetime, timedelta

def show_booking_status_page():
    st.title("📱 Your Bookings")
    
    # Mock booking data
    bookings = [
        {
            "id": "AS12345",
            "service": "Ride-Hailing",
            "status": "In Progress",
            "provider": "Mike Rodriguez",
            "time": "Now",
            "location": "Downtown Pittsburgh",
            "cost": "$15.50"
        },
        {
            "id": "AS12344",
            "service": "Home Services",
            "status": "Scheduled",
            "provider": "Green Lawn Co.",
            "time": "Tomorrow 10:00 AM",
            "location": "123 Main St",
            "cost": "$75.00"
        },
        {
            "id": "AS12343",
            "service": "Delivery",
            "status": "Completed",
            "provider": "Quick Courier",
            "time": "Yesterday",
            "location": "Oakland",
            "cost": "$12.99"
        }
    ]
    
    # Current booking (if any)
    active_booking = next((b for b in bookings if b["status"] == "In Progress"), None)
    
    if active_booking:
        st.markdown("## 🚗 Current Ride")
        
        col1, col2, col3 = st.columns([1, 2, 1])
        
        with col1:
            st.markdown("### 👨‍💼")
        
        with col2:
            st.write(f"**{active_booking['provider']}**")
            st.write("⭐ 4.9 (127 rides)")
            st.write("🚗 Gray Honda Accord - ABC 123")
            st.write("📱 Arriving in 3 minutes")
        
        with col3:
            if st.button("📞 Call Driver"):
                st.info("Calling driver...")
            if st.button("💬 Message"):
                st.info("Opening chat...")
        
        # Live tracking map
        st.markdown("### 🗺️ Live Tracking")
        
        fig = go.Figure(go.Scattermapbox(
            lat=[40.4406, 40.4420],
            lon=[-79.9959, -79.9940],
            mode='markers',
            marker=dict(size=[15, 10], color=['blue', 'red']),
            text=['Your Driver', 'You'],
            name="Locations"
        ))
        
        fig.update_layout(
            mapbox=dict(
                style="open-street-map",
                center=dict(lat=40.4413, lon=-79.9950),
                zoom=15
            ),
            height=300,
            margin=dict(l=0, r=0, t=0, b=0)
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # ETA and trip info
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("ETA", "3 min")
        
        with col2:
            st.metric("Trip Distance", "4.2 miles")
        
        with col3:
            st.metric("Estimated Fare", active_booking["cost"])
        
        # Cancel ride option
        if st.button("❌ Cancel Ride", key="cancel_current"):
            st.error("Are you sure you want to cancel? Cancellation fees may apply.")
    
    # All bookings
    st.markdown("## 📋 All Bookings")
    
    # Filter options
    col1, col2 = st.columns(2)
    
    with col1:
        status_filter = st.selectbox("Filter by Status", ["All", "In Progress", "Scheduled", "Completed", "Cancelled"])
    
    with col2:
        service_filter = st.selectbox("Filter by Service", ["All", "Ride-Hailing", "Delivery", "Home Services", "Moving Help", "Other Tasks"])
    
    # Display bookings
    for booking in bookings:
        # Apply filters
        if status_filter != "All" and booking["status"] != status_filter:
            continue
        if service_filter != "All" and booking["service"] != service_filter:
            continue
        
        # Status color coding
        status_colors = {
            "In Progress": "🔵",
            "Scheduled": "🟡", 
            "Completed": "🟢",
            "Cancelled": "🔴"
        }
        
        status_color = status_colors.get(booking["status"], "⚪")
        
        with st.expander(f"{status_color} {booking['service']} - {booking['id']} ({booking['status']})"):
            col1, col2 = st.columns(2)
            
            with col1:
                st.write(f"**Provider:** {booking['provider']}")
                st.write(f"**Time:** {booking['time']}")
                st.write(f"**Location:** {booking['location']}")
                st.write(f"**Cost:** {booking['cost']}")
            
            with col2:
                # Action buttons based on status
                if booking["status"] == "Scheduled":
                    if st.button("📝 Modify", key=f"modify_{booking['id']}"):
                        st.info("Modification options coming soon!")
                    if st.button("❌ Cancel", key=f"cancel_{booking['id']}"):
                        st.warning("Booking cancelled")
                
                elif booking["status"] == "Completed":
                    if st.button("⭐ Rate & Review", key=f"rate_{booking['id']}"):
                        show_rating_form(booking)
                    if st.button("🔄 Book Again", key=f"rebook_{booking['id']}"):
                        st.success("Redirecting to booking form...")
                
                elif booking["status"] == "In Progress":
                    if st.button("📍 Track", key=f"track_{booking['id']}"):
                        st.info("Showing live tracking...")
                    if st.button("💬 Contact", key=f"contact_{booking['id']}"):
                        st.info("Opening chat...")

def show_rating_form(booking):
    st.markdown(f"### Rate your {booking['service']} experience")
    
    # Rating
    rating = st.select_slider("Overall Rating", options=[1, 2, 3, 4, 5], value=5)
    
    # Review categories
    col1, col2 = st.columns(2)
    
    with col1:
        punctuality = st.slider("Punctuality", 1, 5, 5)
        quality = st.slider("Quality of Service", 1, 5, 5)
    
    with col2:
        communication = st.slider("Communication", 1, 5, 5)
        professionalism = st.slider("Professionalism", 1, 5, 5)
    
    # Written review
    review_text = st.text_area("Write a review (optional)", placeholder="Share your experience...")
    
    # Tip option
    tip_amount = st.selectbox("Add a tip", ["No tip", "10%", "15%", "20%", "25%", "Custom amount"])
    
    if st.button("Submit Review"):
        st.success(f"Thank you for rating {booking['provider']}! ⭐ {rating}/5")
        if tip_amount != "No tip":
            st.success(f"Tip of {tip_amount} added!")

if __name__ == "__main__":
    show_booking_status_page()
