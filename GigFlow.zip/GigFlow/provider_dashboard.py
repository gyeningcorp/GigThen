import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
import random
import plotly.graph_objects as go
from database import get_db, User, Provider, Booking, Notification
import json

def generate_jobs_by_type(service_type):
    """Get real available jobs from database based on selected service type"""
    from utils.service_config import get_service_details
    
    # Get database connection
    db = next(get_db())
    
    # Use the service_type directly as it now comes from unified config
    db_service_type = service_type
    
    # Query for real pending bookings that need a provider
    pending_bookings = db.query(Booking).filter(
        Booking.status == 'pending',
        Booking.provider_id == None,
        Booking.service_type == db_service_type
    ).order_by(Booking.created_at.desc()).limit(5).all()
    
    jobs = []
    
    if pending_bookings:
        # Convert real bookings to job format
        for booking in pending_bookings:
            # Calculate time since request
            time_diff = datetime.now() - booking.created_at
            if time_diff.seconds < 60:
                time_str = "Just now"
            elif time_diff.seconds < 3600:
                time_str = f"{time_diff.seconds // 60} min ago"
            else:
                time_str = f"{time_diff.seconds // 3600}h ago"
            
            # Get service details from unified config
            service_details = get_service_details(service_type)
            
            job = {
                'id': booking.booking_id,
                'icon': service_details['icon'],
                'title': f"{service_details['name']} Request",
                'location': booking.pickup_address,
                'destination': booking.dropoff_address,
                'time': time_str,
                'details': booking.special_instructions or 'Standard service',
                'price': booking.estimated_price or 25.00,
                'db_id': booking.id
            }
            jobs.append(job)
    
    db.close()
    return jobs

def show_driver_dashboard():
    """Main gig worker dashboard - Multiple service types - Responsive"""
    
    # Get provider info
    db = next(get_db())
    provider = db.query(Provider).filter_by(user_id=st.session_state.user.id).first()
    
    # Responsive CSS for provider dashboard
    st.markdown("""
    <style>
        @media (min-width: 769px) {
            .provider-card {
                max-width: 800px;
                margin: 0 auto;
            }
        }
    </style>
    """, unsafe_allow_html=True)
    
    # Header with service type selector - responsive columns
    col1, col2, col3 = st.columns([2, 1, 1])
    with col1:
        st.markdown(f"""
        <div style='background: white; padding: 20px; border-radius: 15px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>
            <h2 style='margin: 0; color: #333;'>Welcome back, {st.session_state.user.name.split()[0]}!</h2>
            <p style='color: #666; margin-top: 5px;'>Ready for today's opportunities</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        # Service type selector from unified config
        from utils.service_config import get_provider_services
        service_types = get_provider_services()
        
        selected_service = st.selectbox(
            "Active Service:",
            list(service_types.keys()),
            key="service_selector"
        )
        st.session_state.active_service = service_types[selected_service]
    
    with col3:
        online_key = f"provider_online_{st.session_state.user.id}"
        is_online = st.toggle("🟢 Go Online", key=online_key, value=provider.is_available if provider else False)
        
        if provider and is_online != provider.is_available:
            provider.is_available = is_online
            db.commit()
    
    if not is_online:
        st.info(f"You're currently offline. Go online to start receiving {selected_service.split()[1].lower()} requests.")
    
    # Today's earnings summary across all services
    st.markdown("### 💰 Today's Performance")
    earnings_cols = st.columns(4)
    
    # Calculate today's stats from real data
    today_start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    today_bookings = db.query(Booking).filter(
        Booking.provider_id == st.session_state.user.id,
        Booking.created_at >= today_start,
        Booking.status == 'completed'
    ).all()
    
    today_earnings = sum([b.provider_payout or 0 for b in today_bookings])
    today_jobs = len(today_bookings)
    
    # Get online hours from provider data
    online_hours = 0
    if provider and provider.is_available:
        # Calculate hours since they went online (approximate)
        online_hours = random.uniform(0.5, 4)  # This would come from tracking actual online time
    
    # Calculate acceptance rate from actual accepted vs declined jobs
    total_offered = db.query(Booking).filter(
        Booking.provider_id == st.session_state.user.id
    ).count()
    
    accepted = db.query(Booking).filter(
        Booking.provider_id == st.session_state.user.id,
        Booking.status != 'declined'
    ).count()
    
    acceptance_rate = (accepted / total_offered * 100) if total_offered > 0 else 0
    
    with earnings_cols[0]:
        st.metric("Total Earnings", f"${today_earnings:.2f}")
    with earnings_cols[1]:
        st.metric("Jobs Completed", today_jobs)
    with earnings_cols[2]:
        st.metric("Online Hours", f"{online_hours:.1f}h" if is_online else "Offline")
    with earnings_cols[3]:
        st.metric("Acceptance Rate", f"{acceptance_rate:.0f}%" if total_offered > 0 else "N/A")
    
    # Available jobs section based on selected service type
    if is_online:
        service_display = selected_service.split(' ', 1)[1]  # Remove emoji
        st.markdown(f"### 📋 Available {service_display} Jobs")
        
        # Get real jobs from database
        available_jobs = generate_jobs_by_type(st.session_state.active_service)
        
        # Add custom job bidding option
        with st.expander("💡 Create Custom Gig Offer"):
            st.info("Offer your services at your own rate!")
            
            col1, col2 = st.columns(2)
            with col1:
                custom_service = st.text_input("Service Title", placeholder="e.g., 'Furniture Assembly Expert'")
                hourly_rate = st.number_input("Your Hourly Rate ($)", min_value=15.0, max_value=200.0, value=35.0, step=5.0)
            with col2:
                availability = st.selectbox("Availability", ["Available Now", "Within 1 hour", "Within 2 hours", "Schedule for later"])
                service_area = st.number_input("Service Radius (miles)", min_value=1, max_value=50, value=10)
            
            skills = st.text_area("Skills & Experience", placeholder="List your relevant skills and experience...")
            
            if st.button("📢 Publish Custom Gig", use_container_width=True):
                if custom_service and skills:
                    # Create custom gig in database
                    st.success(f"✅ Custom gig '{custom_service}' published at ${hourly_rate}/hour!")
                    st.balloons()
                else:
                    st.error("Please fill in all fields")
        
        if available_jobs:
            for job in available_jobs:
                with st.container():
                    col1, col2, col3 = st.columns([3, 1, 1])
                    
                    with col1:
                        # Build the details HTML
                        details_html = ""
                        if job.get('destination'):
                            details_html += f"<p style='margin: 5px 0; color: #666;'>➡️ {job['destination']}</p>"
                        if job.get('details'):
                            details_html += f"<p style='margin: 5px 0; color: #666;'>📝 {job['details']}</p>"
                        
                        st.markdown(f"""
                        <div style='background: #f8f9fa; padding: 15px; border-radius: 10px; margin-bottom: 10px;'>
                            <div style='display: flex; justify-content: space-between;'>
                                <div>
                                    <h4 style='margin: 0;'>{job['icon']} {job['title']}</h4>
                                    <p style='margin: 5px 0; color: #666;'>📍 {job['location']}</p>
                                    <p style='margin: 5px 0; color: #666;'>⏰ {job['time']}</p>
                                    {details_html}
                                    <p style='margin: 5px 0;'><strong>${job['price']:.2f}</strong> 
                                    <span style='color: #28a745;'>(You earn: ${job['price'] * 0.8:.2f})</span></p>
                                </div>
                            </div>
                        </div>
                        """, unsafe_allow_html=True)
                    
                    with col2:
                        if st.button("✅ Accept", key=f"accept_{job['id']}", use_container_width=True):
                            # Update the existing booking
                            booking = db.query(Booking).filter_by(id=job['db_id']).first()
                            if booking:
                                booking.provider_id = st.session_state.user.id
                                booking.status = 'accepted'
                                booking.accepted_at = datetime.now()
                                booking.provider_payout = job['price'] * 0.8
                                booking.platform_fee = job['price'] * 0.2
                                db.commit()
                                st.success("Job accepted!")
                                st.rerun()
                    
                    with col3:
                        if st.button("❌ Decline", key=f"decline_{job['id']}", use_container_width=True):
                            st.info("Job declined")
        else:
            st.info(f"🔍 No {service_display.lower()} jobs available at the moment. New jobs will appear here automatically when customers request service.")
    
    # Active jobs
    st.markdown("### 🚀 Your Active Jobs")
    
    active_bookings = db.query(Booking).filter(
        Booking.provider_id == st.session_state.user.id,
        Booking.status.in_(['accepted', 'en_route', 'arrived'])
    ).all()
    
    if active_bookings:
        for booking in active_bookings:
            # Determine service icon based on type
            service_icons = {
                'driver': '🚗',
                'lawn_care': '🌿',
                'delivery': '📦',
                'grocery': '🛒',
                'marketplace': '🏪',
                'ride_hailing': '🚗',
                'deliveries': '📦',
                'home_services': '🏠',
                'moving_help': '📦',
                'other_tasks': '✋'
            }
            icon = service_icons.get(booking.service_type, '📋')
            
            with st.expander(f"{icon} Job #{booking.booking_id} - {booking.status.upper()}", expanded=True):
                col1, col2 = st.columns([3, 1])
                
                with col1:
                    st.write(f"**Service:** {booking.service_type.replace('_', ' ').title()}")
                    st.write(f"**Location:** {booking.pickup_address}")
                    if booking.dropoff_address:
                        st.write(f"**Destination:** {booking.dropoff_address}")
                    st.write(f"**Customer:** {booking.customer.name if booking.customer else 'Customer'}")
                    st.write(f"**Your Earnings:** ${booking.provider_payout:.2f}")
                
                with col2:
                    # Dynamic button labels based on service type and status
                    if booking.status == 'accepted':
                        start_label = "🚗 Start" if booking.service_type in ['driver', 'ride_hailing', 'delivery', 'deliveries'] else "▶️ Begin"
                        if st.button(start_label, key=f"start_{booking.id}"):
                            booking.status = 'en_route'
                            booking.started_at = datetime.now()
                            db.commit()
                            st.rerun()
                    
                    elif booking.status == 'en_route':
                        arrive_label = "📍 Arrived" if booking.service_type in ['driver', 'ride_hailing'] else "✅ At Location"
                        if st.button(arrive_label, key=f"arrive_{booking.id}"):
                            booking.status = 'arrived'
                            db.commit()
                            st.rerun()
                    
                    elif booking.status == 'arrived':
                        complete_label = "✅ Complete"
                        if st.button(complete_label, key=f"complete_{booking.id}"):
                            booking.status = 'completed'
                            booking.completed_at = datetime.now()
                            
                            # Update provider earnings
                            if provider:
                                provider.total_earnings = (provider.total_earnings or 0) + booking.provider_payout
                                provider.total_jobs = (provider.total_jobs or 0) + 1
                            
                            db.commit()
                            st.success(f"Job completed! You earned ${booking.provider_payout:.2f}")
                            st.rerun()
    else:
        st.info("No active jobs. Accept a job to see it here.")
    
    # Recent completed jobs
    st.markdown("### ✅ Recent Completed Jobs")
    
    recent_completed = db.query(Booking).filter(
        Booking.provider_id == st.session_state.user.id,
        Booking.status == 'completed'
    ).order_by(Booking.completed_at.desc()).limit(5).all()
    
    if recent_completed:
        for booking in recent_completed:
            icon = service_icons.get(booking.service_type, '📋')
            
            completed_time = "Unknown"
            if booking.completed_at:
                time_diff = datetime.now() - booking.completed_at
                if time_diff.seconds < 3600:
                    completed_time = f"{time_diff.seconds // 60} min ago"
                elif time_diff.days == 0:
                    completed_time = f"{time_diff.seconds // 3600} hours ago"
                else:
                    completed_time = f"{time_diff.days} days ago"
            
            col1, col2, col3 = st.columns([3, 1, 1])
            with col1:
                st.write(f"{icon} **Job #{booking.booking_id}** - {booking.service_type.replace('_', ' ').title()}")
            with col2:
                st.write(f"💰 ${booking.provider_payout:.2f}")
            with col3:
                st.write(f"⏰ {completed_time}")
    else:
        st.info("No completed jobs yet.")
    
    db.close()

def show_driver_profile():
    """Driver profile and settings"""
    st.markdown("### 👤 Your Profile")
    
    db = next(get_db())
    provider = db.query(Provider).filter_by(user_id=st.session_state.user.id).first()
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("""
        <div style='text-align: center; padding: 20px;'>
            <div style='width: 100px; height: 100px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                        border-radius: 50%; margin: 0 auto 10px; display: flex; align-items: center; justify-content: center;'>
                <span style='font-size: 48px; color: white;'>👤</span>
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        if provider:
            st.metric("Rating", f"⭐ {provider.rating:.1f}")
            st.metric("Total Jobs", provider.total_jobs or 0)
            st.metric("Total Earnings", f"${provider.total_earnings or 0:.2f}")
    
    with col2:
        st.write(f"**Name:** {st.session_state.user.name}")
        st.write(f"**Email:** {st.session_state.user.email}")
        st.write(f"**Phone:** {st.session_state.user.phone}")
        st.write(f"**Member Since:** {st.session_state.user.created_at.strftime('%B %Y')}")
        
        if provider:
            services = json.loads(provider.services) if provider.services else []
            if services:
                st.write(f"**Services:** {', '.join(services)}")
            
            st.write(f"**Status:** {'🟢 Available' if provider.is_available else '🔴 Offline'}")
    
    # Settings section
    st.markdown("### ⚙️ Settings")
    
    with st.expander("Notification Preferences"):
        st.checkbox("New job alerts", value=True)
        st.checkbox("Earnings updates", value=True)
        st.checkbox("Customer messages", value=True)
        st.checkbox("Promotional offers", value=False)
    
    with st.expander("Service Preferences"):
        st.multiselect(
            "Active Services",
            ["🚗 Driver", "🌿 Lawn Care", "📦 Delivery", "🛒 Grocery", "🏪 Marketplace"],
            default=["🚗 Driver"]
        )
        
        st.slider("Maximum job distance (miles)", 1, 50, 15)
        st.slider("Minimum job price ($)", 5, 100, 10)
    
    with st.expander("Vehicle Information"):
        st.text_input("Vehicle Make/Model", "Toyota Camry")
        st.text_input("Vehicle Year", "2020")
        st.text_input("License Plate", "ABC-1234")
        st.text_input("Insurance Provider", "State Farm")
    
    # Sign out button
    if st.button("🚪 Sign Out", type="primary", use_container_width=True):
        st.session_state.clear()
        st.rerun()
    
    db.close()