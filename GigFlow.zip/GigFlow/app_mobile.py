"""
GigThen Mobile App - Modern mobile-first design with bottom navigation
"""
import streamlit as st
from datetime import datetime, timedelta
import time
import random
import json
import hashlib
import os
from database import get_db, User, Provider, Booking, Notification, init_sample_providers
from utils.pricing_utils import (
    calculate_ride_fare, 
    calculate_delivery_cost,
    calculate_home_service_cost,
    calculate_moving_cost
)
from utils.payment_utils import PaymentProcessor, calculate_pricing_breakdown
import math

# Configure page for mobile
st.set_page_config(
    page_title="GigThen",
    page_icon="🚗",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Responsive CSS for both mobile and desktop
st.markdown("""
<style>
    /* Responsive design */
    .stApp {
        background: white;
        min-height: 100vh;
    }
    
    /* Container with responsive max-width */
    .main-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
    }
    
    /* Remove default padding */
    .block-container {
        padding: 0 !important;
        max-width: 100% !important;
    }
    
    /* Responsive breakpoints */
    @media (max-width: 768px) {
        .stApp {
            max-width: 100%;
        }
        .main-container {
            padding: 0 10px;
        }
    }
    
    @media (min-width: 769px) {
        .main-container {
            padding: 0 40px;
        }
    }
    
    /* Mobile container */
    [data-testid="stVerticalBlock"] {
        gap: 0;
    }
    
    /* Header styling */
    .mobile-header {
        background: white;
        padding: 20px;
        border-radius: 0 0 30px 30px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        margin-bottom: 20px;
    }
    
    /* Service cards - responsive */
    .service-card {
        background: white;
        border-radius: 20px;
        padding: 20px;
        margin: 10px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        transition: transform 0.3s ease;
        cursor: pointer;
    }
    
    .service-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    }
    
    /* Desktop styles */
    @media (min-width: 769px) {
        .service-card {
            max-width: 600px;
            margin: 15px auto;
            padding: 25px;
        }
        
        .mobile-header {
            max-width: 1200px;
            margin: 0 auto 30px;
            border-radius: 15px;
        }
        
        .bottom-nav {
            display: none;
        }
    }
    
    /* Bottom navigation - mobile only */
    .bottom-nav {
        position: fixed;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
        width: 100%;
        max-width: 428px;
        background: white;
        padding: 10px 0;
        border-radius: 25px 25px 0 0;
        box-shadow: 0 -4px 20px rgba(0,0,0,0.1);
        z-index: 999;
    }
    
    @media (min-width: 769px) {
        .bottom-nav {
            display: none;
        }
    }
    
    /* Floating action button */
    .fab {
        position: fixed;
        bottom: 80px;
        right: 20px;
        width: 60px;
        height: 60px;
        background: #000;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        color: white;
        font-size: 24px;
        cursor: pointer;
        z-index: 998;
    }
    
    /* Input fields */
    .stTextInput > div > div > input {
        border-radius: 15px !important;
        border: 2px solid #e0e0e0 !important;
        padding: 12px 20px !important;
        font-size: 16px !important;
    }
    
    /* Buttons */
    .stButton > button {
        border-radius: 25px !important;
        padding: 12px 30px !important;
        font-weight: 600 !important;
        background: #000 !important;
        border: none !important;
        color: white !important;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15) !important;
    }
    
    /* Map container */
    .map-container {
        border-radius: 20px;
        overflow: hidden;
        margin: 10px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    }
    
    /* Status pill */
    .status-pill {
        display: inline-block;
        padding: 6px 16px;
        border-radius: 20px;
        font-size: 14px;
        font-weight: 600;
        margin: 5px;
    }
    
    .status-active {
        background: #e8f5e9;
        color: #2e7d32;
    }
    
    .status-pending {
        background: #fff3e0;
        color: #f57c00;
    }
    
    .status-completed {
        background: #e3f2fd;
        color: #1565c0;
    }
    
    /* Price tag */
    .price-tag {
        background: #000;
        color: white;
        padding: 8px 16px;
        border-radius: 20px;
        font-weight: bold;
        display: inline-block;
    }
    
    /* Hide streamlit elements */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    
    /* Responsive design */
    @media (max-width: 768px) {
        .stApp {
            max-width: 100%;
        }
        .bottom-nav {
            max-width: 100%;
        }
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'stage' not in st.session_state:
    st.session_state.stage = 'login'
if 'user' not in st.session_state:
    st.session_state.user = None
if 'active_tab' not in st.session_state:
    st.session_state.active_tab = 'home'

# Initialize database
init_sample_providers()

# Pittsburgh locations
PITTSBURGH_LOCATIONS = [
    {"name": "Downtown Pittsburgh", "lat": 40.4406, "lng": -79.9959},
    {"name": "Pittsburgh Airport", "lat": 40.4943, "lng": -80.2659},
    {"name": "University of Pittsburgh", "lat": 40.4444, "lng": -79.9608},
    {"name": "Carnegie Mellon University", "lat": 40.4432, "lng": -79.9428},
    {"name": "Strip District", "lat": 40.4620, "lng": -79.9825},
    {"name": "Shadyside", "lat": 40.4550, "lng": -79.9360},
    {"name": "Squirrel Hill", "lat": 40.4312, "lng": -79.9233},
    {"name": "Oakland", "lat": 40.4406, "lng": -79.9547},
    {"name": "South Side", "lat": 40.4285, "lng": -79.9659},
    {"name": "North Shore", "lat": 40.4469, "lng": -80.0097}
]

def show_mobile_login():
    """Mobile-optimized login screen"""
    st.markdown("""
    <div style='text-align: center; padding: 40px 20px; background: white;'>
        <h1 style='color: #333; font-size: 48px; margin-bottom: 10px; font-weight: bold;'>GigThen</h1>
        <p style='color: #666; font-size: 18px;'>Your all-in-one service platform</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Login card
    with st.container():
        st.markdown("<div class='mobile-header'>", unsafe_allow_html=True)
        
        tab1, tab2 = st.tabs(["📱 Login", "✨ Sign Up"])
        
        with tab1:
            login_type = st.selectbox("I am a:", ["Customer", "Service Provider"])
            email = st.text_input("Email", placeholder="Enter your email")
            password = st.text_input("Password", type="password", placeholder="Enter your password")
            
            col1, col2 = st.columns(2)
            with col1:
                st.checkbox("Remember me")
            with col2:
                st.markdown("<a href='#' style='float: right;'>Forgot password?</a>", unsafe_allow_html=True)
            
            if st.button("Login", use_container_width=True):
                if email and password:
                    db = next(get_db())
                    user_type = "customer" if login_type == "Customer" else "provider"
                    
                    # Hash password
                    password_hash = hashlib.sha256(password.encode()).hexdigest()
                    
                    # Authenticate (case-insensitive email)
                    user = db.query(User).filter(
                        User.email.ilike(email),
                        User.password_hash == password_hash,
                        User.user_type == user_type
                    ).first()
                    
                    db.close()
                    
                    if user:
                        st.session_state.user = user
                        st.session_state.user_type = user_type
                        st.session_state.stage = 'home'
                        st.success("Welcome back!")
                        time.sleep(1)
                        st.rerun()
                    else:
                        st.error("Invalid credentials")
                else:
                    st.error("Please fill all fields")
        
        with tab2:
            signup_type = st.selectbox("Sign up as:", ["Customer", "Service Provider"])
            
            col1, col2 = st.columns(2)
            with col1:
                first_name = st.text_input("First Name", key="signup_first")
                email = st.text_input("Email", key="signup_email")
            with col2:
                last_name = st.text_input("Last Name", key="signup_last")
                phone = st.text_input("Phone", key="signup_phone")
            
            password = st.text_input("Password", type="password", key="signup_pass")
            confirm_password = st.text_input("Confirm Password", type="password", key="signup_confirm")
            
            if signup_type == "Service Provider":
                services = st.multiselect(
                    "Services you provide:",
                    ["🚗 Ride Hailing", "📦 Deliveries", "🏠 Home Services", "📦 Moving", "✋ Tasks"]
                )
            
            agree_terms = st.checkbox("I agree to Terms of Service and Privacy Policy")
            
            if st.button("Create Account", use_container_width=True):
                # Validate all fields
                if not all([first_name, last_name, email, phone, password, confirm_password]):
                    st.error("Please fill in all fields")
                elif password != confirm_password:
                    st.error("Passwords don't match")
                elif len(password) < 6:
                    st.error("Password must be at least 6 characters")
                elif not agree_terms:
                    st.error("Please agree to Terms of Service")
                else:
                    # Create account in database
                    db = next(get_db())
                    
                    # Check if email already exists (case-insensitive)
                    existing_user = db.query(User).filter(User.email.ilike(email)).first()
                    
                    if existing_user:
                        st.error("Email already registered. Please login.")
                    else:
                        # Hash password
                        password_hash = hashlib.sha256(password.encode()).hexdigest()
                        
                        # Create user account
                        new_user = User(
                            name=f"{first_name} {last_name}",
                            email=email,
                            phone=phone,
                            password_hash=password_hash,
                            user_type="customer" if signup_type == "Customer" else "provider"
                        )
                        db.add(new_user)
                        db.flush()  # Get the user ID
                        
                        if signup_type == "Service Provider":
                            # Create provider profile
                            service_list = []
                            if 'services' in locals():
                                service_map = {
                                    "🚗 Ride Hailing": "ride_hailing",
                                    "📦 Deliveries": "deliveries",
                                    "🏠 Home Services": "home_services",
                                    "📦 Moving": "moving_help",
                                    "✋ Tasks": "other_tasks"
                                }
                                service_list = [service_map.get(s, s) for s in services]
                            
                            new_provider = Provider(
                                user_id=new_user.id,
                                services=json.dumps(service_list),
                                is_available=True,
                                rating=4.5,
                                total_jobs=0
                            )
                            db.add(new_provider)
                        
                        try:
                            db.commit()
                            st.success("✅ Account created successfully! Please login.")
                            time.sleep(2)
                            # Clear the form
                            st.session_state.stage = 'login'
                            st.rerun()
                        except Exception as e:
                            db.rollback()
                            st.error(f"Error creating account: {str(e)}")
                        finally:
                            db.close()
        
        st.markdown("</div>", unsafe_allow_html=True)

def show_mobile_home():
    """Mobile home screen with service grid"""
    from utils.service_config import get_customer_services
    
    # Header with user info
    user_name = st.session_state.user.name.split()[0] if hasattr(st.session_state.user, 'name') else "User"
    st.markdown(f"""
    <div class='mobile-header'>
        <div style='display: flex; justify-content: space-between; align-items: center;'>
            <div>
                <p style='margin: 0; color: #666; font-size: 14px;'>Welcome back,</p>
                <h2 style='margin: 0; color: #333;'>{user_name} 👋</h2>
            </div>
            <div style='display: flex; gap: 10px;'>
                <div style='width: 40px; height: 40px; background: #f5f5f5; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer;'>
                    🔔
                </div>
                <div style='width: 40px; height: 40px; background: #f5f5f5; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer;'>
                    👤
                </div>
            </div>
        </div>
        
        <!-- Search bar -->
        <div style='margin-top: 20px; background: #f5f5f5; padding: 12px 20px; border-radius: 25px; cursor: pointer;'>
            <span style='color: #999;'>🔍 What service do you need?</span>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Service categories with visual cards
    st.markdown("<div style='padding: 0 10px;'>", unsafe_allow_html=True)
    st.markdown("### What do you need?")
    
    # Define service cards with visual styling
    service_cards = [
        {
            'name': 'Ride',
            'type': 'ride_hailing',
            'gradient': 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            'icon': '🚗',
            'image_svg': '''<svg viewBox="0 0 200 100" style="width: 100%; height: 100px;">
                <rect x="0" y="0" width="200" height="100" fill="#f0f4ff"/>
                <path d="M40 60 L160 60 L155 45 L145 40 L55 40 L45 45 Z" fill="#ff6b6b" stroke="#333" stroke-width="1"/>
                <rect x="50" y="60" width="100" height="15" fill="#ff6b6b"/>
                <circle cx="65" cy="75" r="8" fill="#333"/>
                <circle cx="135" cy="75" r="8" fill="#333"/>
                <rect x="70" y="45" width="25" height="10" fill="#87ceeb" opacity="0.7"/>
                <rect x="105" y="45" width="25" height="10" fill="#87ceeb" opacity="0.7"/>
                <circle cx="100" cy="30" r="3" fill="#ffd93d"/>
                <path d="M97 30 L103 30" stroke="#ffd93d" stroke-width="2"/>
                <path d="M100 27 L100 33" stroke="#ffd93d" stroke-width="2"/>
            </svg>'''
        },
        {
            'name': 'Delivery',
            'type': 'deliveries_errands',
            'gradient': 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
            'icon': '📦',
            'image_svg': '''<svg viewBox="0 0 200 100" style="width: 100%; height: 100px;">
                <rect x="0" y="0" width="200" height="100" fill="#fff5f5"/>
                <ellipse cx="100" cy="70" rx="40" ry="8" fill="#ddd" opacity="0.3"/>
                <path d="M70 50 L70 35 L85 35 L90 25 L110 25 L115 35 L130 35 L130 50" fill="#6c757d" stroke="#333" stroke-width="1"/>
                <rect x="70" y="50" width="60" height="20" fill="#6c757d"/>
                <circle cx="80" cy="70" r="6" fill="#333"/>
                <circle cx="120" cy="70" r="6" fill="#333"/>
                <rect x="135" y="45" width="15" height="12" fill="#ffa726" stroke="#333" stroke-width="1"/>
                <path d="M90 55 L110 55" stroke="#fff" stroke-width="2"/>
                <circle cx="100" cy="40" r="2" fill="#ff6b6b"/>
            </svg>'''
        },
        {
            'name': 'Tasks',
            'type': 'other_tasks',
            'gradient': 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
            'icon': '✋',
            'image_svg': '''<svg viewBox="0 0 200 100" style="width: 100%; height: 100px;">
                <rect x="0" y="0" width="200" height="100" fill="#f0f8ff"/>
                <g opacity="0.8">
                    <path d="M30 70 L30 40 Q30 30 40 30 L45 30 Q50 30 50 35 L50 60" fill="#ffb3d9" stroke="#333" stroke-width="1"/>
                    <path d="M60 65 L60 35 Q60 25 70 25 L75 25 Q80 25 80 30 L80 55" fill="#b3d9ff" stroke="#333" stroke-width="1"/>
                    <path d="M90 60 L90 30 Q90 20 100 20 L105 20 Q110 20 110 25 L110 50" fill="#ffd9b3" stroke="#333" stroke-width="1"/>
                    <path d="M120 55 L120 25 Q120 15 130 15 L135 15 Q140 15 140 20 L140 45" fill="#d9b3ff" stroke="#333" stroke-width="1"/>
                    <path d="M150 50 L150 20 Q150 10 160 10 L165 10 Q170 10 170 15 L170 40" fill="#b3ffd9" stroke="#333" stroke-width="1"/>
                </g>
                <circle cx="100" cy="70" r="3" fill="#667eea"/>
                <path d="M97 70 L103 70" stroke="#667eea" stroke-width="2"/>
                <path d="M100 67 L100 73" stroke="#667eea" stroke-width="2"/>
            </svg>'''
        }
    ]
    
    # Display service cards
    for card in service_cards:
        st.markdown(f"""
        <div style='background: white; border-radius: 20px; padding: 20px; margin-bottom: 15px; 
                    box-shadow: 0 2px 10px rgba(0,0,0,0.08); cursor: pointer;
                    transition: all 0.3s ease;'>
            <div style='display: flex; align-items: center; justify-content: space-between;'>
                <div style='flex: 1;'>
                    <h3 style='margin: 0; font-size: 24px; font-weight: 600;'>{card['name']}</h3>
                </div>
                <div style='width: 150px; height: 100px; background: {card['gradient']}; 
                            border-radius: 15px; padding: 10px; position: relative;'>
                    {card['image_svg']}
                    <div style='position: absolute; bottom: 10px; right: 10px; 
                                width: 35px; height: 35px; background: white; 
                                border-radius: 50%; display: flex; align-items: center; 
                                justify-content: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);'>
                        <span style='font-size: 20px;'>{card['icon']}</span>
                    </div>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        # Invisible button for click handling
        if st.button(f"", key=f"service_{card['type']}", 
                     use_container_width=True, help=f"Select {card['name']} service"):
            st.session_state.selected_service = card['type']
            st.session_state.stage = 'service_details'
            st.rerun()
    
    # Additional services grid
    st.markdown("### More Services")
    col1, col2 = st.columns(2)
    
    additional_services = [
        ("🛒", "Grocery", "grocery_shopping", "#4caf50"),
        ("🏪", "Marketplace", "marketplace_pickup", "#ff9800"),
        ("🏠", "Home", "home_services", "#2196f3"),
        ("📦", "Moving", "moving_help", "#9c27b0"),
        ("🌿", "Lawn Care", "lawn_care", "#66bb6a")
    ]
    
    for i, (icon, name, service_type, color) in enumerate(additional_services):
        with col1 if i % 2 == 0 else col2:
            st.markdown(f"""
            <div style='background: white; border-radius: 15px; padding: 15px; margin-bottom: 10px;
                        box-shadow: 0 2px 8px rgba(0,0,0,0.08); text-align: center; cursor: pointer;'>
                <div style='font-size: 30px; margin-bottom: 5px;'>{icon}</div>
                <div style='font-weight: 500; color: #333;'>{name}</div>
            </div>
            """, unsafe_allow_html=True)
            
            if st.button(f"", key=f"additional_{service_type}", 
                        use_container_width=True, help=f"Select {name} service"):
                st.session_state.selected_service = service_type
                st.session_state.stage = 'service_details'
                st.rerun()
    
    # Recent bookings
    st.markdown("### Recent Activity")
    
    db = next(get_db())
    recent_bookings = db.query(Booking).filter_by(
        customer_id=st.session_state.user.id
    ).order_by(Booking.created_at.desc()).limit(3).all()
    
    if recent_bookings:
        for booking in recent_bookings:
            with st.container():
                st.markdown(f"""
                <div class='service-card'>
                    <div style='display: flex; justify-content: space-between; align-items: center;'>
                        <div>
                            <h4 style='margin: 0;'>{booking.service_type.replace('_', ' ').title()}</h4>
                            <p style='margin: 5px 0; color: #666; font-size: 14px;'>{booking.pickup_address}</p>
                            <p style='margin: 0; color: #999; font-size: 12px;'>{booking.created_at.strftime('%b %d, %I:%M %p')}</p>
                        </div>
                        <div>
                            <span class='status-pill status-{booking.status}'>
                                {booking.status.upper()}
                            </span>
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
    else:
        st.info("No recent bookings. Book your first service!")
    
    db.close()
    st.markdown("</div>", unsafe_allow_html=True)

def show_mobile_service_details():
    """Mobile service booking screen with specialized forms"""
    from utils.service_forms import (
        show_ride_hailing_form, show_delivery_form, show_home_services_form,
        show_moving_help_form, show_custom_task_form, show_grocery_shopping_form,
        show_marketplace_pickup_form
    )
    
    service_type = st.session_state.get('selected_service', 'ride_hailing')
    
    # Header
    st.markdown(f"""
    <div class='mobile-header'>
        <div style='display: flex; align-items: center; gap: 15px;'>
            <span style='font-size: 24px; cursor: pointer;' onclick='window.history.back()'>←</span>
            <h2 style='margin: 0;'>{service_type.replace('_', ' ').title()}</h2>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    with st.container():
        st.markdown("<div style='padding: 20px;'>", unsafe_allow_html=True)
        
        # Show appropriate form based on service type
        form_data = {}
        
        if service_type == 'ride_hailing':
            form_data = show_ride_hailing_form()
            
        elif service_type == 'delivery':
            form_data = show_delivery_form()
            
        elif service_type == 'grocery':
            form_data = show_grocery_shopping_form()
            
        elif service_type == 'marketplace':
            form_data = show_marketplace_pickup_form()
                
        elif service_type == 'home_services':
            form_data = show_home_services_form()
            
        elif service_type == 'moving_help':
            form_data = show_moving_help_form()
            
        elif service_type == 'other_tasks':
            form_data = show_custom_task_form()
        
        else:
            # Default to custom task for unrecognized services
            form_data = show_custom_task_form()
        
        # Continue with booking button
        st.markdown("---")
        
        if st.button("📋 Review & Continue", type="primary", use_container_width=True):
            # Validate form data
            required_fields = ['pickup', 'dropoff'] if service_type in ['ride_hailing', 'deliveries'] else []
            
            if service_type == 'home_services':
                required_fields = ['address']
            elif service_type == 'other_tasks':
                required_fields = ['task_title', 'task_description']
                
            # Check required fields
            form_valid = True
            if service_type == 'ride_hailing':
                form_valid = form_data.get('pickup') and form_data.get('dropoff')
            elif service_type in ['delivery', 'grocery', 'marketplace']:
                form_valid = form_data.get('pickup') and form_data.get('dropoff') or form_data.get('delivery_address')
            elif service_type == 'home_services':
                form_valid = form_data.get('address')
            elif service_type == 'other_tasks':
                form_valid = form_data.get('task_title') and form_data.get('task_description')
            else:
                form_valid = True  # Default to valid for other types
                
            if form_valid:
                # Store form data in session
                st.session_state.booking_details = {
                    'service_type': service_type,
                    'form_data': form_data,
                    'price': {'total': form_data.get('estimated_price', 50.00) if 'estimated_price' in form_data else 
                             form_data.get('budget', 50.00) if 'budget' in form_data else 50.00}
                }
                
                # For ride and delivery, extract pickup/dropoff
                if service_type == 'ride_hailing':
                    st.session_state.booking_details['pickup'] = form_data.get('pickup')
                    st.session_state.booking_details['dropoff'] = form_data.get('dropoff')
                elif service_type in ['delivery', 'grocery', 'marketplace']:
                    st.session_state.booking_details['pickup'] = form_data.get('pickup', form_data.get('store', form_data.get('seller_address')))
                    st.session_state.booking_details['dropoff'] = form_data.get('dropoff', form_data.get('delivery_address'))
                elif service_type == 'home_services':
                    st.session_state.booking_details['pickup'] = form_data.get('address')
                    st.session_state.booking_details['dropoff'] = None
                elif service_type == 'moving_help':
                    st.session_state.booking_details['pickup'] = form_data.get('from_address')
                    st.session_state.booking_details['dropoff'] = form_data.get('to_address')
                else:
                    st.session_state.booking_details['pickup'] = form_data.get('task_location', 'Customer Location')
                    st.session_state.booking_details['dropoff'] = None
                
                st.session_state.stage = 'payment'
                st.rerun()
            else:
                st.error("⚠️ Please fill in all required fields before continuing")
        
        st.markdown("</div>", unsafe_allow_html=True)

def show_mobile_activity():
    """Mobile activity/bookings screen"""
    st.markdown("""
    <div class='mobile-header'>
        <h2 style='margin: 0;'>Activity</h2>
    </div>
    """, unsafe_allow_html=True)
    
    # Tabs for different booking statuses
    tab1, tab2, tab3 = st.tabs(["🔄 Active", "⏰ Scheduled", "✅ Completed"])
    
    db = next(get_db())
    
    with tab1:
        # Active bookings
        active_bookings = db.query(Booking).filter_by(
            customer_id=st.session_state.user.id,
            status='in_progress'
        ).order_by(Booking.created_at.desc()).all()
        
        if active_bookings:
            for booking in active_bookings:
                show_booking_card(booking, is_active=True)
        else:
            st.info("No active bookings")
    
    with tab2:
        # Scheduled bookings
        scheduled_bookings = db.query(Booking).filter_by(
            customer_id=st.session_state.user.id,
            status='pending'
        ).order_by(Booking.created_at.desc()).all()
        
        if scheduled_bookings:
            for booking in scheduled_bookings:
                show_booking_card(booking, is_scheduled=True)
        else:
            st.info("No scheduled bookings")
    
    with tab3:
        # Completed bookings
        completed_bookings = db.query(Booking).filter_by(
            customer_id=st.session_state.user.id,
            status='completed'
        ).order_by(Booking.created_at.desc()).limit(10).all()
        
        if completed_bookings:
            for booking in completed_bookings:
                show_booking_card(booking, is_completed=True)
        else:
            st.info("No completed bookings")
    
    db.close()

def show_booking_card(booking, is_active=False, is_scheduled=False, is_completed=False):
    """Display a booking card"""
    service_icons = {
        'ride_hailing': '🚗',
        'deliveries': '📦',
        'home_services': '🏠',
        'moving_help': '🚚',
        'other_tasks': '✋'
    }
    
    icon = service_icons.get(booking.service_type, '📍')
    service_name = booking.service_type.replace('_', ' ').title()
    
    # Status styling
    if is_active:
        status_class = 'status-active'
        status_text = 'IN PROGRESS'
    elif is_scheduled:
        status_class = 'status-pending'
        status_text = 'SCHEDULED'
    else:
        status_class = 'status-completed'
        status_text = 'COMPLETED'
    
    st.markdown(f"""
    <div class='service-card'>
        <div style='display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;'>
            <div style='display: flex; gap: 15px; align-items: center;'>
                <span style='font-size: 32px;'>{icon}</span>
                <div>
                    <h4 style='margin: 0;'>{service_name}</h4>
                    <p style='margin: 0; color: #666; font-size: 14px;'>ID: {booking.booking_id}</p>
                </div>
            </div>
            <span class='status-pill {status_class}'>{status_text}</span>
        </div>
        <div style='padding-left: 47px;'>
            <p style='margin: 5px 0; color: #666; font-size: 14px;'>📍 {booking.pickup_address}</p>
            {f"<p style='margin: 5px 0; color: #666; font-size: 14px;'>📍 {booking.dropoff_address}</p>" if booking.dropoff_address else ""}
            <p style='margin: 5px 0; color: #999; font-size: 12px;'>{booking.created_at.strftime('%b %d, %I:%M %p')}</p>
            <div style='display: flex; justify-content: space-between; align-items: center; margin-top: 10px;'>
                <span class='price-tag'>${booking.estimated_price:.2f}</span>
                {f"<button style='background: #667eea; color: white; border: none; padding: 8px 16px; border-radius: 20px; cursor: pointer;'>Track</button>" if is_active else ""}
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

def show_mobile_tracking():
    """Mobile tracking screen - uses real driver tracking"""
    from utils.driver_tracking import show_driver_tracking
    show_driver_tracking()

def show_mobile_profile():
    """Mobile profile screen"""
    st.markdown(f"""
    <div class='mobile-header'>
        <h2 style='margin: 0;'>Profile</h2>
    </div>
    """, unsafe_allow_html=True)
    
    # Profile info
    user_name = st.session_state.user.name if hasattr(st.session_state.user, 'name') else "User"
    user_email = st.session_state.user.email if hasattr(st.session_state.user, 'email') else "user@gigthen.com"
    user_phone = st.session_state.user.phone if hasattr(st.session_state.user, 'phone') else None
    
    st.markdown(f"""
    <div class='service-card'>
        <div style='text-align: center; padding: 20px;'>
            <div style='width: 100px; height: 100px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 50%; margin: 0 auto 15px; display: flex; align-items: center; justify-content: center;'>
                <span style='font-size: 48px; color: white;'>👤</span>
            </div>
            <h3 style='margin: 0;'>{user_name}</h3>
            <p style='margin: 5px 0; color: #666;'>{user_email}</p>
            <p style='margin: 0; color: #666;'>📱 {user_phone or 'Add phone'}</p>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Menu items
    menu_items = [
        ("💳", "Payment Methods", "Manage cards and payment options"),
        ("📍", "Saved Addresses", "Home, work, and favorite places"),
        ("🎁", "Promotions", "View available discounts"),
        ("📜", "Ride History", "View past trips and receipts"),
        ("⚙️", "Settings", "App preferences and notifications"),
        ("❓", "Help & Support", "Get help with your account"),
        ("📤", "Sign Out", "Log out of your account")
    ]
    
    for icon, title, subtitle in menu_items:
        st.markdown(f"""
        <div class='service-card' style='cursor: pointer;'>
            <div style='display: flex; justify-content: space-between; align-items: center;'>
                <div style='display: flex; gap: 15px; align-items: center;'>
                    <span style='font-size: 24px;'>{icon}</span>
                    <div>
                        <p style='margin: 0; font-weight: 600;'>{title}</p>
                        <p style='margin: 0; color: #666; font-size: 14px;'>{subtitle}</p>
                    </div>
                </div>
                <span style='color: #999;'>›</span>
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        if title == "Sign Out":
            if st.button("Confirm Sign Out", key="signout"):
                st.session_state.clear()
                st.rerun()

def show_bottom_navigation():
    """Mobile bottom navigation bar"""
    tabs = [
        ("🏠", "Home", "home"),
        ("📋", "Activity", "activity"),
        ("➕", "Book", "book"),
        ("💬", "Messages", "messages"),
        ("👤", "Profile", "profile")
    ]
    
    st.markdown("""
    <div class='bottom-nav'>
        <div style='display: flex; justify-content: space-around; align-items: center;'>
    """, unsafe_allow_html=True)
    
    cols = st.columns(5)
    for i, (icon, label, tab_id) in enumerate(tabs):
        with cols[i]:
            if tab_id == "book":
                # Special booking button
                if st.button(icon, key=f"nav_{tab_id}", help=label, use_container_width=True):
                    st.session_state.active_tab = 'home'
                    st.session_state.stage = 'service_selection'
                    st.rerun()
            else:
                active = st.session_state.active_tab == tab_id
                if st.button(
                    f"{icon}\n{label}" if active else icon,
                    key=f"nav_{tab_id}",
                    help=label,
                    use_container_width=True
                ):
                    st.session_state.active_tab = tab_id
                    st.rerun()
    
    st.markdown("""
        </div>
    </div>
    """, unsafe_allow_html=True)

def create_mobile_booking(service_type, pickup, dropoff, details):
    """Create a new booking"""
    db = next(get_db())
    
    booking_id = hashlib.md5(f"{datetime.now().isoformat()}".encode()).hexdigest()[:12].upper()
    
    # Get coordinates (mock)
    pickup_coords = (40.4406, -79.9959)
    dropoff_coords = (40.4943, -80.2659) if dropoff else None
    
    # Calculate price
    distance = random.uniform(3, 15)
    duration = distance * 3
    
    if service_type == 'ride_hailing':
        price_info = calculate_ride_fare(distance, int(duration), details.get('vehicle_type', 'standard'))
    else:
        price_info = {'total': random.uniform(15, 50)}
    
    booking = Booking(
        booking_id=booking_id,
        customer_id=st.session_state.user.id,
        service_type=service_type,
        pickup_address=pickup,
        pickup_lat=pickup_coords[0],
        pickup_lng=pickup_coords[1],
        dropoff_address=dropoff,
        dropoff_lat=dropoff_coords[0] if dropoff_coords else None,
        dropoff_lng=dropoff_coords[1] if dropoff_coords else None,
        service_details=json.dumps(details),
        estimated_price=price_info['total'],
        status='pending'
    )
    
    db.add(booking)
    db.commit()
    db.close()
    
    return booking_id

def show_mobile_messages():
    """Mobile messages screen"""
    st.markdown("""
    <div class='mobile-header'>
        <h2 style='margin: 0;'>Messages</h2>
    </div>
    """, unsafe_allow_html=True)
    
    # Mock messages
    messages = [
        {
            'sender': 'Mike Rodriguez',
            'role': 'Driver',
            'message': 'On my way to pick you up!',
            'time': '2 mins ago',
            'unread': True
        },
        {
            'sender': 'GigThen Support',
            'role': 'Support',
            'message': 'Your ride has been confirmed',
            'time': '15 mins ago',
            'unread': False
        },
        {
            'sender': 'Sarah Johnson',
            'role': 'House Cleaner',
            'message': 'Service completed. Thank you!',
            'time': 'Yesterday',
            'unread': False
        }
    ]
    
    for msg in messages:
        unread_style = "background: #f0f7ff;" if msg['unread'] else ""
        st.markdown(f"""
        <div class='service-card' style='cursor: pointer; {unread_style}'>
            <div style='display: flex; gap: 15px;'>
                <div style='width: 50px; height: 50px; background: #f5f5f5; border-radius: 50%; display: flex; align-items: center; justify-content: center;'>
                    {'👤' if msg['role'] != 'Support' else '💬'}
                </div>
                <div style='flex: 1;'>
                    <div style='display: flex; justify-content: space-between; align-items: center;'>
                        <h4 style='margin: 0;'>{msg['sender']}</h4>
                        <span style='color: #999; font-size: 12px;'>{msg['time']}</span>
                    </div>
                    <p style='margin: 2px 0; color: #666; font-size: 12px;'>{msg['role']}</p>
                    <p style='margin: 5px 0; {"font-weight: 600;" if msg["unread"] else ""}'>{msg['message']}</p>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)

def show_mobile_payment():
    """Mobile payment screen"""
    if 'booking_details' not in st.session_state:
        st.session_state.stage = 'home'
        st.rerun()
    
    booking = st.session_state.booking_details
    
    st.markdown("""
    <div class='mobile-header'>
        <div style='display: flex; align-items: center; gap: 15px;'>
            <span style='font-size: 24px; cursor: pointer;' onclick='window.history.back()'>←</span>
            <h2 style='margin: 0;'>Payment</h2>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Payment summary
    total = booking.get('price', {}).get('total', 0)
    
    st.markdown(f"""
    <div class='service-card' style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;'>
        <h3 style='margin: 0; color: white;'>Total Amount</h3>
        <h1 style='margin: 10px 0; color: white;'>${total:.2f}</h1>
        <p style='margin: 0; opacity: 0.9;'>Including service fee</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Payment methods
    st.markdown("### Select Payment Method")
    
    payment_method = st.radio(
        "Choose payment method",
        ["💳 Credit Card (•••• 4242)", "💵 Cash", "➕ Add New Card"],
        key="payment_method_radio",
        label_visibility="collapsed"
    )
    
    # If Add New Card is selected, show card input form
    if "Add New Card" in payment_method:
        with st.container():
            st.markdown("#### Enter Card Details")
            col1, col2 = st.columns(2)
            with col1:
                card_number = st.text_input("Card Number", placeholder="1234 5678 9012 3456")
                expiry = st.text_input("Expiry Date", placeholder="MM/YY")
            with col2:
                card_name = st.text_input("Name on Card", placeholder="John Doe")
                cvv = st.text_input("CVV", placeholder="123", type="password", max_chars=3)
    
    # Promo code
    with st.expander("🎁 Add promo code"):
        promo_code = st.text_input("", placeholder="Enter promo code", key="promo_code_input")
        if st.button("Apply", key="apply_promo"):
            st.success("Promo code applied! $5 discount added.")
    
    # Spacer
    st.markdown("---")
    
    # Payment button with better styling
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        if st.button("💳 Complete Payment", use_container_width=True, type="primary", key="complete_payment_btn"):
            with st.spinner("Processing payment..."):
                time.sleep(2)
            
            st.success("✅ Payment successful!")
            st.balloons()
            
            # Create booking
            booking_id = create_mobile_booking(
                service_type=booking.get('service_type'),
                pickup=booking.get('pickup'),
                dropoff=booking.get('dropoff'),
                details=booking.get('details', {})
            )
            
            st.session_state.booking_id = booking_id
            st.session_state.current_booking_id = booking_id
            
            # For ride service, go to ride search page
            if booking.get('service_type') == 'ride_hailing':
                st.session_state.stage = 'searching_driver'
                st.session_state.booking_details = {
                    'pickup': booking.get('pickup'),
                    'dropoff': booking.get('dropoff'),
                    'distance': booking.get('distance', 5),
                    'duration': booking.get('duration', 15)
                }
            else:
                st.session_state.stage = 'searching_provider'
            
            time.sleep(1)
            st.rerun()

def show_provider_search():
    """Show provider search screen with 2-3 minute timeout"""
    from utils.provider_search import search_for_provider
    
    booking_id = st.session_state.get('current_booking_id')
    service_type = st.session_state.get('service_type', 'ride_hailing')
    
    # Search for provider (this will show the search UI and handle the timeout)
    provider_id = search_for_provider(booking_id, service_type)
    
    if provider_id:
        # Provider found - update booking
        db = next(get_db())
        booking = db.query(Booking).filter_by(booking_id=booking_id).first()
        if booking:
            booking.provider_id = provider_id
            booking.status = 'accepted'
            booking.accepted_at = datetime.now()
            db.commit()
        db.close()
        
        st.success("✅ Provider assigned! Redirecting to tracking...")
        st.session_state.stage = 'tracking'
        st.session_state.active_tab = 'activity'
        time.sleep(2)
        st.rerun()

def main():
    """Main responsive app for mobile and desktop"""
    if st.session_state.stage == 'login':
        show_mobile_login()
    elif st.session_state.user:
        # Check if user is a provider and redirect to provider dashboard
        if st.session_state.user_type == 'provider':
            import provider_dashboard_new
            provider_dashboard_new.show_gig_home()
        else:
            # Customer interface - responsive design
            # Desktop navigation at top
            desktop_nav_container = st.container()
            with desktop_nav_container:
                st.markdown("""
                <style>
                    @media (max-width: 768px) {
                        .desktop-nav { display: none; }
                    }
                    @media (min-width: 769px) {
                        .desktop-nav { 
                            display: block;
                            max-width: 1200px;
                            margin: 0 auto 20px;
                            padding: 10px 40px;
                        }
                    }
                </style>
                <div class="desktop-nav">
                """, unsafe_allow_html=True)
                
                # Desktop navigation tabs (hidden on mobile)
                desktop_cols = st.columns(5)
                nav_items = [
                    ("🏠", "Home", "home"),
                    ("📋", "Activity", "activity"),
                    ("➕", "Book", "book"),
                    ("💬", "Messages", "messages"),
                    ("👤", "Profile", "profile")
                ]
                
                for idx, (icon, label, tab_id) in enumerate(nav_items):
                    with desktop_cols[idx]:
                        if st.button(f"{icon} {label}", key=f"desktop_{tab_id}", use_container_width=True):
                            if tab_id == "book":
                                st.session_state.active_tab = 'home'
                                st.session_state.stage = 'service_selection'
                            else:
                                st.session_state.active_tab = tab_id
                            st.rerun()
                
                st.markdown("</div>", unsafe_allow_html=True)
            
            # Main content area with responsive container
            content_container = st.container()
            with content_container:
                # Responsive column layout
                if st.session_state.stage == 'searching_driver':
                    from utils.ride_search import show_searching_for_driver
                    show_searching_for_driver()
                elif st.session_state.stage == 'driver_tracking':
                    from utils.driver_tracking import show_driver_tracking
                    show_driver_tracking()
                elif st.session_state.stage == 'searching_provider':
                    show_provider_search()
                elif st.session_state.active_tab == 'home':
                    if st.session_state.stage == 'service_details':
                        show_mobile_service_details()
                    else:
                        show_mobile_home()
                elif st.session_state.active_tab == 'activity':
                    show_mobile_activity()
                elif st.session_state.active_tab == 'messages':
                    show_mobile_messages()
                elif st.session_state.active_tab == 'profile':
                    show_mobile_profile()
                elif st.session_state.stage == 'payment':
                    show_mobile_payment()
                elif st.session_state.stage == 'tracking':
                    show_mobile_tracking()
            
            # Show bottom navigation for mobile only
            if st.session_state.stage not in ['service_details', 'payment', 'tracking']:
                show_bottom_navigation()
    else:
        show_mobile_login()

if __name__ == "__main__":
    main()