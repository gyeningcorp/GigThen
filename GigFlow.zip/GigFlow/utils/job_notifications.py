"""Real-time job notification system for providers"""
import streamlit as st
import time
from datetime import datetime
from database import get_db, Booking, Provider, Notification
from utils.service_config import SERVICES
import random

def check_for_new_jobs(provider_id, service_type):
    """Check for new job requests for this provider"""
    db = next(get_db())
    
    # Find pending bookings that match provider's service type
    new_jobs = db.query(Booking).filter(
        Booking.status == 'pending',
        Booking.provider_id == None,
        Booking.service_type == service_type
    ).order_by(Booking.created_at.desc()).first()
    
    db.close()
    return new_jobs

def show_job_request_popup(booking):
    """Show Uber-style job request popup"""
    service = SERVICES.get(booking.service_type, SERVICES['other_tasks'])
    
    # Calculate time since request
    time_diff = datetime.now() - booking.created_at
    if time_diff.seconds < 60:
        time_str = "Just now"
    else:
        time_str = f"{time_diff.seconds // 60} min ago"
    
    # Estimate distance (mock for now)
    distance = random.uniform(0.5, 5.0)
    duration = int(distance * 3)
    
    # Show popup overlay
    st.markdown("""
    <style>
        .job-popup {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            border-radius: 20px;
            padding: 0;
            width: 90%;
            max-width: 400px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            z-index: 10000;
            animation: slideUp 0.3s ease;
        }
        
        @keyframes slideUp {
            from {
                transform: translate(-50%, 100%);
                opacity: 0;
            }
            to {
                transform: translate(-50%, -50%);
                opacity: 1;
            }
        }
        
        .popup-header {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 20px;
            border-radius: 20px 20px 0 0;
            text-align: center;
        }
        
        .popup-content {
            padding: 20px;
        }
        
        .popup-timer {
            position: absolute;
            top: 20px;
            right: 20px;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: 3px solid white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            font-weight: bold;
            background: rgba(255,255,255,0.2);
        }
        
        .trip-info {
            display: flex;
            justify-content: space-between;
            margin: 15px 0;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 12px;
        }
        
        .trip-stat {
            text-align: center;
        }
        
        .trip-value {
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }
        
        .trip-label {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        
        .location-box {
            padding: 15px;
            margin: 10px 0;
            border-left: 3px solid #667eea;
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .location-label {
            font-size: 12px;
            color: #666;
            margin-bottom: 5px;
        }
        
        .location-address {
            font-size: 16px;
            color: #333;
            font-weight: 500;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        
        .btn-accept {
            background: linear-gradient(135deg, #4caf50, #45a049);
            color: white;
            border: none;
            padding: 15px;
            border-radius: 12px;
            font-size: 18px;
            font-weight: 600;
            flex: 2;
            cursor: pointer;
        }
        
        .btn-decline {
            background: #f44336;
            color: white;
            border: none;
            padding: 15px;
            border-radius: 12px;
            font-size: 18px;
            font-weight: 600;
            flex: 1;
            cursor: pointer;
        }
        
        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 9999;
        }
    </style>
    """, unsafe_allow_html=True)
    
    # Create container for popup
    with st.container():
        st.markdown('<div class="overlay"></div>', unsafe_allow_html=True)
        
        # Popup content
        popup_html = f"""
        <div class='job-popup'>
            <div class='popup-header'>
                <div class='popup-timer'>15</div>
                <h2 style='margin: 0; font-size: 24px;'>{service['icon']} New {service['name']} Request!</h2>
                <p style='margin: 5px 0 0 0; opacity: 0.9;'>{time_str}</p>
            </div>
            
            <div class='popup-content'>
                <div class='trip-info'>
                    <div class='trip-stat'>
                        <div class='trip-value'>${booking.estimated_price:.2f}</div>
                        <div class='trip-label'>Estimated Fare</div>
                    </div>
                    <div class='trip-stat'>
                        <div class='trip-value'>{distance:.1f} mi</div>
                        <div class='trip-label'>Distance</div>
                    </div>
                    <div class='trip-stat'>
                        <div class='trip-value'>{duration} min</div>
                        <div class='trip-label'>Duration</div>
                    </div>
                </div>
                
                <div class='location-box'>
                    <div class='location-label'>PICKUP</div>
                    <div class='location-address'>{booking.pickup_address}</div>
                </div>
                
                {f'''
                <div class='location-box'>
                    <div class='location-label'>DROPOFF</div>
                    <div class='location-address'>{booking.dropoff_address}</div>
                </div>
                ''' if booking.dropoff_address else ''}
            </div>
        </div>
        """
        
        st.markdown(popup_html, unsafe_allow_html=True)
        
        # Action buttons
        col1, col2 = st.columns([2, 1])
        
        with col1:
            if st.button("✅ ACCEPT", key=f"accept_{booking.id}", use_container_width=True, type="primary"):
                accept_job(booking.id)
                st.success("Job accepted! Navigate to pickup location.")
                time.sleep(2)
                st.rerun()
        
        with col2:
            if st.button("❌ DECLINE", key=f"decline_{booking.id}", use_container_width=True):
                decline_job(booking.id)
                st.rerun()

def accept_job(booking_id):
    """Accept a job request"""
    db = next(get_db())
    
    booking = db.query(Booking).filter_by(id=booking_id).first()
    if booking:
        booking.provider_id = st.session_state.user.id
        booking.status = 'accepted'
        booking.accepted_at = datetime.now()
        
        # Create notification for customer
        notification = Notification(
            user_id=booking.customer_id,
            title="Provider Found!",
            message=f"Your {booking.service_type.replace('_', ' ').title()} provider is on the way",
            type="booking_update",
            related_booking_id=booking.id
        )
        db.add(notification)
        db.commit()
    
    db.close()

def decline_job(booking_id):
    """Decline a job request"""
    # For now, just remove from view
    # In production, would track declined jobs
    pass

def auto_check_jobs(provider_id, service_type):
    """Automatically check for new jobs periodically"""
    if 'last_job_check' not in st.session_state:
        st.session_state.last_job_check = datetime.now()
    
    # Check every 5 seconds
    if (datetime.now() - st.session_state.last_job_check).seconds >= 5:
        st.session_state.last_job_check = datetime.now()
        
        new_job = check_for_new_jobs(provider_id, service_type)
        if new_job and f"seen_job_{new_job.id}" not in st.session_state:
            st.session_state[f"seen_job_{new_job.id}"] = True
            return new_job
    
    return None