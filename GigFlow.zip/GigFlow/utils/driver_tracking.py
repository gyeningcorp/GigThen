"""Real-time GPS tracking for driver location"""
import streamlit as st
import plotly.graph_objects as go
import time
import random
from datetime import datetime
from database import get_db, Booking, Provider, User

# Pittsburgh area coordinates for realistic tracking
PITTSBURGH_COORDS = {
    'center': {'lat': 40.4406, 'lon': -79.9959},
    'bounds': {
        'north': 40.5006,
        'south': 40.3806,
        'east': -79.8659,
        'west': -80.1259
    }
}

def generate_route_points(start_lat, start_lon, end_lat, end_lon, num_points=20):
    """Generate realistic route points between start and end"""
    points = []
    
    # Add some realistic curves to the route
    for i in range(num_points):
        progress = i / (num_points - 1)
        
        # Basic interpolation with some random variation for realistic movement
        lat = start_lat + (end_lat - start_lat) * progress
        lon = start_lon + (end_lon - start_lon) * progress
        
        # Add slight variations to simulate real driving (turns, lane changes)
        if 0.2 < progress < 0.8:  # Middle portion of journey
            lat += random.uniform(-0.002, 0.002)
            lon += random.uniform(-0.002, 0.002)
        
        points.append({'lat': lat, 'lon': lon, 'progress': progress})
    
    return points

def calculate_driver_position(booking_created_at, pickup_lat, pickup_lon, dropoff_lat, dropoff_lon):
    """Calculate current driver position based on time elapsed"""
    
    # Time calculations
    elapsed_time = (datetime.now() - booking_created_at).total_seconds()
    pickup_arrival_time = 300  # 5 minutes to reach pickup
    trip_duration = 600  # 10 minutes for the trip
    
    if elapsed_time < pickup_arrival_time:
        # Driver heading to pickup
        progress = elapsed_time / pickup_arrival_time
        # Start from a random nearby location
        driver_start_lat = pickup_lat + random.uniform(-0.03, 0.03)
        driver_start_lon = pickup_lon + random.uniform(-0.03, 0.03)
        
        current_lat = driver_start_lat + (pickup_lat - driver_start_lat) * progress
        current_lon = driver_start_lon + (pickup_lon - driver_start_lon) * progress
        status = "arriving_pickup"
        eta = int((pickup_arrival_time - elapsed_time) / 60)
        
    elif elapsed_time < (pickup_arrival_time + 60):  # Wait 1 minute at pickup
        current_lat = pickup_lat
        current_lon = pickup_lon
        status = "at_pickup"
        eta = 0
        
    elif elapsed_time < (pickup_arrival_time + 60 + trip_duration):
        # Driver heading to dropoff with customer
        progress = (elapsed_time - pickup_arrival_time - 60) / trip_duration
        current_lat = pickup_lat + (dropoff_lat - pickup_lat) * progress
        current_lon = pickup_lon + (dropoff_lon - pickup_lon) * progress
        status = "enroute"
        eta = int((trip_duration - (elapsed_time - pickup_arrival_time - 60)) / 60)
        
    else:
        # Arrived at destination
        current_lat = dropoff_lat
        current_lon = dropoff_lon
        status = "completed"
        eta = 0
    
    return current_lat, current_lon, status, eta

def show_driver_tracking():
    """Display real-time driver tracking map"""
    
    # Get booking details
    if 'current_booking_id' not in st.session_state:
        st.error("No active booking found")
        return
    
    db = next(get_db())
    booking = db.query(Booking).filter_by(id=st.session_state.current_booking_id).first()
    
    if not booking:
        st.error("Booking not found")
        return
    
    # Get driver details
    provider = db.query(Provider).filter_by(id=booking.provider_id).first() if booking.provider_id else None
    driver_name = "Your Driver"
    if provider:
        user = db.query(User).filter_by(id=provider.user_id).first()
        driver_name = user.name if user else "Your Driver"
    
    # Parse location data
    booking_details = st.session_state.get('booking_details', {})
    pickup_address = booking_details.get('pickup', 'Pickup Location')
    dropoff_address = booking_details.get('dropoff', 'Destination')
    
    # Generate coordinates (in production, would use real geocoding)
    pickup_lat = PITTSBURGH_COORDS['center']['lat'] + random.uniform(-0.05, 0.05)
    pickup_lon = PITTSBURGH_COORDS['center']['lon'] + random.uniform(-0.05, 0.05)
    dropoff_lat = PITTSBURGH_COORDS['center']['lat'] + random.uniform(-0.05, 0.05)
    dropoff_lon = PITTSBURGH_COORDS['center']['lon'] + random.uniform(-0.05, 0.05)
    
    # Calculate current driver position
    driver_lat, driver_lon, status, eta = calculate_driver_position(
        booking.created_at, pickup_lat, pickup_lon, dropoff_lat, dropoff_lon
    )
    
    # Status header
    status_messages = {
        'arriving_pickup': f'🚗 Driver arriving in {eta} min',
        'at_pickup': '✅ Driver has arrived!',
        'enroute': f'🛣️ On the way • {eta} min remaining',
        'completed': '🎉 You have arrived!'
    }
    
    st.markdown(f"""
    <div style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                color: white; padding: 20px; border-radius: 15px; margin-bottom: 20px;'>
        <h2 style='color: white; margin: 0;'>{status_messages.get(status, 'Tracking...')}</h2>
        <div style='margin-top: 10px; opacity: 0.9;'>
            <div>Driver: {driver_name}</div>
            <div>Vehicle: Gray Toyota Camry • ABC-1234</div>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Create the map
    fig = go.Figure()
    
    # Add route line
    route_points = generate_route_points(pickup_lat, pickup_lon, dropoff_lat, dropoff_lon)
    route_lats = [p['lat'] for p in route_points]
    route_lons = [p['lon'] for p in route_points]
    
    fig.add_trace(go.Scattermapbox(
        mode="lines",
        lon=route_lons,
        lat=route_lats,
        line=dict(width=4, color='#667eea'),
        name="Route",
        showlegend=False
    ))
    
    # Add pickup marker
    fig.add_trace(go.Scattermapbox(
        mode="markers+text",
        lon=[pickup_lon],
        lat=[pickup_lat],
        marker=dict(size=15, color='green'),
        text=["Pickup"],
        textposition="top center",
        name="Pickup",
        showlegend=False
    ))
    
    # Add dropoff marker
    fig.add_trace(go.Scattermapbox(
        mode="markers+text",
        lon=[dropoff_lon],
        lat=[dropoff_lat],
        marker=dict(size=15, color='red'),
        text=["Dropoff"],
        textposition="top center",
        name="Dropoff",
        showlegend=False
    ))
    
    # Add driver/car marker with custom symbol
    fig.add_trace(go.Scattermapbox(
        mode="markers",
        lon=[driver_lon],
        lat=[driver_lat],
        marker=dict(
            size=20,
            color='#764ba2',
            symbol='car'  # Car icon
        ),
        text=[f"{driver_name}'s car"],
        name="Driver",
        showlegend=False
    ))
    
    # Add pulsing effect for driver location
    fig.add_trace(go.Scattermapbox(
        mode="markers",
        lon=[driver_lon],
        lat=[driver_lat],
        marker=dict(
            size=30,
            color='rgba(118, 75, 162, 0.3)',
        ),
        showlegend=False
    ))
    
    # Map layout
    fig.update_layout(
        mapbox=dict(
            style="open-street-map",
            center=dict(lat=driver_lat, lon=driver_lon),
            zoom=13,
            bearing=0,
            pitch=0
        ),
        margin=dict(l=0, r=0, t=0, b=0),
        height=400,
        showlegend=False
    )
    
    # Display map
    st.plotly_chart(fig, use_container_width=True)
    
    # Trip details
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown(f"""
        <div style='background: #f8f9fa; padding: 15px; border-radius: 10px;'>
            <div style='color: #666; font-size: 12px; margin-bottom: 5px;'>PICKUP</div>
            <div style='font-weight: 500;'>📍 {pickup_address}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div style='background: #f8f9fa; padding: 15px; border-radius: 10px;'>
            <div style='color: #666; font-size: 12px; margin-bottom: 5px;'>DROPOFF</div>
            <div style='font-weight: 500;'>📍 {dropoff_address}</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Action buttons based on status
    st.markdown("<div style='margin-top: 20px;'>", unsafe_allow_html=True)
    
    if status == 'arriving_pickup':
        col1, col2 = st.columns(2)
        with col1:
            if st.button("📞 Call Driver", use_container_width=True):
                st.info("Calling driver...")
        with col2:
            if st.button("💬 Message Driver", use_container_width=True):
                st.info("Opening chat...")
    
    elif status == 'at_pickup':
        if st.button("🚗 I'm in the car", use_container_width=True, type="primary"):
            st.success("Great! Your trip has started.")
            st.rerun()
    
    elif status == 'completed':
        st.markdown("""
        <div style='background: #d4edda; border: 1px solid #c3e6cb; padding: 15px; 
                    border-radius: 10px; text-align: center;'>
            <h3 style='color: #155724; margin: 0;'>Trip Complete!</h3>
            <p style='color: #155724; margin: 10px 0;'>Thank you for riding with us!</p>
        </div>
        """, unsafe_allow_html=True)
        
        if st.button("⭐ Rate Your Trip", use_container_width=True, type="primary"):
            st.session_state.stage = 'rating'
            st.rerun()
    
    # Cancel button (except when completed)
    if status != 'completed':
        if st.button("Cancel Trip", use_container_width=True, type="secondary"):
            booking.status = 'cancelled'
            db.commit()
            st.session_state.stage = 'home'
            st.rerun()
    
    st.markdown("</div>", unsafe_allow_html=True)
    
    # Auto-refresh for live tracking
    if status not in ['completed', 'cancelled']:
        time.sleep(3)  # Refresh every 3 seconds
        st.rerun()