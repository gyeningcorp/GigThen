"""Provider search functionality with timeout"""
import streamlit as st
import time
from datetime import datetime, timedelta
from database import get_db, Provider, Booking
import random

def search_for_provider(booking_id, service_type, max_search_time=180):
    """
    Search for available providers for a booking.
    Shows a real-time search interface that looks for providers for 2-3 minutes.
    
    Args:
        booking_id: The booking ID to search providers for
        service_type: Type of service requested
        max_search_time: Maximum time to search in seconds (default 180 = 3 minutes)
    
    Returns:
        Provider ID if found, None if no provider available
    """
    
    # Initialize search state
    if 'search_start_time' not in st.session_state:
        st.session_state.search_start_time = time.time()
        st.session_state.search_attempts = 0
    
    # Calculate elapsed time
    elapsed_time = time.time() - st.session_state.search_start_time
    remaining_time = max_search_time - elapsed_time
    
    # Search container
    search_container = st.container()
    
    with search_container:
        # Show search UI
        st.markdown("""
        <div style='background: white; padding: 30px; border-radius: 20px; text-align: center;'>
            <div class='spinner' style='margin: 0 auto 20px;'>
                <div style='width: 60px; height: 60px; border: 4px solid #f3f3f3; 
                            border-top: 4px solid #667eea; border-radius: 50%;
                            animation: spin 1s linear infinite; margin: 0 auto;'></div>
            </div>
            <h3 style='margin: 10px 0;'>🔍 Searching for available providers...</h3>
        </div>
        
        <style>
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        </style>
        """, unsafe_allow_html=True)
        
        # Progress bar
        progress = min(elapsed_time / max_search_time, 1.0)
        st.progress(progress)
        
        # Status messages that change over time
        if elapsed_time < 30:
            status_msg = "🔍 Looking for nearby providers..."
        elif elapsed_time < 60:
            status_msg = "📡 Expanding search radius..."
            st.session_state.search_attempts += 1
        elif elapsed_time < 90:
            status_msg = "🌐 Checking additional service areas..."
            st.session_state.search_attempts += 1
        elif elapsed_time < 120:
            status_msg = "⚡ Sending priority notifications to providers..."
            st.session_state.search_attempts += 1
        elif elapsed_time < 150:
            status_msg = "🎯 Making final attempts to find someone..."
            st.session_state.search_attempts += 1
        else:
            status_msg = "⏱️ Search time expiring soon..."
        
        st.info(status_msg)
        
        # Display search statistics
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Time Searching", f"{int(elapsed_time)}s")
        with col2:
            st.metric("Providers Contacted", st.session_state.search_attempts * random.randint(3, 8))
        with col3:
            if remaining_time > 0:
                st.metric("Time Remaining", f"{int(remaining_time)}s")
            else:
                st.metric("Time Remaining", "0s")
        
        # Check database for available providers periodically
        if int(elapsed_time) % 10 == 0:  # Check every 10 seconds
            db = next(get_db())
            
            # Map service types
            service_map = {
                'ride_hailing': ['driver', 'ride_hailing'],
                'deliveries': ['delivery', 'deliveries'],
                'home_services': ['lawn_care', 'home_services'],
                'moving_help': ['moving', 'moving_help'],
                'other_tasks': ['tasks', 'other_tasks']
            }
            
            acceptable_services = service_map.get(service_type, [service_type])
            
            # Query for available providers
            available_providers = db.query(Provider).filter(
                Provider.is_available == True
            ).all()
            
            # Filter providers by service type
            matching_providers = []
            for provider in available_providers:
                if provider.services:
                    import json
                    provider_services = json.loads(provider.services)
                    if any(service in acceptable_services for service in provider_services):
                        matching_providers.append(provider)
            
            db.close()
            
            # If provider found, return it
            if matching_providers:
                selected_provider = random.choice(matching_providers)
                
                # Show success message
                st.success(f"✅ Provider found! Assigning to your request...")
                time.sleep(2)
                
                # Clear search state
                del st.session_state.search_start_time
                del st.session_state.search_attempts
                
                return selected_provider.user_id
        
        # If search time exceeded
        if elapsed_time >= max_search_time:
            st.error("""
            😔 **No providers available right now**
            
            We couldn't find any available providers in your area at this time.
            This could be due to high demand or limited availability.
            
            **What you can do:**
            - Try again in a few minutes
            - Schedule for a later time
            - Adjust your service location
            """)
            
            # Clear search state
            if 'search_start_time' in st.session_state:
                del st.session_state.search_start_time
            if 'search_attempts' in st.session_state:
                del st.session_state.search_attempts
            
            # Add retry button
            if st.button("🔄 Try Again", use_container_width=True):
                st.session_state.search_start_time = time.time()
                st.session_state.search_attempts = 0
                st.rerun()
            
            if st.button("❌ Cancel Booking", use_container_width=True):
                # Update booking status to cancelled
                db = next(get_db())
                booking = db.query(Booking).filter_by(booking_id=booking_id).first()
                if booking:
                    booking.status = 'cancelled'
                    db.commit()
                db.close()
                
                st.session_state.stage = 'service_selection'
                st.session_state.active_tab = 'home'
                st.rerun()
            
            return None
        
        # Auto-refresh to update the search progress
        time.sleep(1)
        st.rerun()