"""Specialized forms for each service type"""
import streamlit as st
from datetime import datetime, time, timedelta

def show_ride_hailing_form():
    """Specialized form for ride-hailing service"""
    st.markdown("### 🚗 Ride Details")
    
    col1, col2 = st.columns(2)
    
    with col1:
        pickup = st.text_input("📍 Pickup Location", placeholder="Enter pickup address")
        pickup_time = st.selectbox("⏰ Pickup Time", [
            "Now", "In 15 minutes", "In 30 minutes", "In 1 hour", "Schedule for later"
        ])
        
        if pickup_time == "Schedule for later":
            scheduled_date = st.date_input("Date", min_value=datetime.now().date())
            scheduled_time = st.time_input("Time", value=time(12, 0))
    
    with col2:
        dropoff = st.text_input("📍 Dropoff Location", placeholder="Enter destination")
        passengers = st.number_input("👥 Number of Passengers", min_value=1, max_value=8, value=1)
        luggage = st.selectbox("🧳 Luggage", ["No luggage", "Small bag", "1-2 suitcases", "3+ suitcases"])
    
    # Ride preferences
    st.markdown("#### Preferences")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        ride_type = st.selectbox("Vehicle Type", ["Economy", "Comfort", "Premium", "XL", "Wheelchair Accessible"])
    with col2:
        quiet_ride = st.checkbox("🤫 Quiet ride preferred")
    with col3:
        child_seat = st.checkbox("👶 Child seat needed")
    
    # Special instructions
    special_instructions = st.text_area("Special Instructions", placeholder="Any specific requests or instructions for the driver?")
    
    # Price estimate
    if pickup and dropoff:
        estimated_price = calculate_ride_price(pickup, dropoff, ride_type)
        st.info(f"💰 Estimated Price: ${estimated_price:.2f}")
    
    return {
        'pickup': pickup,
        'dropoff': dropoff,
        'pickup_time': pickup_time,
        'passengers': passengers,
        'luggage': luggage,
        'ride_type': ride_type,
        'quiet_ride': quiet_ride,
        'child_seat': child_seat,
        'special_instructions': special_instructions
    }

def show_delivery_form():
    """Specialized form for delivery service"""
    st.markdown("### 📦 Delivery Details")
    
    delivery_type = st.radio("Delivery Type", [
        "📦 Package Delivery",
        "🍔 Food Delivery", 
        "📄 Document Delivery",
        "💊 Pharmacy Delivery",
        "🛍️ Shopping Delivery"
    ])
    
    col1, col2 = st.columns(2)
    
    with col1:
        pickup = st.text_input("📍 Pickup Location", placeholder="Store/Restaurant address")
        pickup_contact = st.text_input("📞 Pickup Contact", placeholder="Contact at pickup (optional)")
        
    with col2:
        dropoff = st.text_input("📍 Delivery Address", placeholder="Where to deliver")
        dropoff_contact = st.text_input("📞 Recipient Phone", placeholder="Recipient's phone number")
    
    # Package details
    st.markdown("#### Package Details")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        package_size = st.selectbox("📏 Size", ["Small (Envelope)", "Medium (Shoebox)", "Large (Moving box)", "Extra Large"])
    with col2:
        package_weight = st.selectbox("⚖️ Weight", ["Under 5 lbs", "5-20 lbs", "20-50 lbs", "Over 50 lbs"])
    with col3:
        fragile = st.checkbox("⚠️ Fragile/Handle with care")
    
    # Delivery preferences
    delivery_speed = st.radio("Delivery Speed", [
        "⚡ Express (Within 1 hour)",
        "🚀 Same Day",
        "📅 Scheduled Delivery"
    ])
    
    if delivery_speed == "📅 Scheduled Delivery":
        delivery_date = st.date_input("Delivery Date", min_value=datetime.now().date())
        delivery_window = st.selectbox("Delivery Window", [
            "Morning (8 AM - 12 PM)",
            "Afternoon (12 PM - 5 PM)",
            "Evening (5 PM - 9 PM)"
        ])
    
    # Special handling
    st.markdown("#### Special Handling")
    leave_at_door = st.checkbox("🚪 Leave at door")
    signature_required = st.checkbox("✍️ Signature required")
    photo_confirmation = st.checkbox("📸 Photo confirmation upon delivery")
    
    special_instructions = st.text_area("Delivery Instructions", 
                                       placeholder="Gate code, apartment number, delivery preferences...")
    
    # Price estimate
    estimated_price = calculate_delivery_price(package_size, delivery_speed)
    st.info(f"💰 Estimated Price: ${estimated_price:.2f}")
    
    return {
        'delivery_type': delivery_type,
        'pickup': pickup,
        'dropoff': dropoff,
        'package_size': package_size,
        'package_weight': package_weight,
        'fragile': fragile,
        'delivery_speed': delivery_speed,
        'special_instructions': special_instructions
    }

def show_home_services_form():
    """Specialized form for home services"""
    st.markdown("### 🏠 Home Service Details")
    
    service_category = st.selectbox("Service Category", [
        "🧹 Cleaning",
        "🔧 Handyman",
        "🌿 Lawn Care",
        "🎨 Painting",
        "🔌 Electrical",
        "🚰 Plumbing",
        "🏗️ General Repairs"
    ])
    
    # Service-specific options
    if "Cleaning" in service_category:
        cleaning_type = st.radio("Cleaning Type", [
            "Regular Cleaning",
            "Deep Cleaning",
            "Move-in/Move-out Cleaning",
            "Post-construction Cleaning"
        ])
        
        col1, col2 = st.columns(2)
        with col1:
            bedrooms = st.number_input("🛏️ Bedrooms", min_value=0, max_value=10, value=2)
            bathrooms = st.number_input("🚿 Bathrooms", min_value=1, max_value=10, value=1)
        with col2:
            square_feet = st.number_input("📐 Square Feet", min_value=500, max_value=10000, step=100, value=1500)
            frequency = st.selectbox("🔄 Frequency", ["One-time", "Weekly", "Bi-weekly", "Monthly"])
        
        supplies = st.checkbox("🧽 Provider brings supplies")
        pets = st.checkbox("🐾 Pets in home")
        
    elif "Lawn Care" in service_category:
        lawn_services = st.multiselect("Services Needed", [
            "Mowing", "Edging", "Leaf Removal", "Hedge Trimming", 
            "Fertilizing", "Weed Control", "Aeration", "Seeding"
        ])
        
        col1, col2 = st.columns(2)
        with col1:
            lawn_size = st.selectbox("Lawn Size", ["Small (< 1/4 acre)", "Medium (1/4 - 1/2 acre)", 
                                                   "Large (1/2 - 1 acre)", "Extra Large (> 1 acre)"])
        with col2:
            frequency = st.selectbox("Service Frequency", ["One-time", "Weekly", "Bi-weekly", "Monthly"])
        
        equipment = st.checkbox("🚜 I have equipment")
        
    elif "Handyman" in service_category or "Repairs" in service_category:
        tasks = st.text_area("Tasks Needed", 
                            placeholder="List all tasks that need to be done:\n- Fix leaky faucet\n- Install shelves\n- Repair drywall")
        
        col1, col2 = st.columns(2)
        with col1:
            urgency = st.selectbox("Urgency", ["Not urgent", "Within a week", "Within 2-3 days", "ASAP/Emergency"])
        with col2:
            estimated_hours = st.slider("Estimated Hours", min_value=1, max_value=8, value=2)
    
    # Property details
    st.markdown("#### Property Details")
    col1, col2 = st.columns(2)
    
    with col1:
        property_type = st.selectbox("Property Type", ["House", "Apartment", "Condo", "Townhouse", "Commercial"])
        address = st.text_input("📍 Service Address", placeholder="Full address")
    
    with col2:
        preferred_date = st.date_input("📅 Preferred Date", min_value=datetime.now().date())
        preferred_time = st.selectbox("⏰ Preferred Time", [
            "Morning (8 AM - 12 PM)",
            "Afternoon (12 PM - 5 PM)",
            "Evening (5 PM - 8 PM)",
            "Flexible"
        ])
    
    # Access information
    st.markdown("#### Access Information")
    access_instructions = st.text_area("Access Instructions", 
                                      placeholder="Gate code, parking info, will you be home, etc.")
    
    # Photos
    st.markdown("#### Photos (Optional)")
    photos = st.file_uploader("Upload photos of the area/issue", 
                            type=['png', 'jpg', 'jpeg'], 
                            accept_multiple_files=True)
    
    # Price estimate
    estimated_price = calculate_home_service_price(service_category, property_type)
    st.info(f"💰 Estimated Price: ${estimated_price:.2f} - ${estimated_price * 1.5:.2f}")
    
    return {
        'service_category': service_category,
        'property_type': property_type,
        'address': address,
        'preferred_date': preferred_date,
        'preferred_time': preferred_time,
        'access_instructions': access_instructions
    }

def show_moving_help_form():
    """Specialized form for moving help"""
    st.markdown("### 🚚 Moving Help Details")
    
    moving_type = st.radio("Type of Move", [
        "🏠 Full Home Move",
        "🏢 Office Move",
        "📦 Single Item/Furniture",
        "🚛 Loading/Unloading Only",
        "📦 Packing Services Only"
    ])
    
    # Locations
    st.markdown("#### Locations")
    col1, col2 = st.columns(2)
    
    with col1:
        from_address = st.text_input("📍 Moving From", placeholder="Current address")
        from_floor = st.selectbox("Floor (From)", ["Ground", "1st", "2nd", "3rd", "4th+"])
        from_elevator = st.checkbox("🛗 Elevator available (From)")
    
    with col2:
        to_address = st.text_input("📍 Moving To", placeholder="New address")
        to_floor = st.selectbox("Floor (To)", ["Ground", "1st", "2nd", "3rd", "4th+"])
        to_elevator = st.checkbox("🛗 Elevator available (To)")
    
    # Move details
    st.markdown("#### Move Details")
    
    if "Full Home" in moving_type or "Office" in moving_type:
        col1, col2, col3 = st.columns(3)
        with col1:
            bedrooms = st.number_input("🛏️ Bedrooms", min_value=0, max_value=10, value=2)
        with col2:
            square_feet = st.number_input("📐 Square Feet", min_value=500, max_value=10000, step=100, value=1500)
        with col3:
            helpers_needed = st.number_input("👥 Helpers Needed", min_value=1, max_value=6, value=2)
    else:
        items_list = st.text_area("Items to Move", 
                                 placeholder="List items:\n- Sofa\n- Refrigerator\n- Dresser")
        helpers_needed = st.number_input("👥 Helpers Needed", min_value=1, max_value=4, value=1)
    
    # Special items
    st.markdown("#### Special Items")
    col1, col2 = st.columns(2)
    
    with col1:
        heavy_items = st.multiselect("Heavy/Special Items", [
            "Piano", "Safe", "Pool Table", "Gym Equipment", 
            "Appliances", "Fragile Artwork", "Antiques"
        ])
    
    with col2:
        packing_supplies = st.checkbox("📦 Need packing supplies")
        assembly_needed = st.checkbox("🔧 Furniture assembly/disassembly needed")
        truck_needed = st.checkbox("🚚 Need moving truck")
    
    # Schedule
    moving_date = st.date_input("📅 Moving Date", min_value=datetime.now().date())
    moving_time = st.selectbox("⏰ Start Time", [
        "Early Morning (6-8 AM)",
        "Morning (8 AM-12 PM)",
        "Afternoon (12-5 PM)",
        "Evening (5-8 PM)"
    ])
    
    estimated_duration = st.slider("Estimated Duration (hours)", min_value=1, max_value=12, value=4)
    
    # Special instructions
    special_instructions = st.text_area("Special Instructions", 
                                       placeholder="Fragile items, parking restrictions, etc.")
    
    # Price estimate
    estimated_price = calculate_moving_price(moving_type, helpers_needed, estimated_duration)
    st.info(f"💰 Estimated Price: ${estimated_price:.2f}")
    
    return {
        'moving_type': moving_type,
        'from_address': from_address,
        'to_address': to_address,
        'helpers_needed': helpers_needed,
        'moving_date': moving_date,
        'special_instructions': special_instructions
    }

def show_custom_task_form():
    """Form for custom tasks where users set their own requirements and budget"""
    st.markdown("### ✋ Custom Task Details")
    
    st.info("💡 Describe any task you need help with and set your budget!")
    
    # Task details
    task_title = st.text_input("Task Title", placeholder="e.g., 'Help organize garage sale', 'Assemble IKEA furniture'")
    
    task_category = st.selectbox("Task Category", [
        "🏠 Home & Garden",
        "🛠️ Assembly & Installation",
        "📦 Shopping & Errands",
        "🎉 Event Help",
        "📚 Organization & Admin",
        "🐕 Pet Services",
        "💻 Tech Help",
        "🎨 Creative Projects",
        "Other"
    ])
    
    task_description = st.text_area("Task Description", 
                                   placeholder="Describe what you need done in detail...",
                                   height=150)
    
    # Location and timing
    st.markdown("#### When & Where")
    col1, col2 = st.columns(2)
    
    with col1:
        task_location = st.text_input("📍 Task Location", placeholder="Address or general area")
        task_date = st.date_input("📅 When do you need this done?", min_value=datetime.now().date())
    
    with col2:
        flexibility = st.selectbox("Date Flexibility", [
            "Must be this date",
            "Flexible ± 1 day",
            "Flexible ± 2-3 days",
            "Flexible within a week"
        ])
        estimated_hours = st.slider("⏱️ Estimated Hours", min_value=0.5, max_value=8.0, value=2.0, step=0.5)
    
    # Requirements
    st.markdown("#### Requirements")
    col1, col2 = st.columns(2)
    
    with col1:
        skills_needed = st.multiselect("Skills Needed", [
            "No special skills",
            "Heavy lifting",
            "Driving/Vehicle required",
            "Tools required",
            "Experience preferred",
            "Professional certification"
        ])
    
    with col2:
        helpers_needed = st.number_input("Number of Helpers", min_value=1, max_value=5, value=1)
        tools_provided = st.checkbox("I'll provide necessary tools/supplies")
    
    # Budget - Let customer set their price
    st.markdown("#### 💰 Your Budget")
    
    budget_type = st.radio("Budget Type", [
        "Hourly Rate",
        "Fixed Price for Entire Task"
    ])
    
    if budget_type == "Hourly Rate":
        col1, col2 = st.columns(2)
        with col1:
            hourly_rate = st.number_input("💵 Hourly Rate ($)", min_value=15.0, max_value=200.0, value=25.0, step=5.0)
        with col2:
            max_budget = hourly_rate * estimated_hours
            st.metric("Maximum Budget", f"${max_budget:.2f}")
            st.caption(f"Based on {estimated_hours} hours")
    else:
        fixed_price = st.number_input("💵 Total Budget ($)", min_value=20.0, max_value=5000.0, value=100.0, step=10.0)
        hourly_equivalent = fixed_price / estimated_hours if estimated_hours > 0 else 0
        st.caption(f"≈ ${hourly_equivalent:.2f}/hour based on {estimated_hours} hours")
    
    # Provider matching preferences
    st.markdown("#### Provider Preferences")
    
    provider_preferences = st.multiselect("Preferences (Optional)", [
        "⭐ Highly rated only (4.5+)",
        "✅ Verified/Background checked",
        "🏆 Experienced in this type of task",
        "💬 Good communication skills",
        "🚗 Has own transportation"
    ])
    
    # Photos
    photos = st.file_uploader("📸 Add Photos (Optional)", 
                            type=['png', 'jpg', 'jpeg'], 
                            accept_multiple_files=True,
                            help="Show what needs to be done")
    
    # Additional notes
    additional_notes = st.text_area("Additional Notes", 
                                   placeholder="Any other important details, requirements, or preferences...")
    
    # Show summary
    if task_title and task_description:
        st.success(f"""
        **Task Summary:**
        - Title: {task_title}
        - Category: {task_category}
        - Location: {task_location}
        - Date: {task_date}
        - Duration: {estimated_hours} hours
        - Budget: ${hourly_rate * estimated_hours if budget_type == "Hourly Rate" else fixed_price:.2f}
        - Helpers: {helpers_needed}
        """)
    
    return {
        'task_title': task_title,
        'task_category': task_category,
        'task_description': task_description,
        'task_location': task_location,
        'task_date': task_date,
        'estimated_hours': estimated_hours,
        'budget_type': budget_type,
        'budget': hourly_rate * estimated_hours if budget_type == "Hourly Rate" else fixed_price,
        'helpers_needed': helpers_needed,
        'additional_notes': additional_notes
    }

def show_grocery_shopping_form():
    """Specialized form for grocery shopping service"""
    st.markdown("### 🛒 Grocery Shopping Details")
    
    # Store selection
    store = st.selectbox("🏪 Select Store", [
        "Giant Eagle",
        "Whole Foods",
        "Trader Joe's",
        "Aldi",
        "Costco",
        "Sam's Club",
        "Target",
        "Walmart",
        "Other (Specify)"
    ])
    
    if store == "Other (Specify)":
        custom_store = st.text_input("Store Name", placeholder="Enter store name")
    
    # Shopping list
    st.markdown("#### Shopping List")
    
    list_type = st.radio("How would you like to provide your list?", [
        "📝 Type items",
        "📸 Upload photo of list",
        "🔗 Share list link"
    ])
    
    if list_type == "📝 Type items":
        shopping_list = st.text_area("Shopping List", 
                                    placeholder="Enter items (one per line):\nMilk\nBread\nEggs\nBananas",
                                    height=200)
        estimated_items = len(shopping_list.split('\n')) if shopping_list else 0
        st.caption(f"Approximately {estimated_items} items")
        
    elif list_type == "📸 Upload photo of list":
        list_photo = st.file_uploader("Upload list photo", type=['png', 'jpg', 'jpeg'])
        estimated_items = st.number_input("Estimated number of items", min_value=1, max_value=200, value=20)
        
    else:
        list_link = st.text_input("List Link", placeholder="Paste link to shared shopping list")
        estimated_items = st.number_input("Estimated number of items", min_value=1, max_value=200, value=20)
    
    # Preferences
    st.markdown("#### Shopping Preferences")
    col1, col2 = st.columns(2)
    
    with col1:
        substitutions = st.selectbox("If item unavailable", [
            "Get similar substitute",
            "Skip item",
            "Call/text me"
        ])
        
        brand_preference = st.selectbox("Brand preference", [
            "Cheapest option",
            "Name brands",
            "Store brands",
            "Organic when available"
        ])
    
    with col2:
        budget_limit = st.number_input("Budget Limit ($)", min_value=0, value=0, 
                                      help="Set to 0 for no limit")
        
        special_instructions = st.text_area("Special Instructions", 
                                          placeholder="Check expiration dates, ripe produce only, etc.")
    
    # Delivery details
    st.markdown("#### Delivery Details")
    
    delivery_address = st.text_input("📍 Delivery Address", placeholder="Where to deliver groceries")
    
    col1, col2 = st.columns(2)
    with col1:
        delivery_date = st.date_input("Delivery Date", min_value=datetime.now().date())
    with col2:
        delivery_window = st.selectbox("Delivery Window", [
            "ASAP",
            "Morning (8 AM - 12 PM)",
            "Afternoon (12 PM - 5 PM)",
            "Evening (5 PM - 9 PM)"
        ])
    
    # Special requirements
    col1, col2 = st.columns(2)
    with col1:
        temperature_sensitive = st.checkbox("❄️ Includes frozen/refrigerated items")
        heavy_items = st.checkbox("💪 Includes heavy items (water cases, etc.)")
    with col2:
        contactless = st.checkbox("🚪 Contactless delivery")
        bags_needed = st.checkbox("🛍️ Need shopping bags")
    
    # Price calculation
    service_fee = 15 + (estimated_items * 0.50)  # Base fee + per item
    st.info(f"""
    💰 **Estimated Service Fee: ${service_fee:.2f}**
    - Shopping service: $15 base
    - Per item fee: ${estimated_items * 0.50:.2f} ({estimated_items} items × $0.50)
    - Plus cost of groceries at checkout
    """)
    
    return {
        'store': store,
        'shopping_list': shopping_list if list_type == "📝 Type items" else None,
        'estimated_items': estimated_items,
        'delivery_address': delivery_address,
        'delivery_date': delivery_date,
        'delivery_window': delivery_window,
        'budget_limit': budget_limit,
        'service_fee': service_fee
    }

def show_marketplace_pickup_form():
    """Specialized form for marketplace pickup service"""
    st.markdown("### 🏪 Marketplace Pickup Details")
    
    platform = st.selectbox("Platform", [
        "Facebook Marketplace",
        "Craigslist",
        "OfferUp",
        "Mercari",
        "NextDoor",
        "Other"
    ])
    
    # Item details
    st.markdown("#### Item Details")
    
    item_name = st.text_input("Item Name", placeholder="e.g., Vintage dresser, Exercise bike")
    item_link = st.text_input("Listing Link (Optional)", placeholder="URL to the listing")
    
    col1, col2 = st.columns(2)
    with col1:
        item_size = st.selectbox("Item Size", [
            "Small (fits in car trunk)",
            "Medium (fits in SUV)",
            "Large (needs pickup truck)",
            "Extra Large (needs moving truck)"
        ])
        
        item_weight = st.selectbox("Approximate Weight", [
            "Light (< 25 lbs)",
            "Medium (25-75 lbs)",
            "Heavy (75-150 lbs)",
            "Very Heavy (> 150 lbs, needs 2 people)"
        ])
    
    with col2:
        item_value = st.number_input("Item Purchase Price ($)", min_value=0.0, value=100.0, step=10.0)
        fragile = st.checkbox("⚠️ Fragile/Requires careful handling")
    
    # Pickup details
    st.markdown("#### Pickup Information")
    
    col1, col2 = st.columns(2)
    with col1:
        seller_address = st.text_input("📍 Pickup Location", placeholder="Seller's address or meeting point")
        pickup_date = st.date_input("Pickup Date", min_value=datetime.now().date())
    
    with col2:
        pickup_window = st.selectbox("Pickup Time Window", [
            "Morning (8 AM - 12 PM)",
            "Afternoon (12 PM - 5 PM)",
            "Evening (5 PM - 8 PM)",
            "Flexible - Anytime"
        ])
        seller_phone = st.text_input("Seller Contact (Optional)", placeholder="Phone number")
    
    # Delivery details
    st.markdown("#### Delivery Information")
    
    delivery_address = st.text_input("📍 Delivery Address", placeholder="Where to deliver the item")
    
    col1, col2 = st.columns(2)
    with col1:
        stairs_pickup = st.selectbox("Stairs at Pickup", ["No stairs", "1 flight", "2 flights", "3+ flights"])
    with col2:
        stairs_delivery = st.selectbox("Stairs at Delivery", ["No stairs", "1 flight", "2 flights", "3+ flights"])
    
    # Payment handling
    st.markdown("#### Payment Handling")
    
    payment_method = st.radio("Payment to Seller", [
        "I've already paid the seller",
        "Provider pays seller, I reimburse + fee",
        "I'll handle payment separately"
    ])
    
    if payment_method == "Provider pays seller, I reimburse + fee":
        st.warning(f"Provider will pay ${item_value:.2f} to seller. You'll reimburse this amount plus service fee.")
    
    # Additional services
    st.markdown("#### Additional Services")
    
    col1, col2 = st.columns(2)
    with col1:
        inspection = st.checkbox("🔍 Inspect item before pickup")
        assembly = st.checkbox("🔧 Assembly needed after delivery")
    with col2:
        disposal = st.checkbox("🗑️ Dispose of old item")
        photos = st.checkbox("📸 Send photos during pickup")
    
    # Special instructions
    special_instructions = st.text_area("Special Instructions", 
                                       placeholder="Gate codes, specific handling instructions, where to place item...")
    
    # Calculate service fee
    base_fee = 30
    size_multiplier = {"Small": 1, "Medium": 1.5, "Large": 2, "Extra Large": 3}
    size_key = item_size.split(" ")[0] if item_size else "Medium"
    
    service_fee = base_fee * size_multiplier.get(size_key, 1)
    
    if stairs_pickup != "No stairs":
        service_fee += 10
    if stairs_delivery != "No stairs":
        service_fee += 10
    if assembly:
        service_fee += 25
    if disposal:
        service_fee += 20
    
    st.info(f"""
    💰 **Service Fee: ${service_fee:.2f}**
    - Base pickup & delivery: ${base_fee:.2f}
    - Size adjustment: {size_key}
    {"- Stairs handling: $20" if stairs_pickup != "No stairs" or stairs_delivery != "No stairs" else ""}
    {"- Assembly service: $25" if assembly else ""}
    {"- Disposal service: $20" if disposal else ""}
    """)
    
    return {
        'platform': platform,
        'item_name': item_name,
        'item_size': item_size,
        'seller_address': seller_address,
        'delivery_address': delivery_address,
        'pickup_date': pickup_date,
        'payment_method': payment_method,
        'service_fee': service_fee,
        'special_instructions': special_instructions
    }

# Price calculation functions
def calculate_ride_price(pickup, dropoff, ride_type):
    """Calculate ride price based on distance and type - 30% cheaper than Uber"""
    # Base prices (30% lower than typical Uber)
    base_prices = {
        "Economy": 1.50,      # Uber: ~$2.50
        "Comfort": 2.00,      # Uber: ~$3.00
        "Premium": 3.50,      # Uber: ~$5.00
        "XL": 2.50,          # Uber: ~$3.50
        "Wheelchair Accessible": 2.00
    }
    
    # Per mile rate (40% lower than Uber's ~$1.50/mile)
    per_mile_rates = {
        "Economy": 0.90,
        "Comfort": 1.10,
        "Premium": 1.50,
        "XL": 1.20,
        "Wheelchair Accessible": 0.95
    }
    
    # Per minute rate (33% lower than Uber's ~$0.30/min)
    per_minute = 0.20
    
    # Simplified calculation - in production would use actual distance
    import random
    distance = random.uniform(3, 15)  # miles
    duration = distance * 3  # rough estimate: 3 minutes per mile in city
    
    base = base_prices.get(ride_type, 1.50)
    mile_rate = per_mile_rates.get(ride_type, 0.90)
    
    price = base + (distance * mile_rate) + (duration * per_minute)
    
    # Add distance and duration to session state for ride search page
    if 'booking_details' not in st.session_state:
        st.session_state.booking_details = {}
    st.session_state.booking_details['distance'] = round(distance, 1)
    st.session_state.booking_details['duration'] = round(duration, 0)
    
    return round(price, 2)

def calculate_delivery_price(package_size, delivery_speed):
    """Calculate delivery price"""
    size_prices = {
        "Small (Envelope)": 8,
        "Medium (Shoebox)": 12,
        "Large (Moving box)": 20,
        "Extra Large": 35
    }
    
    speed_multiplier = {
        "⚡ Express (Within 1 hour)": 2.0,
        "🚀 Same Day": 1.5,
        "📅 Scheduled Delivery": 1.0
    }
    
    base = size_prices.get(package_size, 15)
    multiplier = speed_multiplier.get(delivery_speed, 1.0)
    return round(base * multiplier, 2)

def calculate_home_service_price(service_category, property_type):
    """Calculate home service price range"""
    base_prices = {
        "🧹 Cleaning": 80,
        "🔧 Handyman": 75,
        "🌿 Lawn Care": 60,
        "🎨 Painting": 200,
        "🔌 Electrical": 150,
        "🚰 Plumbing": 120,
        "🏗️ General Repairs": 100
    }
    return base_prices.get(service_category, 100)

def calculate_moving_price(moving_type, helpers, hours):
    """Calculate moving help price"""
    hourly_rate = 35  # per helper
    truck_fee = 50 if "Full Home" in moving_type else 0
    return round((hourly_rate * helpers * hours) + truck_fee, 2)