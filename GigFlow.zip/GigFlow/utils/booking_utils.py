import streamlit as st
from datetime import datetime, timedelta
import hashlib

def generate_booking_id(service_type, timestamp=None):
    """Generate a unique booking ID"""
    if timestamp is None:
        timestamp = datetime.now()
    
    # Create a hash from service type and timestamp
    hash_input = f"{service_type}_{timestamp.isoformat()}"
    hash_object = hashlib.md5(hash_input.encode())
    hash_hex = hash_object.hexdigest()
    
    # Use first 5 characters and add AS prefix
    booking_id = f"AS{hash_hex[:5].upper()}"
    
    return booking_id

def calculate_service_fee(base_cost, service_type, add_ons=None):
    """Calculate total service fee including platform fees and add-ons"""
    
    # Platform fees by service type
    platform_fees = {
        "ride_hailing": 0.15,    # 15%
        "delivery": 0.20,        # 20%
        "home_services": 0.18,   # 18%
        "moving_help": 0.16,     # 16%
        "other_tasks": 0.22      # 22%
    }
    
    fee_rate = platform_fees.get(service_type, 0.18)
    platform_fee = base_cost * fee_rate
    
    total_cost = base_cost + platform_fee
    
    # Add any additional fees
    if add_ons:
        for add_on in add_ons:
            total_cost += add_on.get('cost', 0)
    
    return {
        'base_cost': base_cost,
        'platform_fee': platform_fee,
        'add_ons_cost': sum([addon.get('cost', 0) for addon in add_ons]) if add_ons else 0,
        'total_cost': total_cost
    }

def get_service_providers(service_type, location=None, filters=None):
    """Get available service providers based on service type and filters"""
    
    # Mock provider data
    providers = {
        "ride_hailing": [
            {"name": "Mike Rodriguez", "rating": 4.9, "trips": 127, "eta": "3 min", "car": "Honda Accord", "license": "ABC 123"},
            {"name": "Sarah Chen", "rating": 4.8, "trips": 89, "eta": "5 min", "car": "Toyota Camry", "license": "XYZ 789"},
            {"name": "David Wilson", "rating": 4.7, "trips": 156, "eta": "7 min", "car": "Nissan Altima", "license": "DEF 456"}
        ],
        "delivery": [
            {"name": "Quick Courier", "rating": 4.8, "deliveries": 203, "eta": "20 min", "vehicle": "Bike"},
            {"name": "Fast Dash", "rating": 4.9, "deliveries": 156, "eta": "15 min", "vehicle": "Car"},
            {"name": "Express Go", "rating": 4.7, "deliveries": 178, "eta": "25 min", "vehicle": "Van"}
        ],
        "home_services": [
            {"name": "Mike's Lawn Service", "rating": 4.9, "jobs": 156, "price": "$75-100", "speciality": "Lawn Care"},
            {"name": "Pro Clean Team", "rating": 4.8, "jobs": 203, "price": "$80-120", "speciality": "Cleaning"},
            {"name": "Handy Helper Co.", "rating": 4.7, "jobs": 89, "price": "$70-95", "speciality": "General"}
        ],
        "moving_help": [
            {"name": "Strong Movers", "rating": 4.9, "moves": 78, "price": "$90/hr", "team_size": "3 people"},
            {"name": "Quick Move Co.", "rating": 4.8, "moves": 134, "price": "$85/hr", "team_size": "2-3 people"},
            {"name": "Pro Movers Plus", "rating": 4.7, "moves": 167, "price": "$95/hr", "team_size": "4 people"}
        ],
        "other_tasks": [
            {"name": "Alex M.", "rating": 4.9, "tasks": 78, "speciality": "Furniture Assembly", "rate": "$25/hr"},
            {"name": "Sarah K.", "rating": 4.8, "tasks": 156, "speciality": "Tech Setup", "rate": "$30/hr"},
            {"name": "Mike R.", "rating": 4.7, "tasks": 203, "speciality": "General Tasks", "rate": "$22/hr"}
        ]
    }
    
    return providers.get(service_type, [])

def estimate_completion_time(service_type, details):
    """Estimate service completion time based on service type and details"""
    
    base_times = {
        "ride_hailing": 30,      # 30 minutes average
        "delivery": 60,          # 1 hour
        "home_services": 120,    # 2 hours
        "moving_help": 180,      # 3 hours
        "other_tasks": 90        # 1.5 hours
    }
    
    base_time = base_times.get(service_type, 60)
    
    # Adjust based on details
    if service_type == "moving_help":
        size_multipliers = {
            "Studio/1 Bedroom": 1.0,
            "2 Bedroom": 1.5,
            "3 Bedroom": 2.0,
            "4+ Bedroom": 3.0
        }
        multiplier = size_multipliers.get(details.get('home_size', 'Studio/1 Bedroom'), 1.0)
        base_time *= multiplier
    
    elif service_type == "home_services":
        property_multipliers = {
            "Small": 1.0,
            "Medium": 1.3,
            "Large": 1.6,
            "Extra Large": 2.0
        }
        multiplier = property_multipliers.get(details.get('property_size', 'Small'), 1.0)
        base_time *= multiplier
    
    return int(base_time)

def calculate_surge_pricing(base_price, service_type, time_of_day=None, demand_level="normal"):
    """Calculate surge pricing based on demand and time"""
    
    if time_of_day is None:
        time_of_day = datetime.now().hour
    
    # Peak hours (7-9 AM, 5-7 PM)
    is_peak_hour = (7 <= time_of_day <= 9) or (17 <= time_of_day <= 19)
    
    surge_multiplier = 1.0
    
    # Apply surge based on demand level
    if demand_level == "high":
        surge_multiplier = 1.3
    elif demand_level == "very_high":
        surge_multiplier = 1.5
    elif demand_level == "extreme":
        surge_multiplier = 2.0
    
    # Additional surge for peak hours
    if is_peak_hour and service_type == "ride_hailing":
        surge_multiplier *= 1.2
    
    # Weekend surge for certain services
    if datetime.now().weekday() >= 5:  # Saturday or Sunday
        if service_type in ["home_services", "moving_help"]:
            surge_multiplier *= 1.1
    
    surge_price = base_price * surge_multiplier
    
    return {
        'base_price': base_price,
        'surge_multiplier': surge_multiplier,
        'surge_price': surge_price,
        'is_surge': surge_multiplier > 1.0
    }

def validate_booking_details(service_type, details):
    """Validate booking details based on service type"""
    
    errors = []
    
    # Common validations
    if not details.get('location') and not (details.get('pickup') and details.get('dropoff')):
        errors.append("Location information is required")
    
    # Service-specific validations
    if service_type == "ride_hailing":
        if not details.get('pickup'):
            errors.append("Pickup location is required")
        if not details.get('dropoff'):
            errors.append("Drop-off location is required")
    
    elif service_type == "home_services":
        if not details.get('description'):
            errors.append("Service description is required")
        if not details.get('location'):
            errors.append("Service location is required")
    
    elif service_type == "moving_help":
        if not details.get('origin'):
            errors.append("Origin address is required")
        if not details.get('destination'):
            errors.append("Destination address is required")
    
    elif service_type == "other_tasks":
        if not details.get('description'):
            errors.append("Task description is required")
    
    return errors

def format_booking_summary(booking_details):
    """Format booking details for display"""
    
    summary = []
    service_type = booking_details.get('service_type', 'Unknown Service')
    
    summary.append(f"**Service:** {service_type}")
    
    # Add location information
    if booking_details.get('pickup') and booking_details.get('dropoff'):
        summary.append(f"**From:** {booking_details['pickup']}")
        summary.append(f"**To:** {booking_details['dropoff']}")
    elif booking_details.get('location'):
        summary.append(f"**Location:** {booking_details['location']}")
    elif booking_details.get('origin') and booking_details.get('destination'):
        summary.append(f"**From:** {booking_details['origin']}")
        summary.append(f"**To:** {booking_details['destination']}")
    
    # Add service-specific details
    if booking_details.get('vehicle_type'):
        summary.append(f"**Vehicle:** {booking_details['vehicle_type']}")
    
    if booking_details.get('category'):
        summary.append(f"**Category:** {booking_details['category']}")
    
    if booking_details.get('description'):
        summary.append(f"**Description:** {booking_details['description'][:100]}...")
    
    if booking_details.get('cost_estimate'):
        summary.append(f"**Estimated Cost:** {booking_details['cost_estimate']}")
    
    return '\n'.join(summary)

def get_booking_status_updates(booking_id, service_type):
    """Get status updates for a booking"""
    
    # Mock status updates based on service type
    updates = {
        "ride_hailing": [
            {"time": "2 min ago", "status": "Driver assigned", "message": "Mike is on the way"},
            {"time": "5 min ago", "status": "Ride confirmed", "message": "Your ride has been booked"},
        ],
        "delivery": [
            {"time": "10 min ago", "status": "Package picked up", "message": "Courier has your item"},
            {"time": "25 min ago", "status": "Courier assigned", "message": "Quick Courier is handling your delivery"},
        ],
        "home_services": [
            {"time": "1 hour ago", "status": "Provider confirmed", "message": "Mike's Lawn Service will arrive tomorrow at 10 AM"},
            {"time": "2 hours ago", "status": "Quotes received", "message": "3 providers have submitted quotes"},
        ]
    }
    
    return updates.get(service_type, [])
