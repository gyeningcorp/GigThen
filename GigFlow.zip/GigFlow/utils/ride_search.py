"""Real-time ride searching functionality"""
import streamlit as st
import time
from datetime import datetime, timedelta
import random
from database import get_db, Provider, Booking, User

def show_searching_for_driver():
    """Display real-time driver search interface"""
    
    # Initialize search state
    if 'search_start_time' not in st.session_state:
        st.session_state.search_start_time = time.time()
        st.session_state.driver_found = False
        st.session_state.search_attempts = 0
    
    # Calculate search duration
    search_duration = time.time() - st.session_state.search_start_time
    max_search_time = 180  # 3 minutes in seconds
    
    # Container for the search UI
    search_container = st.container()
    
    with search_container:
        # Header
        st.markdown("""
        <div style='text-align: center; padding: 20px;'>
            <h2 style='margin-bottom: 10px;'>🚗 Finding Your Driver</h2>
            <p style='color: #666; margin: 0;'>Searching for available drivers nearby...</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Show booking details
        if 'booking_details' in st.session_state:
            details = st.session_state.booking_details
            
            # Price display (cheaper than Uber)
            base_fare = 1.50  # Lower than Uber's typical $2.50
            per_mile = 0.90   # Lower than Uber's typical $1.50
            per_minute = 0.20  # Lower than Uber's typical $0.30
            
            # Calculate estimated price
            distance = details.get('distance', 5)
            duration = details.get('duration', 15)
            estimated_price = base_fare + (per_mile * distance) + (per_minute * duration)
            
            st.markdown(f"""
            <div style='background: #f8f9fa; border-radius: 12px; padding: 20px; margin: 20px 0;'>
                <div style='margin-bottom: 15px;'>
                    <div style='color: #666; font-size: 14px;'>Pickup</div>
                    <div style='font-weight: 500;'>📍 {details.get('pickup', 'Current Location')}</div>
                </div>
                <div style='margin-bottom: 15px;'>
                    <div style='color: #666; font-size: 14px;'>Dropoff</div>
                    <div style='font-weight: 500;'>📍 {details.get('dropoff', 'Destination')}</div>
                </div>
                <div style='border-top: 1px solid #dee2e6; padding-top: 15px; margin-top: 15px;'>
                    <div style='display: flex; justify-content: space-between; align-items: center;'>
                        <div>
                            <div style='color: #666; font-size: 14px;'>Estimated Fare</div>
                            <div style='font-size: 24px; font-weight: bold; color: #28a745;'>
                                ${estimated_price:.2f}
                            </div>
                            <div style='color: #28a745; font-size: 12px;'>
                                💰 Save ~30% vs Uber
                            </div>
                        </div>
                        <div style='text-align: right;'>
                            <div style='color: #666; font-size: 14px;'>Distance</div>
                            <div style='font-weight: 500;'>{distance} miles</div>
                            <div style='color: #666; font-size: 14px; margin-top: 5px;'>Duration</div>
                            <div style='font-weight: 500;'>~{duration} mins</div>
                        </div>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)
        
        # Animated search indicator
        search_progress = st.empty()
        status_message = st.empty()
        
        # Search animation frames
        search_messages = [
            "🔍 Looking for nearby drivers...",
            "📡 Connecting to available drivers...",
            "🚗 Finding the best driver for you...",
            "⏳ Almost there...",
            "🎯 Matching you with a driver..."
        ]
        
        # Display animated search
        message_index = int((search_duration / 2) % len(search_messages))
        
        # Progress bar
        progress = min(search_duration / max_search_time, 0.95)
        search_progress.progress(progress)
        
        # Status message
        status_message.markdown(f"""
        <div style='text-align: center; margin: 20px 0;'>
            <div style='font-size: 18px; color: #667eea; margin-bottom: 10px;'>
                {search_messages[message_index]}
            </div>
            <div style='color: #999; font-size: 14px;'>
                Searching for {int(search_duration)} seconds...
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        # Check for driver acceptance
        db = next(get_db())
        
        # Look for accepted booking
        if 'current_booking_id' in st.session_state:
            booking = db.query(Booking).filter_by(
                id=st.session_state.current_booking_id
            ).first()
            
            if booking and booking.status == 'accepted' and booking.provider_id:
                # Driver found!
                st.session_state.driver_found = True
                provider = db.query(Provider).filter_by(id=booking.provider_id).first()
                
                if provider:
                    user = db.query(User).filter_by(id=provider.user_id).first()
                    driver_name = user.name if user else "Your Driver"
                    
                    st.balloons()
                    st.success("🎉 Driver found!")
                    
                    st.markdown(f"""
                    <div style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                                color: white; border-radius: 12px; padding: 20px; margin: 20px 0;'>
                        <h3 style='color: white; margin-bottom: 15px;'>Driver Accepted!</h3>
                        <div style='display: flex; align-items: center; gap: 15px;'>
                            <div style='width: 60px; height: 60px; background: white; border-radius: 50%; 
                                        display: flex; align-items: center; justify-content: center; font-size: 30px;'>
                                🚗
                            </div>
                            <div style='flex: 1;'>
                                <div style='font-size: 18px; font-weight: bold;'>{driver_name}</div>
                                <div style='opacity: 0.9;'>⭐ {provider.rating} rating • {provider.total_jobs} trips</div>
                                <div style='opacity: 0.9; margin-top: 5px;'>Arriving in ~5 minutes</div>
                            </div>
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    # Action buttons
                    col1, col2 = st.columns(2)
                    with col1:
                        if st.button("📞 Contact Driver", use_container_width=True):
                            st.info("Calling driver...")
                    with col2:
                        if st.button("📍 Track Driver", use_container_width=True):
                            st.session_state.stage = 'driver_tracking'
                            st.rerun()
                    
                    # Cancel button
                    if st.button("Cancel Ride", use_container_width=True, type="secondary"):
                        booking.status = 'cancelled'
                        db.commit()
                        st.session_state.stage = 'home'
                        st.rerun()
                    
                    return True
        
        # After 3 minutes, show no drivers available
        if search_duration >= max_search_time:
            st.error("😔 No drivers available")
            st.markdown("""
            <div style='text-align: center; padding: 20px;'>
                <p style='color: #666; margin-bottom: 20px;'>
                    We couldn't find any available drivers in your area right now. 
                    Please try again in a few minutes.
                </p>
            </div>
            """, unsafe_allow_html=True)
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("🔄 Search Again", use_container_width=True):
                    # Reset search
                    del st.session_state.search_start_time
                    st.rerun()
            with col2:
                if st.button("🏠 Back to Home", use_container_width=True):
                    st.session_state.stage = 'home'
                    st.rerun()
            
            return False
        
        # Cancel search button
        st.markdown("<div style='margin-top: 30px;'>", unsafe_allow_html=True)
        if st.button("Cancel Search", use_container_width=True, type="secondary"):
            if 'current_booking_id' in st.session_state:
                booking = db.query(Booking).filter_by(
                    id=st.session_state.current_booking_id
                ).first()
                if booking:
                    booking.status = 'cancelled'
                    db.commit()
            st.session_state.stage = 'home'
            st.rerun()
        st.markdown("</div>", unsafe_allow_html=True)
        
        # Auto-refresh every 2 seconds
        time.sleep(2)
        st.rerun()
    
    return False