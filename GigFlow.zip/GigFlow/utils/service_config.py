"""Unified service configuration for customers and providers"""

# Master service configuration - single source of truth
SERVICES = {
    "ride_hailing": {
        "name": "Ride",
        "icon": "🚗",
        "color": "#667eea",
        "provider_name": "Driver",
        "description": "Get a ride anywhere in the city",
        "base_price": 15,
        "subtypes": []
    },
    "delivery": {
        "name": "Delivery",
        "icon": "📦",
        "color": "#764ba2",
        "provider_name": "Delivery Driver",
        "description": "Package and parcel delivery",
        "base_price": 12,
        "subtypes": ["package", "document", "express"]
    },
    "grocery": {
        "name": "Grocery",
        "icon": "🛒",
        "color": "#42a5f5",
        "provider_name": "Grocery Shopper",
        "description": "Personal grocery shopping service",
        "base_price": 20,
        "subtypes": []
    },
    "marketplace": {
        "name": "Marketplace",
        "icon": "🏪",
        "color": "#66bb6a",
        "provider_name": "Marketplace Pickup",
        "description": "Facebook Marketplace and Craigslist pickups",
        "base_price": 30,
        "subtypes": []
    },
    "lawn_care": {
        "name": "Lawn Care",
        "icon": "🌿",
        "color": "#4caf50",
        "provider_name": "Lawn Care Specialist",
        "description": "Lawn mowing and yard maintenance",
        "base_price": 60,
        "subtypes": ["mowing", "trimming", "leaf_removal"]
    },
    "home_services": {
        "name": "Home Services",
        "icon": "🏠",
        "color": "#f06292",
        "provider_name": "Home Service Pro",
        "description": "Cleaning, repairs, and maintenance",
        "base_price": 80,
        "subtypes": ["cleaning", "handyman", "painting", "plumbing", "electrical"]
    },
    "moving_help": {
        "name": "Moving",
        "icon": "🚚",
        "color": "#ff9800",
        "provider_name": "Moving Helper",
        "description": "Moving and heavy lifting assistance",
        "base_price": 100,
        "subtypes": ["full_move", "loading", "furniture"]
    },
    "other_tasks": {
        "name": "Custom Tasks",
        "icon": "✋",
        "color": "#9c27b0",
        "provider_name": "Task Helper",
        "description": "Any task you need help with",
        "base_price": 35,
        "subtypes": []
    }
}

def get_customer_services():
    """Get services formatted for customer view"""
    return [(
        service['icon'],
        service['name'],
        key,
        service['color']
    ) for key, service in SERVICES.items()]

def get_provider_services():
    """Get services formatted for provider view"""
    return {
        f"{service['icon']} {service['provider_name']}": key
        for key, service in SERVICES.items()
    }

def get_service_details(service_key):
    """Get details for a specific service"""
    return SERVICES.get(service_key, SERVICES['other_tasks'])

def format_service_name(service_key):
    """Format service key into display name"""
    service = SERVICES.get(service_key)
    if service:
        return f"{service['icon']} {service['name']}"
    return service_key.replace('_', ' ').title()

def get_provider_display_name(service_key):
    """Get provider-facing display name for service"""
    service = SERVICES.get(service_key)
    if service:
        return f"{service['icon']} {service['provider_name']}"
    return service_key.replace('_', ' ').title()