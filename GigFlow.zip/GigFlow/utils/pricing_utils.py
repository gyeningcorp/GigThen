"""
Pittsburgh Pricing Model for AllServ Platform
Based on competitive market research and 20% platform commission
"""

def calculate_ride_fare(distance_miles=4.2, time_minutes=15, vehicle_type="Standard", surge_multiplier=1.0):
    """Calculate ride fare using Pittsburgh pricing model"""
    # Base fare + per mile + per minute
    base_fare = 2.50
    ride_fare = base_fare + (distance_miles * 1.50) + (time_minutes * 0.30)
    
    # Vehicle type multipliers
    multipliers = {
        "Standard": 1.0,
        "Premium": 1.4,
        "XL (6+ passengers)": 1.6,
        "Wheelchair Accessible": 1.3
    }
    
    ride_fare *= multipliers.get(vehicle_type, 1.0)
    ride_fare *= surge_multiplier
    
    # Platform commission (20%)
    provider_payout = ride_fare * 0.80
    
    return {
        "customer_price": ride_fare,
        "provider_payout": provider_payout,
        "platform_commission": ride_fare - provider_payout,
        "breakdown": {
            "base_fare": base_fare,
            "distance_charge": distance_miles * 1.50,
            "time_charge": time_minutes * 0.30,
            "multiplier": multipliers.get(vehicle_type, 1.0),
            "surge": surge_multiplier
        }
    }

def calculate_delivery_cost(distance_miles=4.0, item_size="Small (fits in car)", urgency="Standard"):
    """Calculate delivery cost using Pittsburgh pricing model"""
    # Base fee + per mile
    base_fee = 6.00
    delivery_cost = base_fee + (distance_miles * 1.20)
    
    # Size surcharges
    size_fees = {
        "Small (fits in car)": 0,
        "Medium (SUV needed)": 3.00,
        "Large (truck needed)": 8.00
    }
    
    delivery_cost += size_fees.get(item_size, 0)
    
    # Urgency surge pricing
    if urgency == "ASAP":
        delivery_cost *= 1.35
    
    # Platform commission (20%)
    provider_payout = delivery_cost * 0.80
    
    return {
        "customer_price": delivery_cost,
        "provider_payout": provider_payout,
        "platform_commission": delivery_cost - provider_payout,
        "breakdown": {
            "base_fee": base_fee,
            "distance_charge": distance_miles * 1.20,
            "size_fee": size_fees.get(item_size, 0),
            "urgency_multiplier": 1.35 if urgency == "ASAP" else 1.0
        }
    }

def calculate_home_service_cost(service_category, property_size):
    """Calculate home service cost using Pittsburgh flat rate model"""
    service_rates = {
        "Lawn Care": {"Small": 35, "Medium": 45, "Large": 65, "Commercial": 150},
        "Cleaning": {"Small": 80, "Medium": 120, "Large": 180, "Commercial": 300},
        "Handyman": {"Small": 85, "Medium": 125, "Large": 200, "Commercial": 350},
        "Gardening": {"Small": 40, "Medium": 60, "Large": 90, "Commercial": 200},
        "Snow Removal": {"Small": 30, "Medium": 45, "Large": 70, "Commercial": 150},
        "Pressure Washing": {"Small": 120, "Medium": 180, "Large": 250, "Commercial": 450},
        "Gutter Cleaning": {"Small": 90, "Medium": 130, "Large": 200, "Commercial": 350}
    }
    
    customer_price = service_rates.get(service_category, {"Small": 50, "Medium": 75, "Large": 125, "Commercial": 250})[property_size]
    
    # Platform commission (18% for home services)
    provider_payout = customer_price * 0.82
    
    return {
        "customer_price": customer_price,
        "provider_payout": provider_payout,
        "platform_commission": customer_price - provider_payout
    }

def calculate_moving_cost(home_size, moving_type, distance_miles=8.0, extras=None):
    """Calculate moving cost using Pittsburgh model: booking fee + hourly labor + transport"""
    if extras is None:
        extras = {}
    
    # Base pricing
    booking_fee = 20.00 if moving_type != "Labor Only (I have truck)" else 0
    hourly_rate = 35.00  # per person
    
    # Estimate hours and team size based on home size
    estimates = {
        "Studio/1BR": {"hours": 2.0, "team": 2},
        "2BR": {"hours": 3.0, "team": 2},
        "3BR": {"hours": 4.0, "team": 3},
        "4+ BR": {"hours": 6.0, "team": 3},
        "Commercial": {"hours": 8.0, "team": 4}
    }
    
    est = estimates.get(home_size, {"hours": 3.0, "team": 2})
    labor_cost = hourly_rate * est["team"] * est["hours"]
    transport_cost = distance_miles * 1.50 if moving_type != "Labor Only (I have truck)" else 0
    
    # Base total
    total_cost = booking_fee + labor_cost + transport_cost
    
    # Add extras
    if extras.get("stairs"):
        total_cost += 50
    if extras.get("piano"):
        total_cost += 150
    if extras.get("long_carry"):
        total_cost += 75
    if extras.get("assembly"):
        total_cost += 100
    
    # Platform commission (16% for moving)
    provider_payout = total_cost * 0.84
    
    return {
        "customer_price": total_cost,
        "provider_payout": provider_payout,
        "platform_commission": total_cost - provider_payout,
        "breakdown": {
            "booking_fee": booking_fee,
            "labor_cost": labor_cost,
            "transport_cost": transport_cost,
            "extras": total_cost - booking_fee - labor_cost - transport_cost
        }
    }

def calculate_task_cost(task_category, estimated_hours=2.0):
    """Calculate task cost using Pittsburgh hourly model"""
    hourly_rates = {
        "Furniture Assembly": 25,
        "Tech Setup": 30,
        "Pet Services": 20,
        "Errands & Shopping": 18,
        "Organization": 22,
        "Event Help": 20,
        "Custom Task": 25
    }
    
    hourly_rate = hourly_rates.get(task_category, 25)
    customer_price = hourly_rate * estimated_hours
    
    # Platform commission (22% for other tasks)
    provider_payout = customer_price * 0.78
    
    return {
        "customer_price": customer_price,
        "provider_payout": provider_payout,
        "platform_commission": customer_price - provider_payout,
        "hourly_rate": hourly_rate
    }

def get_pricing_summary():
    """Return pricing summary for Pittsburgh market"""
    return {
        "ride_example": "5 miles, 15 min = $12.75 (provider gets $10.20)",
        "delivery_example": "4 miles = $10.80 (provider gets $8.64)",
        "marketplace_pickup": "8 miles = $32 (provider gets $25.60)",
        "moving_help": "2 movers, 2 hrs, 5 mi = $150 (provider gets $120)",
        "lawn_care_small": "Medium yard = $45 (provider gets $36)",
        "general_chores": "2 hrs = $50 (provider gets $40)",
        "platform_commission": "16-22% depending on service type",
        "tips": "100% go to provider"
    }