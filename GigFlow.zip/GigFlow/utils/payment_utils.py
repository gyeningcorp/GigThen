"""
Payment utilities using Stripe for AllServ marketplace
"""
import stripe
import os
from typing import Dict, Optional
import streamlit as st

# Initialize Stripe
stripe.api_key = os.environ.get('STRIPE_SECRET_KEY')
STRIPE_PUBLISHABLE_KEY = os.environ.get('STRIPE_PUBLISHABLE_KEY')

class PaymentProcessor:
    """Handle Stripe payments for the marketplace"""
    
    def __init__(self):
        self.stripe_publishable_key = STRIPE_PUBLISHABLE_KEY
    
    def create_payment_intent(self, amount_cents: int, customer_email: str, 
                            provider_email: str, booking_id: str, 
                            service_type: str) -> Optional[Dict]:
        """
        Create a Stripe Payment Intent for marketplace payment
        Amount should be in cents (e.g., $10.00 = 1000 cents)
        """
        try:
            # Calculate application fee (AllServ commission: 16-22% depending on service)
            fee_percentage = self._get_fee_percentage(service_type)
            application_fee = int(amount_cents * fee_percentage)
            
            payment_intent = stripe.PaymentIntent.create(
                amount=amount_cents,
                currency='usd',
                application_fee_amount=application_fee,
                metadata={
                    'booking_id': booking_id,
                    'customer_email': customer_email,
                    'provider_email': provider_email,
                    'service_type': service_type,
                    'platform': 'AllServ'
                },
                description=f"AllServ {service_type.replace('_', ' ').title()} Service - Booking #{booking_id}"
            )
            
            return {
                'client_secret': payment_intent.client_secret,
                'payment_intent_id': payment_intent.id,
                'amount': amount_cents,
                'application_fee': application_fee,
                'provider_amount': amount_cents - application_fee
            }
            
        except stripe.error.StripeError as e:
            st.error(f"Payment setup failed: {str(e)}")
            return None
    
    def _get_fee_percentage(self, service_type: str) -> float:
        """Get AllServ commission percentage based on service type"""
        fee_rates = {
            'ride_hailing': 0.20,      # 20% (provider gets 80%)
            'deliveries': 0.20,        # 20% (provider gets 80%)
            'home_services': 0.18,     # 18% (provider gets 82%)
            'moving_help': 0.16,       # 16% (provider gets 84%)
            'other_tasks': 0.22        # 22% (provider gets 78%)
        }
        return fee_rates.get(service_type, 0.20)  # Default 20%
    
    def confirm_payment(self, payment_intent_id: str) -> bool:
        """Confirm payment was successful"""
        try:
            payment_intent = stripe.PaymentIntent.retrieve(payment_intent_id)
            return payment_intent.status == 'succeeded'
        except stripe.error.StripeError:
            return False
    
    def create_payout_account(self, provider_email: str, provider_name: str) -> Optional[str]:
        """Create Stripe Express account for provider payouts (simplified)"""
        try:
            account = stripe.Account.create(
                type='express',
                email=provider_email,
                capabilities={
                    'transfers': {'requested': True},
                },
                business_type='individual',
                metadata={
                    'provider_email': provider_email,
                    'provider_name': provider_name,
                    'platform': 'AllServ'
                }
            )
            return account.id
        except stripe.error.StripeError as e:
            st.error(f"Failed to create payout account: {str(e)}")
            return None
    
    def get_account_link(self, account_id: str, refresh_url: str, return_url: str) -> Optional[str]:
        """Get onboarding link for Stripe Express account"""
        try:
            account_link = stripe.AccountLink.create(
                account=account_id,
                refresh_url=refresh_url,
                return_url=return_url,
                type='account_onboarding',
            )
            return account_link.url
        except stripe.error.StripeError as e:
            st.error(f"Failed to create account link: {str(e)}")
            return None

def format_currency(amount_cents: int) -> str:
    """Format cents to currency string"""
    return f"${amount_cents / 100:.2f}"

def calculate_pricing_breakdown(total_amount: float, service_type: str) -> Dict:
    """Calculate pricing breakdown showing customer total, provider earnings, and platform fee"""
    amount_cents = int(total_amount * 100)
    processor = PaymentProcessor()
    fee_percentage = processor._get_fee_percentage(service_type)
    
    platform_fee = int(amount_cents * fee_percentage)
    provider_earnings = amount_cents - platform_fee
    
    return {
        'customer_total': amount_cents,
        'provider_earnings': provider_earnings,
        'platform_fee': platform_fee,
        'fee_percentage': fee_percentage * 100
    }