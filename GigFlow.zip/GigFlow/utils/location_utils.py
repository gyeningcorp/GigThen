import streamlit as st
import plotly.graph_objects as go
import pandas as pd

def create_route_map(pickup_lat, pickup_lng, dropoff_lat, dropoff_lng):
    """Create a route map between pickup and dropoff locations"""
    
    fig = go.Figure()
    
    # Add pickup marker
    fig.add_trace(go.Scattermapbox(
        lat=[pickup_lat],
        lon=[pickup_lng],
        mode='markers',
        marker=dict(size=15, color='red'),
        text=['Pickup Location'],
        name="Pickup"
    ))
    
    # Add dropoff marker
    fig.add_trace(go.Scattermapbox(
        lat=[dropoff_lat],
        lon=[dropoff_lng], 
        mode='markers',
        marker=dict(size=15, color='green'),
        text=['Dropoff Location'],
        name="Dropoff"
    ))
    
    # Add route line
    fig.add_trace(go.Scattermapbox(
        lat=[pickup_lat, dropoff_lat],
        lon=[pickup_lng, dropoff_lng],
        mode='lines',
        line=dict(width=3, color='blue'),
        name="Route"
    ))
    
    # Calculate center point for map
    center_lat = (pickup_lat + dropoff_lat) / 2
    center_lng = (pickup_lng + dropoff_lng) / 2
    
    fig.update_layout(
        mapbox=dict(
            style="open-street-map",
            center=dict(lat=center_lat, lon=center_lng),
            zoom=12
        ),
        height=400,
        margin=dict(l=0, r=0, t=0, b=0),
        showlegend=True
    )
    
    return fig

def create_service_area_map(center_lat=40.4406, center_lng=-79.9959, zoom=11):
    """Create a map showing service coverage area"""
    
    fig = go.Figure()
    
    # Add center marker
    fig.add_trace(go.Scattermapbox(
        lat=[center_lat],
        lon=[center_lng],
        mode='markers',
        marker=dict(size=20, color='blue'),
        text=['Service Center'],
        name="Coverage Center"
    ))
    
    # Add coverage circle (approximate)
    circle_points = []
    import math
    radius = 0.1  # Approximate radius in degrees
    
    for i in range(0, 361, 10):
        angle = math.radians(i)
        lat = center_lat + radius * math.cos(angle)
        lng = center_lng + radius * math.sin(angle)
        circle_points.append((lat, lng))
    
    circle_lats, circle_lngs = zip(*circle_points)
    
    fig.add_trace(go.Scattermapbox(
        lat=circle_lats,
        lon=circle_lngs,
        mode='lines',
        line=dict(width=2, color='blue'),
        fill='tonext',
        fillcolor='rgba(0,100,255,0.1)',
        name="Service Area"
    ))
    
    fig.update_layout(
        mapbox=dict(
            style="open-street-map",
            center=dict(lat=center_lat, lon=center_lng),
            zoom=zoom
        ),
        height=400,
        margin=dict(l=0, r=0, t=0, b=0)
    )
    
    return fig

def calculate_distance(lat1, lng1, lat2, lng2):
    """Calculate approximate distance between two points in miles"""
    import math
    
    # Convert to radians
    lat1, lng1, lat2, lng2 = map(math.radians, [lat1, lng1, lat2, lng2])
    
    # Haversine formula
    dlat = lat2 - lat1
    dlng = lng2 - lng1
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlng/2)**2
    c = 2 * math.asin(math.sqrt(a))
    
    # Earth radius in miles
    r = 3956
    
    return c * r

def calculate_eta(distance_miles, service_type="ride"):
    """Calculate estimated time of arrival based on distance and service type"""
    
    # Average speeds by service type (mph)
    speeds = {
        "ride": 25,        # City driving
        "delivery": 20,    # Includes stops
        "service": 30      # Direct travel
    }
    
    speed = speeds.get(service_type, 25)
    time_hours = distance_miles / speed
    time_minutes = time_hours * 60
    
    # Add buffer time
    buffer = 5 if service_type == "ride" else 10
    
    return int(time_minutes + buffer)

def get_pittsburgh_neighborhoods():
    """Return list of Pittsburgh neighborhoods for location suggestions"""
    return [
        "Downtown", "Oakland", "Shadyside", "Squirrel Hill", "Lawrenceville",
        "Strip District", "South Side", "Mount Washington", "East Liberty",
        "Bloomfield", "Polish Hill", "Troy Hill", "North Side", "Greenfield",
        "Friendship", "Garfield", "Highland Park", "Point Breeze", "Regent Square",
        "Brookline", "Dormont", "Bethel Park", "Upper St. Clair", "Mt. Lebanon"
    ]

def validate_pittsburgh_address(address):
    """Basic validation for Pittsburgh area addresses"""
    if not address:
        return False
    
    pittsburgh_indicators = [
        "pittsburgh", "pgh", "pa", "pennsylvania", "15", "412"
    ]
    
    address_lower = address.lower()
    
    # Check if address contains Pittsburgh indicators
    for indicator in pittsburgh_indicators:
        if indicator in address_lower:
            return True
    
    # Check neighborhoods
    neighborhoods = get_pittsburgh_neighborhoods()
    for neighborhood in neighborhoods:
        if neighborhood.lower() in address_lower:
            return True
    
    return True  # Default to true for demo purposes

def create_provider_tracking_map(provider_lat, provider_lng, customer_lat, customer_lng):
    """Create a live tracking map showing provider and customer locations"""
    
    fig = go.Figure()
    
    # Add provider marker (moving)
    fig.add_trace(go.Scattermapbox(
        lat=[provider_lat],
        lon=[provider_lng],
        mode='markers',
        marker=dict(size=20, color='blue', symbol='car'),
        text=['Service Provider'],
        name="Provider"
    ))
    
    # Add customer marker (stationary)
    fig.add_trace(go.Scattermapbox(
        lat=[customer_lat],
        lon=[customer_lng],
        mode='markers',
        marker=dict(size=15, color='red', symbol='circle'),
        text=['Your Location'],
        name="You"
    ))
    
    # Add route line
    fig.add_trace(go.Scattermapbox(
        lat=[provider_lat, customer_lat],
        lon=[provider_lng, customer_lng],
        mode='lines',
        line=dict(width=2, color='green', dash='dash'),
        name="Route to You"
    ))
    
    # Center map between provider and customer
    center_lat = (provider_lat + customer_lat) / 2
    center_lng = (provider_lng + customer_lng) / 2
    
    fig.update_layout(
        mapbox=dict(
            style="open-street-map",
            center=dict(lat=center_lat, lon=center_lng),
            zoom=14
        ),
        height=300,
        margin=dict(l=0, r=0, t=0, b=0)
    )
    
    return fig
