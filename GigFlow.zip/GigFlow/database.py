"""
Database setup and models for AllServ Platform
"""
import os
from datetime import datetime
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Boolean, Text, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from sqlalchemy.sql import func

# Database connection
DATABASE_URL = os.environ.get('DATABASE_URL')
if DATABASE_URL and DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)

# Use connection pooling for better stability
if DATABASE_URL:
    engine = create_engine(
        DATABASE_URL,
        pool_pre_ping=True,
        pool_recycle=300,
        connect_args={
            "connect_timeout": 10,
            "options": "-c statement_timeout=30000"
        }
    )
else:
    engine = create_engine('sqlite:///allserv.db')

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Models
class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    name = Column(String)
    phone = Column(String)
    password_hash = Column(String)  # Added for authentication
    user_type = Column(String)  # 'customer' or 'provider'
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    customer_bookings = relationship("Booking", back_populates="customer", foreign_keys="Booking.customer_id")
    provider_bookings = relationship("Booking", back_populates="provider", foreign_keys="Booking.provider_id")
    provider_profile = relationship("Provider", back_populates="user", uselist=False)

class Provider(Base):
    __tablename__ = "providers"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True)
    services = Column(Text)  # JSON string of services offered
    vehicle_type = Column(String)
    vehicle_info = Column(String)
    rating = Column(Float, default=5.0)
    total_jobs = Column(Integer, default=0)
    is_available = Column(Boolean, default=True)
    current_lat = Column(Float)
    current_lng = Column(Float)
    
    # Relationships
    user = relationship("User", back_populates="provider_profile")

class Booking(Base):
    __tablename__ = "bookings"
    
    id = Column(Integer, primary_key=True, index=True)
    booking_id = Column(String, unique=True, index=True)
    customer_id = Column(Integer, ForeignKey("users.id"))
    provider_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    
    service_type = Column(String)
    status = Column(String, default="pending")  # pending, accepted, en_route, arrived, completed, cancelled
    
    # Location info
    pickup_address = Column(String)
    pickup_lat = Column(Float)
    pickup_lng = Column(Float)
    dropoff_address = Column(String, nullable=True)
    dropoff_lat = Column(Float, nullable=True)
    dropoff_lng = Column(Float, nullable=True)
    
    # Service details
    service_details = Column(Text)  # JSON string
    
    # Pricing
    estimated_price = Column(Float)
    final_price = Column(Float, nullable=True)
    provider_payout = Column(Float, nullable=True)
    platform_fee = Column(Float, nullable=True)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    accepted_at = Column(DateTime, nullable=True)
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    
    # Relationships
    customer = relationship("User", back_populates="customer_bookings", foreign_keys=[customer_id])
    provider = relationship("User", back_populates="provider_bookings", foreign_keys=[provider_id])
    notifications = relationship("Notification", back_populates="booking")

class Notification(Base):
    __tablename__ = "notifications"
    
    id = Column(Integer, primary_key=True, index=True)
    booking_id = Column(Integer, ForeignKey("bookings.id"))
    user_id = Column(Integer, ForeignKey("users.id"))
    message = Column(String)
    notification_type = Column(String)  # info, success, warning, error
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    booking = relationship("Booking", back_populates="notifications")

# Create tables
Base.metadata.create_all(bind=engine)

# Helper functions
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def init_sample_providers():
    """Initialize sample providers for testing"""
    db = SessionLocal()
    
    # Check if providers exist
    existing = db.query(Provider).first()
    if existing:
        db.close()
        return
    
    import hashlib
    
    # Sample providers
    providers_data = [
        {
            "name": "Mike Rodriguez",
            "email": "mike@allserv.com",
            "phone": "412-555-0101",
            "password": "provider123",
            "services": '["ride_hailing", "deliveries"]',
            "vehicle_type": "Standard",
            "vehicle_info": "Toyota Camry - Gray - ABC 123",
            "rating": 4.9,
            "total_jobs": 127,
            "lat": 40.4506,
            "lng": -79.9856
        },
        {
            "name": "Sarah Johnson",
            "email": "sarah@allserv.com",
            "phone": "412-555-0102",
            "password": "provider123",
            "services": '["ride_hailing", "moving_help"]',
            "vehicle_type": "XL",
            "vehicle_info": "Honda Pilot - Black - XYZ 456",
            "rating": 4.8,
            "total_jobs": 89,
            "lat": 40.4356,
            "lng": -79.9756
        },
        {
            "name": "David Chen",
            "email": "david@allserv.com",
            "phone": "412-555-0103",
            "password": "provider123",
            "services": '["home_services", "other_tasks"]',
            "vehicle_type": None,
            "vehicle_info": None,
            "rating": 4.95,
            "total_jobs": 203,
            "lat": 40.4456,
            "lng": -80.0056
        },
        {
            "name": "Maria Garcia",
            "email": "maria@allserv.com",
            "phone": "412-555-0104",
            "password": "provider123",
            "services": '["deliveries", "errands"]',
            "vehicle_type": "Standard",
            "vehicle_info": "Nissan Altima - Silver - DEF 789",
            "rating": 4.7,
            "total_jobs": 156,
            "lat": 40.4606,
            "lng": -79.9956
        },
        {
            "name": "James Wilson",
            "email": "james@allserv.com",
            "phone": "412-555-0105",
            "password": "provider123",
            "services": '["moving_help", "deliveries"]',
            "vehicle_type": "Truck",
            "vehicle_info": "Ford F-150 - White - GHI 012",
            "rating": 4.85,
            "total_jobs": 94,
            "lat": 40.4306,
            "lng": -79.9656
        }
    ]
    
    for provider_data in providers_data:
        # Create user
        user = User(
            email=provider_data["email"],
            name=provider_data["name"],
            phone=provider_data["phone"],
            password_hash=hashlib.sha256(provider_data["password"].encode()).hexdigest(),
            user_type="provider"
        )
        db.add(user)
        db.flush()
        
        # Create provider profile
        provider = Provider(
            user_id=user.id,
            services=provider_data["services"],
            vehicle_type=provider_data["vehicle_type"],
            vehicle_info=provider_data["vehicle_info"],
            rating=provider_data["rating"],
            total_jobs=provider_data["total_jobs"],
            is_available=True,
            current_lat=provider_data["lat"],
            current_lng=provider_data["lng"]
        )
        db.add(provider)
    
    db.commit()
    db.close()
    print("Sample providers initialized")

if __name__ == "__main__":
    init_sample_providers()