import hashlib

# Calculate the password hash the same way the app does
password = "password123"
password_hash = hashlib.sha256(password.encode()).hexdigest()
print(f"Password hash for 'password123': {password_hash}")