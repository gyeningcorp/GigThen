"""GigThen-style provider dashboard with modern UI"""
import streamlit as st
import random
import time
from datetime import datetime, timedelta
from database import get_db, User, Provider, Booking, Notification
from utils.service_config import SERVICES
import json

# Page config
st.set_page_config(
    page_title="GigThen Provider",
    page_icon="🚗",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Custom CSS for GigThen style
st.markdown("""
<style>
    /* Main container */
    .stApp {
        background: #f8f9fa;
    }
    
    /* Remove padding */
    .block-container {
        padding: 0 !important;
        max-width: 428px !important;
        margin: 0 auto;
    }
    
    /* Header style */
    .gig-header {
        background: white;
        padding: 20px;
        text-align: center;
        border-bottom: 1px solid #e0e0e0;
        position: relative;
    }
    
    .gig-header h1 {
        font-size: 24px;
        font-weight: 600;
        margin: 0;
        color: #1a1a1a;
    }
    
    /* Welcome section */
    .welcome-section {
        background: white;
        padding: 20px;
        margin-bottom: 10px;
    }
    
    .welcome-section h2 {
        font-size: 28px;
        font-weight: 700;
        margin: 0 0 10px 0;
        color: #1a1a1a;
    }
    
    .location-box {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 12px 16px;
        background: #f8f9fa;
        border-radius: 12px;
        margin-top: 15px;
        cursor: pointer;
    }
    
    .location-box:hover {
        background: #e9ecef;
    }
    
    /* Service cards */
    .service-card {
        background: white;
        border-radius: 20px;
        padding: 0;
        margin: 10px 15px;
        overflow: hidden;
        box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        cursor: pointer;
        transition: transform 0.2s;
    }
    
    .service-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 20px rgba(0,0,0,0.12);
    }
    
    .service-card-image {
        width: 100%;
        height: 180px;
        background-size: cover;
        background-position: center;
        position: relative;
    }
    
    .service-card-content {
        padding: 15px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .service-card-title {
        font-size: 20px;
        font-weight: 600;
        color: #1a1a1a;
        margin: 0;
    }
    
    .service-card-icon {
        width: 40px;
        height: 40px;
        background: #f0f0f0;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
    }
    
    /* Bottom navigation */
    .bottom-nav {
        position: fixed;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
        width: 100%;
        max-width: 428px;
        background: white;
        border-top: 1px solid #e0e0e0;
        padding: 8px 0;
        z-index: 1000;
    }
    
    .nav-item {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 4px;
        padding: 8px;
        cursor: pointer;
    }
    
    .nav-item.active {
        color: #007AFF;
    }
    
    .nav-icon {
        font-size: 24px;
    }
    
    .nav-label {
        font-size: 11px;
        color: #666;
    }
    
    .nav-item.active .nav-label {
        color: #007AFF;
    }
    
    /* Profile avatar */
    .profile-avatar {
        position: absolute;
        right: 20px;
        top: 20px;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: linear-gradient(135deg, #667eea, #764ba2);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: 600;
        cursor: pointer;
    }
    
    /* Notification bell */
    .notification-bell {
        position: absolute;
        right: 70px;
        top: 20px;
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        font-size: 20px;
    }
    
    /* Hide Streamlit elements */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    
    /* Service images backgrounds */
    .ride-bg {
        background: linear-gradient(rgba(0,0,0,0.2), rgba(0,0,0,0.2)), 
                    linear-gradient(135deg, #667eea, #764ba2);
    }
    
    .delivery-bg {
        background: linear-gradient(rgba(0,0,0,0.2), rgba(0,0,0,0.2)),
                    linear-gradient(135deg, #f093fb, #f5576c);
    }
    
    .tasks-bg {
        background: linear-gradient(rgba(0,0,0,0.2), rgba(0,0,0,0.2)),
                    linear-gradient(135deg, #4facfe, #00f2fe);
    }
    
    .grocery-bg {
        background: linear-gradient(rgba(0,0,0,0.2), rgba(0,0,0,0.2)),
                    linear-gradient(135deg, #43e97b, #38f9d7);
    }
    
    /* Status badge */
    .status-badge {
        position: absolute;
        top: 10px;
        right: 10px;
        background: rgba(255,255,255,0.95);
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
    }
    
    .status-online {
        color: #00c853;
    }
    
    .status-offline {
        color: #ff5252;
    }
    
    /* Earnings card */
    .earnings-card {
        background: linear-gradient(135deg, #667eea, #764ba2);
        color: white;
        padding: 20px;
        border-radius: 16px;
        margin: 15px;
    }
    
    .earnings-amount {
        font-size: 32px;
        font-weight: 700;
        margin: 10px 0;
    }
    
    .earnings-label {
        font-size: 14px;
        opacity: 0.9;
    }
</style>
""", unsafe_allow_html=True)

def show_gig_home():
    """Main GigThen provider home screen"""
    if 'active_tab' not in st.session_state:
        st.session_state.active_tab = 'home'
    
    # Auto-refresh every 5 seconds to check for new jobs
    if 'last_refresh' not in st.session_state:
        st.session_state.last_refresh = time.time()
    
    # Add auto-refresh for checking new jobs
    current_time = time.time()
    if current_time - st.session_state.last_refresh > 5:
        st.session_state.last_refresh = current_time
        st.rerun()
    
    # Get provider info
    db = next(get_db())
    provider = db.query(Provider).filter_by(user_id=st.session_state.user.id).first()
    user = st.session_state.user
    
    # Header with GigThen branding
    st.markdown(f"""
    <div class='gig-header'>
        <h1>GigThen</h1>
        <div class='notification-bell'>🔔</div>
        <div class='profile-avatar'>{user.name[0].upper()}</div>
    </div>
    """, unsafe_allow_html=True)
    
    if st.session_state.active_tab == 'service_dashboard' and 'active_service_type' in st.session_state:
        show_service_dashboard(st.session_state.active_service_type)
    elif st.session_state.active_tab == 'home':
        show_home_tab(user, provider, db)
    elif st.session_state.active_tab == 'orders':
        show_orders_tab(provider, db)
    elif st.session_state.active_tab == 'messages':
        show_messages_tab()
    elif st.session_state.active_tab == 'profile':
        show_profile_tab(user, provider, db)
    
    # Bottom navigation
    show_bottom_navigation()
    
    db.close()

def show_home_tab(user, provider, db):
    """Home tab with service cards"""
    from utils.job_notifications import auto_check_jobs, show_job_request_popup
    
    # Check for new jobs if provider is online
    if provider and provider.is_available:
        # Check for jobs in the currently selected service type
        active_service = st.session_state.get('active_service_type', 'ride_hailing')
        new_job = auto_check_jobs(user.id, active_service)
        
        if new_job:
            show_job_request_popup(new_job)
            return  # Show popup instead of regular content
    
    # Welcome section
    st.markdown(f"""
    <div class='welcome-section'>
        <h2>Hello, {user.name.split()[0]}!</h2>
        <div class='location-box'>
            <span style='color: #00c853; font-size: 18px;'>📍</span>
            <span style='flex: 1; color: #333;'>123 Main Street, Cityville</span>
            <span style='color: #999;'>›</span>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Map showing service requests
    st.markdown("""
    <div style='background: white; padding: 15px; border-radius: 10px; margin: 15px 0;'>
        <h3 style='margin: 0 0 10px 0; color: #333;'>📍 Service Requests Near You</h3>
    </div>
    """, unsafe_allow_html=True)
    
    # Get all pending bookings
    pending_bookings = db.query(Booking).filter(
        Booking.status == 'pending',
        Booking.provider_id == None
    ).limit(20).all()
    
    # Create map with service request locations
    import plotly.graph_objects as go
    
    # Pittsburgh center coordinates
    center_lat, center_lon = 40.4406, -79.9959
    
    # Create figure
    fig = go.Figure()
    
    # Add markers for each pending booking
    if pending_bookings:
        for booking in pending_bookings:
            # Generate random coordinates near Pittsburgh
            lat = center_lat + random.uniform(-0.05, 0.05)
            lon = center_lon + random.uniform(-0.05, 0.05)
            
            # Service type icons
            service_icons = {
                'ride_hailing': '🚗',
                'delivery': '📦',
                'other_tasks': '✋',
                'grocery': '🛒',
                'home_services': '🏠',
                'moving_help': '📦'
            }
            
            icon = service_icons.get(booking.service_type, '📍')
            service_name = SERVICES.get(booking.service_type, {}).get('name', 'Service')
            
            # Add marker
            fig.add_trace(go.Scattermapbox(
                mode='markers+text',
                lon=[lon],
                lat=[lat],
                marker={'size': 15, 'color': '#667eea'},
                text=f"{icon} {service_name}<br>${booking.estimated_price:.2f}",
                textposition="top center",
                hoverinfo='text',
                hovertext=f"""
                {service_name} Request
                📍 {booking.pickup_address or 'Location'}
                💰 ${booking.estimated_price:.2f}
                ⏰ {booking.created_at.strftime('%I:%M %p') if booking.created_at else 'Recent'}
                """,
                showlegend=False
            ))
    
    # Add provider's current location
    fig.add_trace(go.Scattermapbox(
        mode='markers',
        lon=[center_lon],
        lat=[center_lat],
        marker={'size': 20, 'color': '#28a745'},
        text="You",
        textposition="bottom center",
        hoverinfo='text',
        hovertext="Your Location",
        showlegend=False
    ))
    
    # Update layout
    fig.update_layout(
        mapbox=dict(
            style="open-street-map",
            center=dict(lat=center_lat, lon=center_lon),
            zoom=11
        ),
        height=300,
        margin={"r":0,"t":0,"l":0,"b":0},
        showlegend=False
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Service request count
    if pending_bookings:
        st.markdown(f"""
        <div style='background: #f0f7ff; padding: 10px; border-radius: 8px; margin: 10px 0;'>
            <p style='margin: 0; color: #667eea; text-align: center;'>
                <strong>{len(pending_bookings)} active service requests</strong> in your area
            </p>
        </div>
        """, unsafe_allow_html=True)
    
    # Today's earnings summary
    today_start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    today_bookings = db.query(Booking).filter(
        Booking.provider_id == user.id,
        Booking.created_at >= today_start,
        Booking.status == 'completed'
    ).all()
    
    today_earnings = sum([b.provider_payout or 0 for b in today_bookings])
    
    if today_earnings > 0:
        st.markdown(f"""
        <div class='earnings-card'>
            <div class='earnings-label'>Today's Earnings</div>
            <div class='earnings-amount'>${today_earnings:.2f}</div>
            <div class='earnings-label'>{len(today_bookings)} jobs completed</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Service cards
    services = [
        {
            'title': 'Ride',
            'key': 'ride_hailing',
            'bg_class': 'ride-bg',
            'icon': '🚗',
            'image': '🚗',
            'available_jobs': 0
        },
        {
            'title': 'Delivery',
            'key': 'delivery',
            'bg_class': 'delivery-bg',
            'icon': '📦',
            'image': '🛵',
            'available_jobs': 0
        },
        {
            'title': 'Tasks',
            'key': 'other_tasks',
            'bg_class': 'tasks-bg',
            'icon': '✋',
            'image': '🤝',
            'available_jobs': 0
        },
        {
            'title': 'Grocery',
            'key': 'grocery',
            'bg_class': 'grocery-bg',
            'icon': '🛒',
            'image': '🛒',
            'available_jobs': 0
        }
    ]
    
    # Get available jobs count for each service
    for service in services:
        pending_count = db.query(Booking).filter(
            Booking.status == 'pending',
            Booking.provider_id == None,
            Booking.service_type == service['key']
        ).count()
        service['available_jobs'] = pending_count
    
    # Display service cards
    for service in services:
        is_online = provider.is_available if provider else False
        status_text = "Online" if is_online else "Offline"
        status_class = "status-online" if is_online else "status-offline"
        
        # Create clickable service card (removed as cards are visual only for now)
        
        st.markdown(f"""
        <div class='service-card'>
            <div class='service-card-image {service["bg_class"]}'>
                <div class='status-badge {status_class}'>{status_text}</div>
                <div style='display: flex; align-items: center; justify-content: center; height: 100%; font-size: 80px;'>
                    {service['image']}
                </div>
            </div>
            <div class='service-card-content'>
                <h3 class='service-card-title'>{service['title']}</h3>
                <div class='service-card-icon'>{service['icon']}</div>
            </div>
            {f"<div style='padding: 0 20px 15px; color: #666; font-size: 14px;'>{service['available_jobs']} jobs available</div>" if service['available_jobs'] > 0 else ""}
        </div>
        """, unsafe_allow_html=True)
        
        # Create two columns for buttons
        col1, col2 = st.columns(2)
        
        with col1:
            # View dashboard button
            if st.button(f"📊 View {service['title']} Dashboard", 
                        key=f"view_{service['key']}", use_container_width=True):
                st.session_state.active_service_type = service['key']
                st.session_state.active_tab = 'service_dashboard'
                st.rerun()
        
        with col2:
            # Toggle online status button
            if st.button(f"{'🟢 Go Offline' if is_online else '🔴 Go Online'}", 
                        key=f"toggle_{service['key']}", use_container_width=True):
                if provider:
                    provider.is_available = not is_online
                    st.session_state.active_service_type = service['key']
                    db.commit()
                    st.rerun()

def show_service_dashboard(service_type):
    """Show service-specific dashboard"""
    db = next(get_db())
    provider = db.query(Provider).filter_by(user_id=st.session_state.user.id).first()
    
    # Service names and icons mapping
    service_config = {
        'ride_hailing': {'name': 'Ride Service', 'icon': '🚗'},
        'delivery': {'name': 'Delivery Service', 'icon': '📦'},
        'other_tasks': {'name': 'Task Service', 'icon': '✋'},
        'grocery': {'name': 'Grocery Shopping', 'icon': '🛒'}
    }
    
    config = service_config.get(service_type, {'name': 'Service', 'icon': '💼'})
    service_name = config['name']
    service_icon = config['icon']
    
    # Back button
    if st.button("← Back to Home"):
        st.session_state.active_tab = 'home'
        st.rerun()
    
    # Dashboard header
    st.markdown(f"""
    <div style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                color: white; padding: 30px; border-radius: 15px; margin-bottom: 20px;'>
        <h1 style='color: white; margin: 0;'>{service_icon} {service_name} Dashboard</h1>
        <p style='color: rgba(255,255,255,0.8); margin: 10px 0 0 0;'>
            Manage your {service_name.lower()} operations
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Statistics row
    col1, col2, col3, col4 = st.columns(4)
    
    # Get statistics for this service
    today_earnings = random.uniform(50, 200)
    today_trips = random.randint(3, 15)
    acceptance_rate = random.uniform(85, 98)
    avg_rating = random.uniform(4.5, 5.0)
    
    with col1:
        st.metric("Today's Earnings", f"${today_earnings:.2f}", "+12%")
    with col2:
        st.metric("Trips Today", today_trips, "+3")
    with col3:
        st.metric("Acceptance Rate", f"{acceptance_rate:.1f}%", "+2.1%")
    with col4:
        st.metric("Rating", f"⭐ {avg_rating:.1f}", "+0.2")
    
    # Tabs for different sections
    tab1, tab2, tab3 = st.tabs(["📋 Available Jobs", "📊 Analytics", "⚙️ Settings"])
    
    with tab1:
        st.markdown("### Available Jobs")
        
        # Get pending jobs for this service
        pending_jobs = db.query(Booking).filter(
            Booking.status == 'pending',
            Booking.service_type == service_type,
            Booking.provider_id == None
        ).order_by(Booking.created_at.desc()).limit(5).all()
        
        if pending_jobs:
            for job in pending_jobs:
                with st.container():
                    st.markdown(f"""
                    <div style='background: white; border: 1px solid #e0e0e0; 
                                border-radius: 10px; padding: 15px; margin-bottom: 15px;'>
                        <div style='display: flex; justify-content: space-between; align-items: center;'>
                            <div>
                                <h4 style='margin: 0;'>New {service_name} Request</h4>
                                <p style='color: #666; margin: 5px 0;'>
                                    📍 {job.pickup_address or 'Pickup location'}
                                </p>
                                {f"<p style='color: #666; margin: 5px 0;'>📍 {job.dropoff_address}</p>" 
                                 if job.dropoff_address else ""}
                                <p style='color: #28a745; font-weight: bold; margin: 5px 0;'>
                                    💰 ${job.estimated_price:.2f}
                                </p>
                            </div>
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    col1, col2 = st.columns(2)
                    with col1:
                        if st.button(f"✅ Accept", key=f"accept_{job.id}"):
                            job.provider_id = st.session_state.user.id
                            job.status = 'accepted'
                            job.accepted_at = datetime.now()
                            db.commit()
                            st.success("Job accepted!")
                            st.rerun()
                    with col2:
                        if st.button(f"❌ Decline", key=f"decline_{job.id}"):
                            st.info("Job declined")
        else:
            st.info(f"No available {service_name.lower()} jobs at the moment. Check back soon!")
    
    with tab2:
        st.markdown("### Performance Analytics")
        
        # Mock data for charts
        import plotly.graph_objects as go
        
        # Daily earnings chart
        days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        earnings = [random.uniform(100, 300) for _ in days]
        
        fig = go.Figure(data=[
            go.Bar(x=days, y=earnings, marker_color='#667eea')
        ])
        fig.update_layout(
            title="Weekly Earnings",
            xaxis_title="Day",
            yaxis_title="Earnings ($)",
            showlegend=False
        )
        st.plotly_chart(fig, use_container_width=True)
        
        # Trip statistics
        col1, col2 = st.columns(2)
        with col1:
            st.markdown("""
            <div style='background: #f8f9fa; padding: 20px; border-radius: 10px;'>
                <h4>This Week</h4>
                <p>Total Trips: <strong>47</strong></p>
                <p>Total Earnings: <strong>$1,234.56</strong></p>
                <p>Online Hours: <strong>32.5</strong></p>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            st.markdown("""
            <div style='background: #f8f9fa; padding: 20px; border-radius: 10px;'>
                <h4>This Month</h4>
                <p>Total Trips: <strong>189</strong></p>
                <p>Total Earnings: <strong>$4,567.89</strong></p>
                <p>Online Hours: <strong>142.3</strong></p>
            </div>
            """, unsafe_allow_html=True)
    
    with tab3:
        st.markdown("### Service Settings")
        
        # Service preferences
        st.markdown("#### Availability")
        
        # Working hours
        col1, col2 = st.columns(2)
        with col1:
            start_time = st.time_input("Start Time", value=None)
        with col2:
            end_time = st.time_input("End Time", value=None)
        
        # Service area
        st.markdown("#### Service Area")
        max_distance = st.slider("Maximum distance (miles)", 5, 50, 20)
        
        # Service preferences
        st.markdown("#### Preferences")
        auto_accept = st.checkbox("Auto-accept jobs above minimum fare")
        if auto_accept:
            min_fare = st.number_input("Minimum fare ($)", min_value=5.0, value=15.0, step=1.0)
        
        # Vehicle/Equipment info for specific services
        if service_type == 'ride_hailing':
            st.markdown("#### Vehicle Information")
            vehicle_type = st.selectbox("Vehicle Type", ["Economy", "Comfort", "Premium", "XL"])
            vehicle_info = st.text_input("Vehicle Details", placeholder="Make, Model, Color, License Plate")
        
        if st.button("💾 Save Settings", type="primary"):
            st.success("Settings saved successfully!")
    
    db.close()

def show_orders_tab(provider, db):
    """Orders/jobs tab"""
    st.markdown("""
    <div style='background: white; padding: 20px; text-align: center;'>
        <h2 style='margin: 0;'>Orders</h2>
    </div>
    """, unsafe_allow_html=True)
    
    # Get provider's bookings
    bookings = db.query(Booking).filter_by(
        provider_id=st.session_state.user.id
    ).order_by(Booking.created_at.desc()).limit(10).all()
    
    if bookings:
        for booking in bookings:
            service_info = SERVICES.get(booking.service_type, SERVICES['other_tasks'])
            status_color = {
                'pending': '#ff9800',
                'accepted': '#2196f3',
                'in_progress': '#9c27b0',
                'completed': '#4caf50',
                'cancelled': '#f44336'
            }.get(booking.status, '#999')
            
            st.markdown(f"""
            <div class='service-card'>
                <div style='padding: 20px;'>
                    <div style='display: flex; justify-content: space-between; align-items: center;'>
                        <div>
                            <h4 style='margin: 0; color: #333;'>{service_info['icon']} {service_info['name']}</h4>
                            <p style='margin: 5px 0; color: #666; font-size: 14px;'>{booking.pickup_address}</p>
                            <p style='margin: 0; color: #999; font-size: 12px;'>{booking.created_at.strftime('%b %d, %I:%M %p')}</p>
                        </div>
                        <div>
                            <span style='background: {status_color}; color: white; padding: 6px 12px; border-radius: 20px; font-size: 12px;'>
                                {booking.status.upper()}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)
    else:
        st.info("No orders yet. Go online to start receiving requests!")

def show_messages_tab():
    """Messages tab"""
    st.markdown("""
    <div style='background: white; padding: 20px; text-align: center;'>
        <h2 style='margin: 0;'>Messages</h2>
    </div>
    """, unsafe_allow_html=True)
    
    messages = [
        {'sender': 'Customer Support', 'message': 'Welcome to GigGo!', 'time': '2h ago'},
        {'sender': 'John D.', 'message': 'Thanks for the ride!', 'time': '5h ago'}
    ]
    
    for msg in messages:
        st.markdown(f"""
        <div class='service-card'>
            <div style='padding: 20px;'>
                <div style='display: flex; gap: 15px;'>
                    <div style='width: 50px; height: 50px; background: #f0f0f0; border-radius: 50%; display: flex; align-items: center; justify-content: center;'>
                        💬
                    </div>
                    <div style='flex: 1;'>
                        <h4 style='margin: 0; color: #333;'>{msg['sender']}</h4>
                        <p style='margin: 5px 0; color: #666;'>{msg['message']}</p>
                        <p style='margin: 0; color: #999; font-size: 12px;'>{msg['time']}</p>
                    </div>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)

def show_profile_tab(user, provider, db):
    """Profile tab"""
    st.markdown("""
    <div style='background: white; padding: 20px; text-align: center;'>
        <h2 style='margin: 0;'>Profile</h2>
    </div>
    """, unsafe_allow_html=True)
    
    # Profile info
    st.markdown(f"""
    <div style='background: white; padding: 20px; margin: 10px 15px; border-radius: 16px;'>
        <div style='text-align: center;'>
            <div style='width: 80px; height: 80px; background: linear-gradient(135deg, #667eea, #764ba2); 
                        border-radius: 50%; margin: 0 auto 15px; display: flex; align-items: center; 
                        justify-content: center; color: white; font-size: 32px; font-weight: 600;'>
                {user.name[0].upper()}
            </div>
            <h3 style='margin: 0; color: #333;'>{user.name}</h3>
            <p style='color: #666; margin: 5px 0;'>{user.email}</p>
            <p style='color: #666;'>{user.phone}</p>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Stats
    total_jobs = db.query(Booking).filter_by(provider_id=user.id).count()
    completed_jobs = db.query(Booking).filter_by(provider_id=user.id, status='completed').count()
    
    st.markdown(f"""
    <div style='background: white; padding: 20px; margin: 10px 15px; border-radius: 16px;'>
        <h4 style='margin: 0 0 15px 0; color: #333;'>Statistics</h4>
        <div style='display: flex; justify-content: space-around;'>
            <div style='text-align: center;'>
                <div style='font-size: 24px; font-weight: 600; color: #667eea;'>{total_jobs}</div>
                <div style='color: #666; font-size: 14px;'>Total Jobs</div>
            </div>
            <div style='text-align: center;'>
                <div style='font-size: 24px; font-weight: 600; color: #4caf50;'>{completed_jobs}</div>
                <div style='color: #666; font-size: 14px;'>Completed</div>
            </div>
            <div style='text-align: center;'>
                <div style='font-size: 24px; font-weight: 600; color: #ff9800;'>4.8</div>
                <div style='color: #666; font-size: 14px;'>Rating</div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Sign out button
    if st.button("Sign Out", use_container_width=True):
        st.session_state.clear()
        st.rerun()

def show_bottom_navigation():
    """Bottom navigation bar"""
    tabs = [
        ("🏠", "Home", "home"),
        ("📋", "Orders", "orders"),
        ("💬", "Messages", "messages"),
        ("👤", "Profile", "profile")
    ]
    
    st.markdown("""
    <div class='bottom-nav'>
        <div style='display: flex; justify-content: space-around;'>
    """, unsafe_allow_html=True)
    
    cols = st.columns(4)
    for i, (icon, label, tab_id) in enumerate(tabs):
        with cols[i]:
            active_class = "active" if st.session_state.active_tab == tab_id else ""
            if st.button(f"{icon}\n{label}", key=f"nav_{tab_id}", use_container_width=True):
                st.session_state.active_tab = tab_id
                st.rerun()
    
    st.markdown("""
        </div>
    </div>
    """, unsafe_allow_html=True)

# Main execution
if __name__ == "__main__":
    if 'user' in st.session_state and st.session_state.user:
        show_gig_home()
    else:
        st.error("Please login first")
        st.stop()