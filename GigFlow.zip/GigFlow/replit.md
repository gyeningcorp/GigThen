# GigThen - On-Demand Service Platform

## Overview

GigThen is a comprehensive on-demand service platform built with Streamlit that connects users with various service providers. The application offers multiple service categories including ride-hailing, home services, deliveries, moving help, and other miscellaneous tasks. The platform features a modern, state-of-the-art web interface with service-specific provider mapping, intelligent address autocomplete, and competitive Pittsburgh market pricing.

## Recent Changes (January 2025)

- **Mobile App Redesign**: Complete mobile-first UI overhaul with bottom navigation, service cards, and modern gradients
- **Responsive Mobile Layout**: Max-width 428px container optimized for mobile devices with touch-friendly interface
- **Bottom Navigation Bar**: iOS/Android style tab bar with Home, Activity, Book, Messages, and Profile sections
- **Modern Service Cards**: Hover animations, rounded corners, and shadow effects for better visual hierarchy
- **Gradient Design System**: Purple gradient theme (#667eea to #764ba2) for consistent branding
- **Mobile-Optimized Forms**: Large touch targets, rounded inputs, and streamlined booking flow
- **Status Pills & Price Tags**: Visual indicators for booking status and pricing information
- **Profile Management**: Complete user profile with settings, payment methods, and ride history

## Recent Changes (August 2025)

- **Multi-Service Gig Worker Dashboard**: Complete redesign of provider interface to support 5 distinct gig services:
  - 🚗 Driver (ride-hailing like Uber/Lyft)
  - 🌿 Lawn Care (yard maintenance services)
  - 📦 Delivery (package and food delivery)
  - 🛒 Grocery Shopping (personal shopping services)
  - 🏪 Marketplace Pickup (Facebook Marketplace, Craigslist pickups)
- **Service-Specific Job Generation**: Dynamic job listings tailored to each service type with realistic Pittsburgh locations
- **Professional Driver Interface**: Uber-style dashboard with earnings tracking, job acceptance, and performance metrics
- **Real Database Integration**: PostgreSQL database for storing real users, bookings, providers, and notifications
- **Dual Interface System**: Separate login and interfaces for customers and gig workers/providers
- **Real Provider Management**: Database-backed provider profiles with availability status and earnings tracking
- **Live Booking System**: Real-time booking creation, assignment, and status updates stored in database
- **Accurate Pricing Engine**: Pittsburgh market-based pricing with transparent provider payouts (78-84% based on service)
- **Customer Booking History**: Persistent booking records with status tracking
- **Complete Sign-Up Flow**: Secure user registration for both customers and gig workers with password authentication
- **Stripe Payment Integration**: Full payment processing system supporting credit cards and cash payments with marketplace functionality

- **Modern UI Redesign**: Complete visual overhaul with Inter font, gradient styling, and professional design
- **Service-Specific Provider Mapping**: Each service shows only relevant providers (drivers for rides, specialists for home services, etc.)
- **Smart Address Autocomplete**: Uber-style address suggestions with 40+ Pittsburgh locations and landmarks
- **Enhanced Pricing Model**: Pittsburgh market-competitive rates with transparent provider payouts (78-84%)
- **Professional Service Cards**: Interactive cards with hover effects and real-time availability counts
- **Real-Time GPS Tracking**: Live provider location tracking with automatic movement simulation, route visualization, and dynamic ETA updates
- **Push Notifications System**: Real-time notifications for booking status, provider updates, and service milestones
- **Live Updates Engine**: Automatic page refreshes with real-time data synchronization and timestamp tracking

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Streamlit for rapid web application development
- **UI Pattern**: Multi-page application using Streamlit's page system
- **State Management**: Session-based state management using `st.session_state` for maintaining booking flow and user data
- **Visualization**: Plotly integration for interactive maps and data visualization
- **Layout**: Responsive column-based layout with wide page configuration

### Application Structure
- **Main Application**: Central `app.py` handles routing between different booking stages
- **Page-based Routing**: Separate modules for each service type (ride-hailing, deliveries, home services, moving help, other tasks)
- **Utility Modules**: Dedicated utilities for booking management and location services
- **Booking Flow**: Multi-stage booking process (service selection → service details → confirmation → status tracking)

### Service Management
- **Service Categories**: Modular service types with specialized booking flows
- **Provider Matching**: Mock provider data with rating and availability systems
- **Pricing Engine**: Pittsburgh market-competitive pricing with service-specific models
  - Rides: $2.50 base + $1.50/mile + $0.30/minute (provider gets 80%)
  - Deliveries: $6 base + $1.20/mile + size surcharges (provider gets 80%)
  - Home Services: Flat rates $35-450 based on service/property size (provider gets 82%)
  - Moving Help: $20 booking + $35/hour/person + $1.50/mile transport (provider gets 84%)
  - Other Tasks: $18-30/hour based on skill level (provider gets 78%)
- **Booking System**: Unique ID generation and booking status tracking
- **GPS Tracking System**: Real-time provider location simulation with movement algorithms, route generation, and ETA calculations
- **Notification System**: Push notification engine with timestamped alerts, multiple notification types, and automatic cleanup
- **Real-Time Updates**: Live data synchronization with automatic refresh cycles and status change detection

### Location Services
- **Map Integration**: Plotly-based interactive maps for route visualization and live tracking
- **Location Handling**: Coordinate-based location management with default Pittsburgh coordinates
- **Route Calculation**: Basic route mapping between pickup and dropoff points
- **Real-Time Tracking**: Live provider movement simulation using GPS coordinates, Haversine distance calculations, and automatic position updates
- **ETA Management**: Dynamic ETA calculations based on real-time distance and average speed estimates

### Data Management
- **Session State**: Browser session-based data persistence
- **Mock Data**: Hardcoded service providers and booking data for demonstration
- **Booking Tracking**: In-memory booking status and history management

## External Dependencies

### Core Frameworks
- **Streamlit**: Web application framework for rapid prototyping
- **Plotly**: Interactive visualization library for maps and charts
- **Pandas**: Data manipulation and analysis

### Visualization & Mapping
- **Plotly Graph Objects**: Interactive map components and data visualization
- **Plotly Express**: Simplified plotting interface
- **OpenStreetMap**: Map tiles for geographic visualization

### Utility Libraries
- **datetime**: Date and time handling for scheduling
- **hashlib**: Booking ID generation and data hashing

### Development Dependencies
- Standard Python libraries (no external API integrations currently implemented)
- No database persistence (session-based storage only)
- No payment processing integration
- No real-time communication systems

### Future Integration Points
- Payment processing APIs (Stripe, PayPal)
- Real-time location services (Google Maps API)
- SMS/Email notification services
- Database system for persistent storage
- Real-time messaging for provider communication