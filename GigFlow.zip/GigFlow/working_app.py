import streamlit as st
from datetime import datetime, timedelta
import time
import random
import math

# Simple configuration
st.set_page_config(
    page_title="AllServ Platform",
    page_icon="🚗",
    layout="wide"
)

# Initialize basic session state
if 'notifications' not in st.session_state:
    st.session_state.notifications = []
if 'service' not in st.session_state:
    st.session_state.service = None
if 'booking_confirmed' not in st.session_state:
    st.session_state.booking_confirmed = False
if 'booking_time' not in st.session_state:
    st.session_state.booking_time = None
if 'last_notification_time' not in st.session_state:
    st.session_state.last_notification_time = None

# Add notification function
def add_notification(message, type="info"):
    timestamp = datetime.now().strftime("%I:%M:%S %p")
    st.session_state.notifications.append({
        'message': message,
        'type': type,
        'time': timestamp
    })

# Main app with real-time clock
current_time = datetime.now().strftime("%I:%M:%S %p")
st.title("🚗 AllServ - Real-Time Service Platform")
col1, col2 = st.columns([3, 1])
with col1:
    st.write("Your on-demand service platform with live updates")
with col2:
    st.info(f"🕒 {current_time}")

# Display notifications
if st.session_state.notifications:
    st.sidebar.markdown("### 🔔 Notifications")
    for notif in st.session_state.notifications[-5:]:
        if notif['type'] == 'success':
            st.sidebar.success(f"{notif['message']} - {notif['time']}")
        else:
            st.sidebar.info(f"{notif['message']} - {notif['time']}")

# Service selection
if not st.session_state.service:
    st.markdown("### Choose a Service")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("🚗 Ride-Hailing", use_container_width=True):
            st.session_state.service = "Ride-Hailing"
            add_notification("Ride service selected", "info")
            st.rerun()
    
    with col2:
        if st.button("📦 Deliveries", use_container_width=True):
            st.session_state.service = "Deliveries"
            add_notification("Delivery service selected", "info")
            st.rerun()
    
    with col3:
        if st.button("🏠 Home Services", use_container_width=True):
            st.session_state.service = "Home Services"
            add_notification("Home service selected", "info")
            st.rerun()

# Service details
elif st.session_state.service and not st.session_state.booking_confirmed:
    st.markdown(f"### {st.session_state.service} Details")
    
    pickup = st.text_input("Pickup Location", "Downtown Pittsburgh")
    
    if st.session_state.service == "Ride-Hailing":
        destination = st.text_input("Destination", "Airport")
    
    col1, col2 = st.columns(2)
    with col1:
        if st.button("← Back", use_container_width=True):
            st.session_state.service = None
            st.rerun()
    
    with col2:
        if st.button("✅ Confirm Booking", use_container_width=True):
            st.session_state.booking_confirmed = True
            add_notification("Booking confirmed!", "success")
            add_notification("Provider found: Mike Rodriguez", "success")
            st.rerun()

# Booking confirmed with real-time updates
else:
    st.markdown("### ✅ Booking Confirmed!")
    
    # Calculate time since booking
    if st.session_state.booking_time:
        elapsed = (datetime.now() - st.session_state.booking_time).seconds
        
        # Add progressive notifications based on elapsed time
        if elapsed > 5 and (not st.session_state.last_notification_time or 
                           (datetime.now() - st.session_state.last_notification_time).seconds > 5):
            if elapsed < 10:
                add_notification("Provider is heading your way", "info")
            elif elapsed < 15:
                add_notification("Provider is 5 minutes away", "info")
            elif elapsed < 20:
                add_notification("Provider is arriving soon!", "success")
            elif elapsed < 25:
                add_notification("Provider has arrived! Look for Toyota Camry", "success")
            st.session_state.last_notification_time = datetime.now()
            st.rerun()
        
        # Calculate dynamic ETA
        eta = max(1, 8 - (elapsed // 5))
        status = "En Route" if elapsed < 20 else "Arriving" if elapsed < 25 else "Arrived"
        
        # Display provider info with live updates
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Status", status)
        with col2:
            st.metric("ETA", f"{eta} min")
        with col3:
            st.metric("Time Elapsed", f"{elapsed} sec")
        
        st.markdown("""
        **Provider:** Mike Rodriguez  
        **Vehicle:** Toyota Camry (Gray)  
        **License:** ABC-123  
        **Rating:** ⭐ 4.9 (127 rides)
        """)
    else:
        st.session_state.booking_time = datetime.now()
        st.success("Your provider is on the way!")
    
    # Live tracking indicator
    st.info("🔄 Live tracking active - Updates every 5 seconds")
    
    # Progress bar
    if st.session_state.booking_time:
        elapsed_for_progress = (datetime.now() - st.session_state.booking_time).seconds
        progress = min(100, (elapsed_for_progress / 25) * 100)
        st.progress(progress / 100, text="Provider Progress")
    
    if st.button("Book Another Service"):
        st.session_state.service = None
        st.session_state.booking_confirmed = False
        st.session_state.notifications = []
        st.session_state.booking_time = None
        st.session_state.last_notification_time = None
        st.rerun()
    
    # Auto-refresh for real-time updates
    if st.session_state.booking_time:
        elapsed_check = (datetime.now() - st.session_state.booking_time).seconds
        if elapsed_check < 30:
            time.sleep(3)
            st.rerun()