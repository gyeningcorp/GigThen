import streamlit as st

st.title("Test App")
st.write("This is a test")
st.button("Click Me")