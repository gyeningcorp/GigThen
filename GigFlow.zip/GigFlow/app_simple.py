import streamlit as st
import plotly.graph_objects as go
from datetime import datetime
import random
import math

# Configure page
st.set_page_config(
    page_title="AllServ - Your On-Demand Service Platform",
    page_icon="🚗",
    layout="wide"
)

# Initialize session state
if 'current_service' not in st.session_state:
    st.session_state.current_service = None
if 'booking_stage' not in st.session_state:
    st.session_state.booking_stage = 'service_selection'
if 'user_location' not in st.session_state:
    st.session_state.user_location = {'lat': 40.4406, 'lng': -79.9959}  # Pittsburgh
if 'booking_details' not in st.session_state:
    st.session_state.booking_details = {}
if 'tracking_active' not in st.session_state:
    st.session_state.tracking_active = False
if 'provider_location' not in st.session_state:
    st.session_state.provider_location = None

def main():
    # Header
    st.markdown("""
    <div style="text-align: center; margin-bottom: 2rem;">
        <h1 style="color: #667eea; font-size: 3rem; margin-bottom: 0.5rem;">🚗 AllServ</h1>
        <p style="color: #6b7280; font-size: 1.2rem;">Your All-in-One On-Demand Service Platform</p>
    </div>
    """, unsafe_allow_html=True)
    
    if st.session_state.booking_stage == 'service_selection':
        show_service_selection()
    elif st.session_state.booking_stage == 'service_details':
        show_service_details()
    elif st.session_state.booking_stage == 'confirmation':
        show_confirmation()
    elif st.session_state.booking_stage == 'booking_status':
        show_booking_status()

def show_service_selection():
    st.markdown("### 🛍️ Choose Your Service")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("🚗 Ride-Hailing", use_container_width=True, type="primary"):
            st.session_state.current_service = 'ride_hailing'
            st.session_state.booking_stage = 'service_details'
            st.rerun()
    
    with col2:
        if st.button("📦 Deliveries", use_container_width=True):
            st.session_state.current_service = 'deliveries'
            st.session_state.booking_stage = 'service_details'
            st.rerun()
    
    with col3:
        if st.button("🏠 Home Services", use_container_width=True):
            st.session_state.current_service = 'home_services'
            st.session_state.booking_stage = 'service_details'
            st.rerun()

def show_service_details():
    service_type = st.session_state.current_service
    st.markdown(f"### 📋 {service_type.replace('_', ' ').title()} Details")
    
    # Simple form
    pickup_address = st.text_input("📍 Pickup Address", "Downtown Pittsburgh")
    
    if service_type == 'ride_hailing':
        dropoff_address = st.text_input("📍 Destination", "Pittsburgh Airport")
        st.session_state.booking_details = {
            'service_type': service_type,
            'pickup_address': pickup_address,
            'dropoff_address': dropoff_address
        }
    else:
        st.session_state.booking_details = {
            'service_type': service_type,
            'pickup_address': pickup_address
        }
    
    col1, col2 = st.columns(2)
    with col1:
        if st.button("← Back", use_container_width=True):
            st.session_state.booking_stage = 'service_selection'
            st.rerun()
    with col2:
        if st.button("Continue →", use_container_width=True, type="primary"):
            st.session_state.booking_stage = 'confirmation'
            st.rerun()

def show_confirmation():
    st.markdown("### ✅ Confirm Your Booking")
    details = st.session_state.booking_details
    
    st.write(f"**Service:** {details['service_type'].replace('_', ' ').title()}")
    st.write(f"**Pickup:** {details['pickup_address']}")
    if 'dropoff_address' in details:
        st.write(f"**Destination:** {details['dropoff_address']}")
    
    st.write("**Estimated Cost:** $12.50")
    
    col1, col2 = st.columns(2)
    with col1:
        if st.button("← Modify", use_container_width=True):
            st.session_state.booking_stage = 'service_details'
            st.rerun()
    with col2:
        if st.button("✅ Confirm Booking", use_container_width=True, type="primary"):
            # Start tracking
            start_tracking()
            st.session_state.booking_stage = 'booking_status'
            st.rerun()

def start_tracking():
    user_lat = st.session_state.user_location['lat']
    user_lng = st.session_state.user_location['lng']
    
    # Provider starts nearby
    provider_lat = user_lat + random.uniform(-0.01, 0.01)
    provider_lng = user_lng + random.uniform(-0.01, 0.01)
    
    st.session_state.provider_location = {
        'lat': provider_lat,
        'lng': provider_lng,
        'status': 'en_route',
        'eta': 8
    }
    st.session_state.tracking_active = True

def show_booking_status():
    st.markdown("### 🎉 Booking Confirmed!")
    
    provider_location = st.session_state.provider_location
    
    if provider_location:
        st.success("✅ Your ride has been booked!")
        st.write(f"**Provider Status:** {provider_location['status'].replace('_', ' ').title()}")
        st.write(f"**ETA:** {provider_location['eta']} minutes")
        
        # Simple map
        fig = go.Figure()
        
        # Add user location
        fig.add_trace(go.Scattermapbox(
            lat=[st.session_state.user_location['lat']],
            lon=[st.session_state.user_location['lng']],
            mode='markers',
            marker=dict(size=15, color='blue'),
            text=['You'],
            name="Your Location"
        ))
        
        # Add provider location
        fig.add_trace(go.Scattermapbox(
            lat=[provider_location['lat']],
            lon=[provider_location['lng']],
            mode='markers',
            marker=dict(size=15, color='green'),
            text=['Provider'],
            name="Provider"
        ))
        
        fig.update_layout(
            mapbox=dict(
                style="open-street-map",
                center=dict(
                    lat=st.session_state.user_location['lat'],
                    lon=st.session_state.user_location['lng']
                ),
                zoom=12
            ),
            height=400,
            margin=dict(l=0, r=0, t=0, b=0)
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    if st.button("🔄 Book Another Service", use_container_width=True):
        st.session_state.booking_stage = 'service_selection'
        st.session_state.current_service = None
        st.session_state.booking_details = {}
        st.session_state.tracking_active = False
        st.session_state.provider_location = None
        st.rerun()

if __name__ == "__main__":
    main()