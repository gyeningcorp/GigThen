import streamlit as st
from datetime import datetime
import time

# Page config
st.set_page_config(page_title="AllServ", page_icon="🚗", layout="wide")

# Session state for notifications
if 'notifications' not in st.session_state:
    st.session_state.notifications = []
if 'tracking' not in st.session_state:
    st.session_state.tracking = False
if 'start_time' not in st.session_state:
    st.session_state.start_time = None

# Function to add notifications
def add_notification(msg):
    timestamp = datetime.now().strftime("%I:%M:%S %p")
    st.session_state.notifications.append(f"{msg} - {timestamp}")
    if len(st.session_state.notifications) > 10:
        st.session_state.notifications.pop(0)

# Title and clock
st.title("🚗 AllServ - Real-Time Platform")
current_time = datetime.now().strftime("%I:%M:%S %p")
st.info(f"🕒 Current Time: {current_time}")

# Sidebar notifications
st.sidebar.title("🔔 Push Notifications")
if st.session_state.notifications:
    for notif in reversed(st.session_state.notifications[-5:]):
        st.sidebar.success(notif)
else:
    st.sidebar.write("No notifications yet")

# Main content
st.markdown("### Select a Service")
col1, col2, col3 = st.columns(3)

with col1:
    if st.button("🚗 Ride-Hailing", use_container_width=True):
        add_notification("Ride service selected")
        st.session_state.tracking = True
        st.session_state.start_time = datetime.now()
        st.rerun()

with col2:
    if st.button("📦 Deliveries", use_container_width=True):
        add_notification("Delivery service selected")
        st.session_state.tracking = True
        st.session_state.start_time = datetime.now()
        st.rerun()

with col3:
    if st.button("🏠 Home Services", use_container_width=True):
        add_notification("Home service selected")
        st.session_state.tracking = True
        st.session_state.start_time = datetime.now()
        st.rerun()

# Live tracking simulation
if st.session_state.tracking and st.session_state.start_time:
    elapsed = (datetime.now() - st.session_state.start_time).seconds
    
    st.markdown("### ✅ Service Booked!")
    
    # Live status updates
    if elapsed < 5:
        status = "Finding provider..."
        add_notification("Searching for provider")
    elif elapsed < 10:
        status = "Provider found!"
        add_notification("Provider Mike Rodriguez assigned")
    elif elapsed < 15:
        status = "Provider en route"
        add_notification("Provider is on the way")
    elif elapsed < 20:
        status = "Provider arriving soon"
        add_notification("Provider is 2 minutes away")
    else:
        status = "Provider has arrived!"
        add_notification("Provider has arrived at your location")
        
    # Display metrics
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Status", status)
    with col2:
        eta = max(1, 20 - elapsed)
        st.metric("ETA", f"{eta} seconds")
    with col3:
        st.metric("Time Elapsed", f"{elapsed} seconds")
    
    # Progress bar
    progress = min(100, (elapsed / 20) * 100)
    st.progress(progress / 100, text="Provider Progress")
    
    # Provider info
    if elapsed >= 5:
        st.info("""
        **Provider:** Mike Rodriguez  
        **Vehicle:** Toyota Camry  
        **Rating:** ⭐ 4.9 (127 rides)
        """)
    
    # Reset button
    if st.button("Book Another Service"):
        st.session_state.tracking = False
        st.session_state.start_time = None
        st.session_state.notifications = []
        st.rerun()
    
    # Auto-refresh for real-time updates
    if elapsed < 25:
        time.sleep(2)
        st.rerun()