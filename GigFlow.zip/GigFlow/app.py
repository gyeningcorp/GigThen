import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import pandas as pd
import random
import math

# Configure page
st.set_page_config(
    page_title="AllServ - Your On-Demand Service Platform",
    page_icon="🚗",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Modern CSS styling
st.markdown("""
<style>
    /* Import modern fonts */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    /* Global styles */
    .main {
        padding: 1rem 2rem;
    }
    
    /* Hide Streamlit branding */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    
    /* Custom font */
    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif;
    }
    
    /* Main title styling */
    .main-title {
        font-size: 3.5rem;
        font-weight: 700;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
        margin-bottom: 0.5rem;
    }
    
    .subtitle {
        text-align: center;
        color: #6b7280;
        font-size: 1.2rem;
        margin-bottom: 3rem;
    }
    
    /* Service cards */
    .service-card {
        background: white;
        padding: 2rem;
        border-radius: 16px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        border: 1px solid #e5e7eb;
        transition: all 0.3s ease;
        cursor: pointer;
        height: 200px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        text-align: center;
    }
    
    .service-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        border-color: #667eea;
    }
    
    .service-icon {
        font-size: 3rem;
        margin-bottom: 1rem;
    }
    
    .service-title {
        font-size: 1.5rem;
        font-weight: 600;
        color: #1f2937;
        margin-bottom: 0.5rem;
    }
    
    .service-description {
        color: #6b7280;
        font-size: 0.9rem;
    }
    
    /* Form styling */
    .stSelectbox > div > div {
        background-color: white;
        border: 2px solid #e5e7eb;
        border-radius: 8px;
        transition: border-color 0.2s ease;
    }
    
    .stSelectbox > div > div:focus-within {
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    }
    
    .stTextInput > div > div > input {
        background-color: white;
        border: 2px solid #e5e7eb;
        border-radius: 8px;
        padding: 0.75rem;
        transition: border-color 0.2s ease;
    }
    
    .stTextInput > div > div > input:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    }
    
    /* Button styling */
    .stButton > button {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 8px;
        padding: 0.75rem 2rem;
        font-weight: 600;
        transition: all 0.3s ease;
        width: 100%;
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
    }
    
    /* Metric cards */
    .metric-card {
        background: white;
        padding: 1.5rem;
        border-radius: 12px;
        border: 1px solid #e5e7eb;
        text-align: center;
    }
    
    /* Section headers */
    .section-header {
        font-size: 1.8rem;
        font-weight: 600;
        color: #1f2937;
        margin-bottom: 1.5rem;
        border-bottom: 2px solid #e5e7eb;
        padding-bottom: 0.5rem;
    }
    
    /* Provider cards */
    .provider-card {
        background: white;
        padding: 1.5rem;
        border-radius: 12px;
        border: 1px solid #e5e7eb;
        margin-bottom: 1rem;
        transition: all 0.2s ease;
    }
    
    .provider-card:hover {
        border-color: #667eea;
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.15);
    }
    
    /* Status indicators */
    .status-online {
        color: #10b981;
        font-weight: 600;
    }
    
    .status-busy {
        color: #f59e0b;
        font-weight: 600;
    }
    
    /* Map container */
    .map-container {
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'current_service' not in st.session_state:
    st.session_state.current_service = None
if 'booking_stage' not in st.session_state:
    st.session_state.booking_stage = 'service_selection'
if 'user_location' not in st.session_state:
    st.session_state.user_location = {'lat': 40.4406, 'lng': -79.9959}  # Pittsburgh
if 'booking_details' not in st.session_state:
    st.session_state.booking_details = {}
if 'tracking_active' not in st.session_state:
    st.session_state.tracking_active = False
if 'provider_location' not in st.session_state:
    st.session_state.provider_location = None
if 'route_data' not in st.session_state:
    st.session_state.route_data = None

def main():
    # Modern header
    st.markdown('<h1 class="main-title">AllServ</h1>', unsafe_allow_html=True)
    st.markdown('<p class="subtitle">Your premium on-demand service platform</p>', unsafe_allow_html=True)
    
    # Service selection cards
    if st.session_state.booking_stage == 'service_selection':
        show_service_selection()
    elif st.session_state.booking_stage == 'service_details':
        show_service_details()
    elif st.session_state.booking_stage == 'booking_confirmation':
        show_booking_confirmation()
    elif st.session_state.booking_stage == 'booking_status':
        show_booking_status()

def show_service_selection():
    st.markdown('<div class="section-header">Choose Your Service</div>', unsafe_allow_html=True)
    
    # Create service cards in a modern 5-column grid
    col1, col2, col3, col4, col5 = st.columns(5, gap="medium")
    
    services = [
        ("🚗", "Ride Hailing", "Quick rides across the city", "ride_hailing", "Get from point A to B in comfort"),
        ("📦", "Deliveries", "Fast pickup & delivery", "deliveries", "Restaurant delivery & errands"),
        ("🏠", "Home Services", "Professional home care", "home_services", "Cleaning, lawn care & repairs"),
        ("🚛", "Moving Help", "Expert moving assistance", "moving_help", "Heavy lifting & full moves"),
        ("⚡", "Other Tasks", "Any task, anytime", "other_tasks", "Assembly, pet care & more")
    ]
    
    columns = [col1, col2, col3, col4, col5]
    
    for i, (icon, title, subtitle, service_type, description) in enumerate(services):
        with columns[i]:
            # Create modern service card
            card_html = f"""
            <div class="service-card">
                <div class="service-icon">{icon}</div>
                <div class="service-title">{title}</div>
                <div class="service-description">{subtitle}</div>
            </div>
            """
            st.markdown(card_html, unsafe_allow_html=True)
            
            # Button for service selection
            if st.button(f"Select {title}", key=f"{service_type}_select", use_container_width=True):
                st.session_state.current_service = service_type
                st.session_state.booking_stage = 'service_details'
                st.rerun()
    
    # Add spacing and live provider count
    st.markdown("<br>", unsafe_allow_html=True)
    
    # Live provider stats
    col1, col2, col3, col4, col5 = st.columns(5)
    provider_counts = get_live_provider_counts()
    
    service_keys = ['ride_hailing', 'deliveries', 'home_services', 'moving_help', 'other_tasks']
    
    for i, service in enumerate(service_keys):
        with [col1, col2, col3, col4, col5][i]:
            count = provider_counts.get(service, 0)
            st.metric("Available", f"{count}", delta=None)
            
def get_live_provider_counts():
    """Get current available provider counts by service type"""
    providers = get_service_providers()
    counts = {}
    
    for service_type in ['ride_hailing', 'deliveries', 'home_services', 'moving_help', 'other_tasks']:
        service_providers = providers.get(service_type, [])
        available_count = len([p for p in service_providers if p.get('status') == 'available'])
        counts[service_type] = available_count
    
    return counts

def get_service_providers():
    """Get service-specific provider data with realistic distribution"""
    return {
        'ride_hailing': [
            {'name': 'Mike Rodriguez', 'rating': 4.9, 'status': 'available', 'vehicle': 'Honda Civic', 'eta': '3 min', 'lat': 40.4426, 'lng': -79.9865, 'trips': 1200},
            {'name': 'Sarah Chen', 'rating': 4.8, 'status': 'available', 'vehicle': 'Toyota Corolla', 'eta': '5 min', 'lat': 40.4380, 'lng': -79.9920, 'trips': 980},
            {'name': 'James Wilson', 'rating': 4.7, 'status': 'busy', 'vehicle': 'Nissan Altima', 'eta': '12 min', 'lat': 40.4450, 'lng': -79.9800, 'trips': 750},
            {'name': 'Maria Garcia', 'rating': 4.9, 'status': 'available', 'vehicle': 'Hyundai Elantra', 'eta': '7 min', 'lat': 40.4320, 'lng': -80.0050, 'trips': 1450},
            {'name': 'David Kim', 'rating': 4.6, 'status': 'available', 'vehicle': 'Ford Focus', 'eta': '4 min', 'lat': 40.4500, 'lng': -79.9750, 'trips': 650}
        ],
        'deliveries': [
            {'name': 'Alex Turner', 'rating': 4.8, 'status': 'available', 'vehicle': 'Bike', 'eta': '15 min', 'lat': 40.4400, 'lng': -79.9900, 'deliveries': 2100},
            {'name': 'Lisa Park', 'rating': 4.9, 'status': 'available', 'vehicle': 'Car', 'eta': '8 min', 'lat': 40.4350, 'lng': -80.0000, 'deliveries': 1800},
            {'name': 'Tom Mitchell', 'rating': 4.7, 'status': 'busy', 'vehicle': 'Scooter', 'eta': '20 min', 'lat': 40.4480, 'lng': -79.9820, 'deliveries': 1200},
            {'name': 'Jenny Wu', 'rating': 4.8, 'status': 'available', 'vehicle': 'Car', 'eta': '12 min', 'lat': 40.4280, 'lng': -80.0080, 'deliveries': 950},
            {'name': 'Chris Brown', 'rating': 4.6, 'status': 'available', 'vehicle': 'Van', 'eta': '10 min', 'lat': 40.4520, 'lng': -79.9700, 'deliveries': 750}
        ],
        'home_services': [
            {'name': 'Roberto Martinez', 'rating': 4.9, 'status': 'available', 'specialty': 'Landscaping', 'eta': '2 hours', 'lat': 40.4360, 'lng': -79.9950, 'jobs': 450},
            {'name': 'Amanda Johnson', 'rating': 4.8, 'status': 'available', 'specialty': 'House Cleaning', 'eta': '4 hours', 'lat': 40.4420, 'lng': -79.9880, 'jobs': 680},
            {'name': 'Frank Thompson', 'rating': 4.7, 'status': 'busy', 'specialty': 'Handyman', 'eta': '6 hours', 'lat': 40.4300, 'lng': -80.0020, 'jobs': 320},
            {'name': 'Grace Liu', 'rating': 4.9, 'status': 'available', 'specialty': 'Deep Cleaning', 'eta': '3 hours', 'lat': 40.4470, 'lng': -79.9780, 'jobs': 520},
            {'name': 'Steve Adams', 'rating': 4.6, 'status': 'available', 'specialty': 'Pressure Washing', 'eta': '5 hours', 'lat': 40.4250, 'lng': -80.0100, 'jobs': 180}
        ],
        'moving_help': [
            {'name': 'Tony Ricci', 'rating': 4.8, 'status': 'available', 'crew_size': 3, 'eta': '1 hour', 'lat': 40.4390, 'lng': -79.9930, 'moves': 280},
            {'name': 'Malik Jones', 'rating': 4.9, 'status': 'available', 'crew_size': 2, 'eta': '45 min', 'lat': 40.4440, 'lng': -79.9850, 'moves': 195},
            {'name': 'Carlos Mendez', 'rating': 4.7, 'status': 'busy', 'crew_size': 4, 'eta': '3 hours', 'lat': 40.4320, 'lng': -80.0060, 'moves': 340},
            {'name': 'Ryan O\'Connor', 'rating': 4.8, 'status': 'available', 'crew_size': 2, 'eta': '2 hours', 'lat': 40.4490, 'lng': -79.9770, 'moves': 150},
            {'name': 'Hassan Ali', 'rating': 4.6, 'status': 'available', 'crew_size': 3, 'eta': '90 min', 'lat': 40.4270, 'lng': -80.0090, 'moves': 220}
        ],
        'other_tasks': [
            {'name': 'Jessica Reed', 'rating': 4.8, 'status': 'available', 'skills': 'Assembly, Tech', 'eta': '90 min', 'lat': 40.4410, 'lng': -79.9890, 'tasks': 320},
            {'name': 'Dan Foster', 'rating': 4.7, 'status': 'available', 'skills': 'Pet Care, Errands', 'eta': '30 min', 'lat': 40.4370, 'lng': -79.9970, 'tasks': 450},
            {'name': 'Emily Davis', 'rating': 4.9, 'status': 'busy', 'skills': 'Organization, Events', 'eta': '4 hours', 'lat': 40.4460, 'lng': -79.9810, 'tasks': 280},
            {'name': 'Kevin Lee', 'rating': 4.6, 'status': 'available', 'skills': 'Tech Setup, Assembly', 'eta': '2 hours', 'lat': 40.4290, 'lng': -80.0070, 'tasks': 180},
            {'name': 'Sofia Patel', 'rating': 4.8, 'status': 'available', 'skills': 'Shopping, Errands', 'eta': '45 min', 'lat': 40.4510, 'lng': -79.9740, 'tasks': 390}
        ]
    }

def create_provider_map(service_type, providers=None):
    """Create a map showing only providers for the selected service type"""
    if not providers:
        providers = get_service_providers()[service_type]
    
    # Define colors for different statuses
    colors = {'available': '#10b981', 'busy': '#f59e0b'}
    
    # Prepare data for the map
    lats = [p['lat'] for p in providers]
    lngs = [p['lng'] for p in providers]
    names = [p['name'] for p in providers]
    statuses = [p['status'] for p in providers]
    colors_list = [colors.get(status, '#6b7280') for status in statuses]
    
    # Service-specific hover info
    if service_type == 'ride_hailing':
        hover_text = [f"{p['name']}<br>⭐ {p['rating']} • {p['vehicle']}<br>ETA: {p['eta']}" for p in providers]
    elif service_type == 'deliveries':
        hover_text = [f"{p['name']}<br>⭐ {p['rating']} • {p['vehicle']}<br>ETA: {p['eta']}" for p in providers]
    elif service_type == 'home_services':
        hover_text = [f"{p['name']}<br>⭐ {p['rating']} • {p['specialty']}<br>Available: {p['eta']}" for p in providers]
    elif service_type == 'moving_help':
        hover_text = [f"{p['name']}<br>⭐ {p['rating']} • {p['crew_size']} person crew<br>Available: {p['eta']}" for p in providers]
    else:  # other_tasks
        hover_text = [f"{p['name']}<br>⭐ {p['rating']} • {p['skills']}<br>Available: {p['eta']}" for p in providers]
    
    # Create the map
    fig = go.Figure()
    
    # Add provider markers
    fig.add_trace(go.Scattermapbox(
        lat=lats,
        lon=lngs,
        mode='markers',
        marker=dict(
            size=12,
            color=colors_list,
            opacity=0.8
        ),
        text=hover_text,
        hovertemplate='%{text}<extra></extra>',
        name=f"{service_type.replace('_', ' ').title()} Providers"
    ))
    
    # Add user location
    fig.add_trace(go.Scattermapbox(
        lat=[40.4406],
        lon=[-79.9959],
        mode='markers',
        marker=dict(
            size=15,
            color='#667eea',
            symbol='circle'
        ),
        text=['Your Location'],
        hovertemplate='Your Location<extra></extra>',
        name="You"
    ))
    
    fig.update_layout(
        mapbox=dict(
            style="open-street-map",
            center=dict(lat=40.4406, lon=-79.9959),
            zoom=12
        ),
        height=350,
        margin=dict(l=0, r=0, t=0, b=0),
        showlegend=False
    )
    
    return fig

def get_pittsburgh_address_suggestions(query):
    """Get Pittsburgh address suggestions based on user input"""
    if not query or len(query) < 2:
        return []
    
    # Common Pittsburgh addresses and landmarks
    pittsburgh_addresses = [
        "4800 Baum Blvd, Pittsburgh, PA",
        "4801 Walnut St, Pittsburgh, PA", 
        "4803 Germantown Ave, Pittsburgh, PA",
        "4800 Chestnut St, Pittsburgh, PA",
        "4800 Pine St, Pittsburgh, PA",
        "4805 Liberty Ave, Pittsburgh, PA",
        "4810 Fifth Ave, Pittsburgh, PA",
        "4815 Forbes Ave, Pittsburgh, PA",
        "4820 Penn Ave, Pittsburgh, PA",
        "4825 Carson St, Pittsburgh, PA",
        "1 PPG Place, Pittsburgh, PA",
        "600 Grant St, Pittsburgh, PA",
        "100 Art Rooney Ave, Pittsburgh, PA",
        "115 Federal St, Pittsburgh, PA",
        "1835 E Carson St, Pittsburgh, PA",
        "5800 Fifth Ave, Pittsburgh, PA",
        "4400 Forbes Ave, Pittsburgh, PA",
        "3943 Forbes Ave, Pittsburgh, PA",
        "5032 Centre Ave, Pittsburgh, PA",
        "700 River Ave, Pittsburgh, PA",
        "Pittsburgh International Airport, PA",
        "University of Pittsburgh, PA",
        "Carnegie Mellon University, PA",
        "Heinz Field, Pittsburgh, PA",
        "PNC Park, Pittsburgh, PA",
        "PPG Paints Arena, Pittsburgh, PA",
        "Strip District, Pittsburgh, PA",
        "Oakland, Pittsburgh, PA",
        "Shadyside, Pittsburgh, PA",
        "Squirrel Hill, Pittsburgh, PA",
        "Lawrenceville, Pittsburgh, PA",
        "Downtown Pittsburgh, PA",
        "Point State Park, Pittsburgh, PA",
        "Duquesne University, Pittsburgh, PA",
        "UPMC Presbyterian, Pittsburgh, PA",
        "Allegheny General Hospital, PA",
        "South Side Works, Pittsburgh, PA",
        "Waterfront Shopping, Homestead, PA",
        "Robinson Town Centre, Pittsburgh, PA"
    ]
    
    query_lower = query.lower()
    suggestions = []
    
    for address in pittsburgh_addresses:
        if query_lower in address.lower():
            suggestions.append(address)
            if len(suggestions) >= 6:  # Limit to 6 suggestions like Uber
                break
    
    return suggestions

def smart_address_input(label, placeholder, key):
    """Create a smart address input with autocomplete suggestions"""
    
    # Check if an address was previously selected
    selected_address = st.session_state.get(f"{key}_selected", "")
    
    # Create a text input with the selected address as default
    user_input = st.text_input(label, value=selected_address, placeholder=placeholder, key=key)
    
    # Get suggestions if user has typed something and hasn't selected an address yet
    if user_input and len(user_input) >= 2 and user_input != selected_address:
        suggestions = get_pittsburgh_address_suggestions(user_input)
        
        if suggestions:
            # Create a modern dropdown-style suggestion list
            st.markdown('<div style="margin-top: -10px; margin-bottom: 15px;">', unsafe_allow_html=True)
            
            # Create styled suggestion container
            suggestion_container = """
            <div style="
                background: white;
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
                max-height: 180px;
                overflow-y: auto;
                font-family: 'Inter', sans-serif;
            ">
            """
            
            # Add title
            suggestion_container += """
            <div style="
                padding: 8px 16px;
                background: #f9fafb;
                border-bottom: 1px solid #e5e7eb;
                font-size: 0.85rem;
                font-weight: 600;
                color: #6b7280;
            ">
                📍 Suggested addresses
            </div>
            """
            
            # Add suggestions
            for i, suggestion in enumerate(suggestions):
                suggestion_container += f"""
                <div style="
                    padding: 12px 16px;
                    border-bottom: 1px solid #f3f4f6;
                    color: #374151;
                    font-size: 0.9rem;
                    transition: background-color 0.15s ease;
                    cursor: pointer;
                " 
                class="suggestion-item"
                data-address="{suggestion}">
                    {suggestion}
                </div>
                """
            
            suggestion_container += "</div>"
            st.markdown(suggestion_container, unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)
            
            # Show clickable buttons for each suggestion in a more compact way
            for i, suggestion in enumerate(suggestions[:3]):  # Show only top 3 as buttons
                if st.button(f"📍 {suggestion}", key=f"{key}_select_{i}", help="Click to select this address"):
                    st.session_state[f"{key}_selected"] = suggestion
                    st.rerun()
    
    # Clear selection if user starts typing something new
    if user_input != selected_address and len(user_input) >= 2:
        if f"{key}_selected" in st.session_state:
            del st.session_state[f"{key}_selected"]
    
    return user_input

# GPS Tracking and Mapping Functions
def simulate_provider_movement(provider_id, start_lat, start_lng, end_lat, end_lng, progress=0.0):
    """Simulate provider movement along a route"""
    # Linear interpolation between start and end points
    current_lat = start_lat + (end_lat - start_lat) * progress
    current_lng = start_lng + (end_lng - start_lng) * progress
    
    # Add slight randomness to simulate real GPS movement
    lat_noise = random.uniform(-0.0005, 0.0005)
    lng_noise = random.uniform(-0.0005, 0.0005)
    
    return {
        'lat': current_lat + lat_noise,
        'lng': current_lng + lng_noise,
        'progress': progress,
        'timestamp': datetime.now()
    }

def calculate_distance(lat1, lng1, lat2, lng2):
    """Calculate distance between two GPS coordinates in miles"""
    # Using Haversine formula
    R = 3959  # Earth's radius in miles
    
    dlat = math.radians(lat2 - lat1)
    dlng = math.radians(lng2 - lng1)
    a = (math.sin(dlat / 2) * math.sin(dlat / 2) +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
         math.sin(dlng / 2) * math.sin(dlng / 2))
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    distance = R * c
    
    return distance

def calculate_eta(current_lat, current_lng, dest_lat, dest_lng, avg_speed_mph=25):
    """Calculate ETA based on current location and destination"""
    distance = calculate_distance(current_lat, current_lng, dest_lat, dest_lng)
    eta_hours = distance / avg_speed_mph
    eta_minutes = eta_hours * 60
    return max(1, int(eta_minutes))  # At least 1 minute

def generate_route_points(start_lat, start_lng, end_lat, end_lng, num_points=10):
    """Generate intermediate points along a route"""
    route_points = []
    for i in range(num_points + 1):
        progress = i / num_points
        lat = start_lat + (end_lat - start_lat) * progress
        lng = start_lng + (end_lng - start_lng) * progress
        route_points.append({'lat': lat, 'lng': lng})
    return route_points

def create_live_tracking_map(service_type, provider_location, user_location, destination_location=None):
    """Create a live tracking map with provider and user locations"""
    fig = go.Figure()
    
    # Add user location
    fig.add_trace(go.Scattermapbox(
        lat=[user_location['lat']],
        lon=[user_location['lng']],
        mode='markers',
        marker=dict(
            size=15,
            color='#667eea',
            symbol='circle'
        ),
        text=['Your Location'],
        hovertemplate='Your Location<extra></extra>',
        name="You",
        showlegend=True
    ))
    
    # Add provider location with movement animation
    if provider_location:
        provider_color = '#10b981' if service_type in ['ride_hailing', 'deliveries'] else '#f59e0b'
        provider_symbol = 'car' if service_type == 'ride_hailing' else 'marker'
        
        fig.add_trace(go.Scattermapbox(
            lat=[provider_location['lat']],
            lon=[provider_location['lng']],
            mode='markers',
            marker=dict(
                size=18,
                color=provider_color,
                symbol=provider_symbol
            ),
            text=[f'Service Provider (Moving)'],
            hovertemplate='Service Provider<br>Last updated: %{text}<extra></extra>',
            name="Provider",
            showlegend=True
        ))
    
    # Add destination if provided
    if destination_location:
        fig.add_trace(go.Scattermapbox(
            lat=[destination_location['lat']],
            lon=[destination_location['lng']],
            mode='markers',
            marker=dict(
                size=15,
                color='#ef4444',
                symbol='circle'
            ),
            text=['Destination'],
            hovertemplate='Destination<extra></extra>',
            name="Destination",
            showlegend=True
        ))
        
        # Add route line if provider location exists
        if provider_location:
            route_points = generate_route_points(
                provider_location['lat'], provider_location['lng'],
                destination_location['lat'], destination_location['lng']
            )
            
            route_lats = [point['lat'] for point in route_points]
            route_lngs = [point['lng'] for point in route_points]
            
            fig.add_trace(go.Scattermapbox(
                lat=route_lats,
                lon=route_lngs,
                mode='lines',
                line=dict(
                    width=3,
                    color='#667eea'
                ),
                name="Route",
                showlegend=False,
                hoverinfo='skip'
            ))
    
    # Calculate center point for map
    all_lats = [user_location['lat']]
    all_lngs = [user_location['lng']]
    
    if provider_location:
        all_lats.append(provider_location['lat'])
        all_lngs.append(provider_location['lng'])
    
    if destination_location:
        all_lats.append(destination_location['lat'])
        all_lngs.append(destination_location['lng'])
    
    center_lat = sum(all_lats) / len(all_lats)
    center_lng = sum(all_lngs) / len(all_lngs)
    
    fig.update_layout(
        mapbox=dict(
            style="open-street-map",
            center=dict(lat=center_lat, lon=center_lng),
            zoom=13
        ),
        height=400,
        margin=dict(l=0, r=0, t=0, b=0),
        showlegend=True,
        legend=dict(
            yanchor="top",
            y=0.99,
            xanchor="left",
            x=0.01,
            bgcolor="rgba(255,255,255,0.8)"
        )
    )
    
    return fig

def start_tracking_simulation(service_type, provider_name):
    """Start tracking simulation for a service"""
    # Initialize provider location near user
    user_lat = st.session_state.user_location['lat']
    user_lng = st.session_state.user_location['lng']
    
    # Provider starts slightly away from user
    provider_lat = user_lat + random.uniform(-0.01, 0.01)
    provider_lng = user_lng + random.uniform(-0.01, 0.01)
    
    st.session_state.provider_location = {
        'lat': provider_lat,
        'lng': provider_lng,
        'provider_name': provider_name,
        'service_type': service_type,
        'status': 'en_route',
        'progress': 0.0,
        'start_time': datetime.now()
    }
    
    st.session_state.tracking_active = True
    
def update_provider_location():
    """Update provider location during tracking"""
    if not st.session_state.tracking_active or not st.session_state.provider_location:
        return
    
    provider_loc = st.session_state.provider_location
    user_loc = st.session_state.user_location
    
    # Simulate movement towards user
    elapsed_time = (datetime.now() - provider_loc['start_time']).seconds
    movement_speed = 0.01  # Adjust speed of simulation
    
    # Calculate new position
    if provider_loc['progress'] < 1.0:
        provider_loc['progress'] = min(1.0, elapsed_time * movement_speed / 60)  # Progress over time
        
        new_location = simulate_provider_movement(
            'provider_1',
            provider_loc['lat'],
            provider_loc['lng'],
            user_loc['lat'],
            user_loc['lng'],
            provider_loc['progress']
        )
        
        provider_loc['lat'] = new_location['lat']
        provider_loc['lng'] = new_location['lng']
        
        # Update ETA
        eta = calculate_eta(provider_loc['lat'], provider_loc['lng'], 
                           user_loc['lat'], user_loc['lng'])
        provider_loc['eta'] = eta
        
        if provider_loc['progress'] >= 0.95:
            provider_loc['status'] = 'arriving'
        elif provider_loc['progress'] >= 1.0:
            provider_loc['status'] = 'arrived'

def show_service_details():
    # Back button
    if st.button("← Back to Services"):
        st.session_state.booking_stage = 'service_selection'
        st.session_state.current_service = None
        st.rerun()
    
    service = st.session_state.current_service
    
    if service == 'ride_hailing':
        show_ride_hailing_form()
    elif service == 'deliveries':
        show_deliveries_form()
    elif service == 'home_services':
        show_home_services_form()
    elif service == 'moving_help':
        show_moving_help_form()
    elif service == 'other_tasks':
        show_other_tasks_form()

def show_ride_hailing_form():
    st.markdown("## 🚗 Request a Ride")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Smart address inputs with autocomplete
        pickup_location = smart_address_input("📍 Pickup Location", "Enter pickup address", "pickup_location")
        dropoff_location = smart_address_input("📍 Drop-off Location", "Where to?", "dropoff_location")
        
        # Ride type selection
        ride_type = st.selectbox("🚙 Vehicle Type", 
                               ["Standard", "Premium", "XL (6+ passengers)", "Wheelchair Accessible"])
        
        # Scheduling
        schedule_option = st.radio("⏰ When?", ["Now", "Schedule for later"])
        
        if schedule_option == "Schedule for later":
            schedule_date = st.date_input("Date", min_value=datetime.now().date())
            schedule_time = st.time_input("Time")
        
        # Special requests
        special_requests = st.text_area("Special Requests (Optional)", 
                                      placeholder="Pet-friendly, child seat needed, etc.")
    
    with col2:
        # Service-specific provider map
        st.markdown('<div class="section-header">Available Drivers</div>', unsafe_allow_html=True)
        
        # Show service-specific providers on map
        providers = get_service_providers()['ride_hailing']
        available_providers = [p for p in providers if p['status'] == 'available']
        
        if available_providers:
            # Create map with only ride-hailing providers
            fig = create_provider_map('ride_hailing', providers)
            st.plotly_chart(fig, use_container_width=True)
            
            # Provider list
            st.markdown("**Nearest Drivers:**")
            for provider in available_providers[:3]:
                status_class = "status-online" if provider['status'] == 'available' else "status-busy"
                provider_html = f"""
                <div class="provider-card">
                    <strong>{provider['name']}</strong> ⭐ {provider['rating']}<br>
                    <span class="{status_class}">{provider['vehicle']} • {provider['eta']}</span>
                </div>
                """
                st.markdown(provider_html, unsafe_allow_html=True)
        else:
            st.info("Enter pickup and drop-off locations to see route preview")
    
    # Calculate fare estimate using Pittsburgh pricing model
    # Base fare + per mile + per minute formula
    base_fare = 2.50
    distance_miles = 4.2  # Example distance
    time_minutes = 15     # Example time
    
    # Calculate base ride fare
    ride_fare = base_fare + (distance_miles * 1.50) + (time_minutes * 0.30)
    
    # Apply vehicle type multipliers
    if ride_type == "Premium":
        ride_fare *= 1.4
    elif ride_type == "XL (6+ passengers)":
        ride_fare *= 1.6
    elif ride_type == "Wheelchair Accessible":
        ride_fare *= 1.3
    
    # Fare estimate display
    if pickup_location and dropoff_location:
        st.markdown("### Fare Estimate")
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Fare", f"${ride_fare:.2f}")
        with col2:
            st.metric("Est. Time", f"{time_minutes} min")
        with col3:
            st.metric("Distance", f"{distance_miles} miles")
    
    # Book ride button
    if st.button("🚗 Request Ride", type="primary", use_container_width=True):
        if pickup_location and dropoff_location:
            st.session_state.booking_details = {
                'service_type': 'Ride-Hailing',
                'pickup': pickup_location,
                'dropoff': dropoff_location,
                'vehicle_type': ride_type,
                'fare_estimate': f"${ride_fare:.2f}",
                'special_requests': special_requests
            }
            st.session_state.booking_stage = 'booking_confirmation'
            st.rerun()
        else:
            st.error("Please enter both pickup and drop-off locations")

def show_deliveries_form():
    st.markdown("## 📦 Delivery & Errands")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Delivery type
        delivery_type = st.selectbox("📦 Service Type", 
                                   ["Package Delivery", "Food Delivery", "Marketplace Pickup", 
                                    "Grocery Shopping", "Document Delivery"])
        
        # Smart address inputs with autocomplete
        pickup_location = smart_address_input("📍 Pickup Location", "Where should we collect the item?", "delivery_pickup")
        dropoff_location = smart_address_input("📍 Delivery Location", "Where should we deliver?", "delivery_dropoff")
        
        # Item details
        st.markdown("### Item Details")
        item_description = st.text_area("What needs to be delivered?", 
                                       placeholder="Describe the item(s) to be picked up and delivered")
        
        col_size, col_weight = st.columns(2)
        with col_size:
            item_size = st.selectbox("📏 Size", ["Small (fits in car)", "Medium (SUV needed)", "Large (truck needed)"])
        with col_weight:
            item_weight = st.selectbox("⚖️ Weight", ["Light (<20 lbs)", "Medium (20-50 lbs)", "Heavy (50+ lbs)"])
        
        # Special instructions
        special_instructions = st.text_area("Special Instructions", 
                                          placeholder="Fragile, keep upright, apartment buzzer code, etc.")
        
        # Urgency
        urgency = st.radio("⏰ When?", ["ASAP", "Within 2 hours", "Schedule for later"])
        
        if urgency == "Schedule for later":
            schedule_date = st.date_input("Preferred Date", min_value=datetime.now().date())
            schedule_time = st.time_input("Preferred Time")
    
    with col2:
        # Service-specific provider map
        st.markdown('<div class="section-header">Available Delivery Partners</div>', unsafe_allow_html=True)
        
        # Show delivery providers on map
        providers = get_service_providers()['deliveries']
        available_providers = [p for p in providers if p['status'] == 'available']
        
        if available_providers:
            fig = create_provider_map('deliveries', providers)
            st.plotly_chart(fig, use_container_width=True)
            
            # Provider list
            st.markdown("**Nearest Partners:**")
            for provider in available_providers[:2]:
                status_class = "status-online" if provider['status'] == 'available' else "status-busy"
                provider_html = f"""
                <div class="provider-card">
                    <strong>{provider['name']}</strong> ⭐ {provider['rating']}<br>
                    <span class="{status_class}">{provider['vehicle']} • {provider['eta']}</span>
                </div>
                """
                st.markdown(provider_html, unsafe_allow_html=True)
        
        # Pricing estimate using Pittsburgh delivery model
        st.markdown("### Delivery Estimate")
        
        # Base fee + per mile formula
        base_fee = 6.00
        distance_miles = 4.0  # Example distance
        delivery_cost = base_fee + (distance_miles * 1.20)
        
        # Size surcharges
        if item_size == "Medium (SUV needed)":
            delivery_cost += 3.00
        elif item_size == "Large (truck needed)":
            delivery_cost += 8.00
        
        # Urgency surcharge (25-50% surge pricing)
        if urgency == "ASAP":
            delivery_cost *= 1.35
        
        st.metric("Estimated Cost", f"${delivery_cost:.2f}")
        st.metric("Est. Time", "15-45 min" if urgency == "ASAP" else "As scheduled")
    
    # Request delivery button
    if st.button("📦 Request Delivery", type="primary", use_container_width=True):
        if pickup_location and dropoff_location and item_description:
            st.session_state.booking_details = {
                'service_type': 'Delivery & Errands',
                'delivery_type': delivery_type,
                'pickup': pickup_location,
                'dropoff': dropoff_location,
                'item_description': item_description,
                'size': item_size,
                'weight': item_weight,
                'cost_estimate': f"${delivery_cost:.2f}",
                'special_instructions': special_instructions
            }
            st.session_state.booking_stage = 'booking_confirmation'
            st.rerun()
        else:
            st.error("Please fill in all required fields")

def show_home_services_form():
    st.markdown("## 🏠 Home Services")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Service category
        service_category = st.selectbox("🛠️ Service Type", 
                                      ["Lawn Care", "Cleaning", "Handyman", "Gardening", 
                                       "Snow Removal", "Pressure Washing", "Gutter Cleaning"])
        
        # Smart address input with autocomplete
        service_location = smart_address_input("📍 Service Address", "Where is the work needed?", "service_location")
        
        # Task description
        st.markdown("### Task Details")
        task_description = st.text_area("Describe the work needed", 
                                       placeholder="Be specific about what needs to be done...")
        
        # Property details
        col_size, col_access = st.columns(2)
        with col_size:
            property_size = st.selectbox("🏡 Property Size", ["Small", "Medium", "Large", "Commercial"])
        with col_access:
            access_notes = st.text_input("Access Notes", placeholder="Gate code, key location, etc.")
        
        # Scheduling preferences
        st.markdown("### Scheduling")
        scheduling = st.radio("⏰ Preferred Time", ["This Week", "Next Week", "Flexible", "Recurring Service"])
        
        if scheduling == "Recurring Service":
            frequency = st.selectbox("How Often?", ["Weekly", "Bi-weekly", "Monthly", "Seasonally"])
        
        preferred_time = st.selectbox("Time of Day", ["Morning (8AM-12PM)", "Afternoon (12PM-5PM)", "Evening (5PM-8PM)", "Anytime"])
        
        # Budget
        budget_range = st.selectbox("💰 Budget Range", ["$50-100", "$100-200", "$200-500", "$500+", "Get Quote"])
    
    # Calculate estimated cost using Pittsburgh pricing model
    # Flat rates for small/medium jobs, hourly for larger jobs
    service_rates = {
        "Lawn Care": {"small": 35, "medium": 45, "large": 65, "commercial": 150},
        "Cleaning": {"small": 80, "medium": 120, "large": 180, "commercial": 300},
        "Handyman": {"small": 85, "medium": 125, "large": 200, "commercial": 350},
        "Gardening": {"small": 40, "medium": 60, "large": 90, "commercial": 200},
        "Snow Removal": {"small": 30, "medium": 45, "large": 70, "commercial": 150},
        "Pressure Washing": {"small": 120, "medium": 180, "large": 250, "commercial": 450},
        "Gutter Cleaning": {"small": 90, "medium": 130, "large": 200, "commercial": 350}
    }
    
    # Map property size to pricing tier
    size_mapping = {
        "Small": "small",
        "Medium": "medium", 
        "Large": "large",
        "Commercial": "commercial"
    }
    
    size_tier = size_mapping.get(property_size, "medium")
    base_cost = service_rates.get(service_category, {"small": 50, "medium": 75, "large": 125, "commercial": 250})[size_tier]
    
    with col2:
        # Service-specific provider map
        st.markdown('<div class="section-header">Available Specialists</div>', unsafe_allow_html=True)
        
        # Show home service providers on map
        providers = get_service_providers()['home_services']
        available_providers = [p for p in providers if p['status'] == 'available']
        
        if available_providers:
            fig = create_provider_map('home_services', providers)
            st.plotly_chart(fig, use_container_width=True)
            
            # Provider list
            st.markdown("**Qualified Specialists:**")
            for provider in available_providers[:2]:
                status_class = "status-online" if provider['status'] == 'available' else "status-busy"
                provider_html = f"""
                <div class="provider-card">
                    <strong>{provider['name']}</strong> ⭐ {provider['rating']}<br>
                    <span class="{status_class}">{provider['specialty']} • {provider['eta']}</span>
                </div>
                """
                st.markdown(provider_html, unsafe_allow_html=True)
        
        # Pricing estimate
        st.markdown("### Service Estimate")
        if service_location and task_description:
            st.metric("Estimated Cost", f"${base_cost:.0f}")
            st.metric("Available Time", preferred_time)
        else:
            st.info("Enter service details to see estimate")
    
    # Book service button
    if st.button("🏠 Book Service", type="primary", use_container_width=True):
        if service_location and task_description:
            st.session_state.booking_details = {
                'service_type': 'Home Services',
                'category': service_category,
                'location': service_location,
                'description': task_description,
                'property_size': property_size,
                'preferred_time': preferred_time,
                'cost_estimate': f"${base_cost:.0f}",
                'budget_range': budget_range
            }
            st.session_state.booking_stage = 'booking_confirmation'
            st.rerun()
        else:
            st.error("Please provide service location and task description")

def show_moving_help_form():
    st.markdown("## 📦 Moving Help")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Moving type
        moving_type = st.selectbox("🚚 Service Type", 
                                 ["Labor Only (I have truck)", "Truck + Labor", "Full Service Move"])
        
        # Smart address inputs with autocomplete
        origin_location = smart_address_input("📍 Moving From", "Origin address", "moving_origin")
        destination_location = smart_address_input("📍 Moving To", "Destination address", "moving_destination")
        
        # Move details
        st.markdown("### Move Details")
        home_size = st.selectbox("🏠 Home Size", ["Studio/1BR", "2BR", "3BR", "4+ BR", "Commercial"])
        
        # Item inventory
        st.markdown("#### Major Items (Check all that apply)")
        col_items1, col_items2 = st.columns(2)
        
        with col_items1:
            heavy_furniture = st.checkbox("Heavy Furniture (couch, dresser)")
            appliances = st.checkbox("Appliances (fridge, washer)")
            piano = st.checkbox("Piano/Heavy Instruments")
            fragile_items = st.checkbox("Fragile/Valuable Items")
        
        with col_items2:
            boxes = st.number_input("Number of Boxes", min_value=0, value=0)
            stairs = st.checkbox("Stairs at origin or destination")
            long_carry = st.checkbox("Long carry (50+ feet from truck)")
            assembly = st.checkbox("Furniture disassembly/assembly needed")
        
        # Special requirements
        special_requirements = st.text_area("Special Requirements", 
                                          placeholder="Elevator reservations, parking permits, fragile handling, etc.")
        
        # Date and time
        st.markdown("### Scheduling")
        move_date = st.date_input("Move Date", min_value=datetime.now().date())
        move_time = st.selectbox("Preferred Start Time", 
                               ["8:00 AM", "10:00 AM", "12:00 PM", "2:00 PM", "4:00 PM"])
        
        # Duration estimate
        duration_estimate = st.selectbox("Estimated Duration", 
                                       ["2-3 hours", "3-4 hours", "4-6 hours", "6-8 hours", "Full Day"])
    
    with col2:
        # Service-specific provider map
        st.markdown('<div class="section-header">Available Moving Teams</div>', unsafe_allow_html=True)
        
        # Show moving providers on map
        providers = get_service_providers()['moving_help']
        available_providers = [p for p in providers if p['status'] == 'available']
        
        if available_providers:
            fig = create_provider_map('moving_help', providers)
            st.plotly_chart(fig, use_container_width=True)
            
            # Provider list
            st.markdown("**Available Teams:**")
            for provider in available_providers[:2]:
                status_class = "status-online" if provider['status'] == 'available' else "status-busy"
                provider_html = f"""
                <div class="provider-card">
                    <strong>{provider['name']}</strong> ⭐ {provider['rating']}<br>
                    <span class="{status_class}">{provider['crew_size']} person crew • {provider['eta']}</span>
                </div>
                """
                st.markdown(provider_html, unsafe_allow_html=True)
        
        # Cost estimation using Pittsburgh pricing model
        st.markdown("### Move Estimate")
        
        # Pittsburgh model: $20 booking + $35/hour/person + $1.50/mile transport
        booking_fee = 20.00
        hourly_rate = 35.00  # per person
        distance_miles = 8.0  # Example distance
        estimated_hours = 3.0  # Based on home size
        
        # Estimate hours based on home size
        hour_estimates = {
            "Studio/1BR": 2.0,
            "2BR": 3.0,
            "3BR": 4.0,
            "4+ BR": 6.0,
            "Commercial": 8.0
        }
        estimated_hours = hour_estimates.get(home_size, 3.0)
        
        # Team size based on home size
        team_sizes = {
            "Studio/1BR": 2,
            "2BR": 2,
            "3BR": 3,
            "4+ BR": 3,
            "Commercial": 4
        }
        team_size = team_sizes.get(home_size, 2)
        
        # Calculate total cost
        labor_cost = hourly_rate * team_size * estimated_hours
        transport_cost = distance_miles * 1.50 if moving_type != "Labor Only (I have truck)" else 0
        
        if moving_type == "Labor Only (I have truck)":
            total_cost = labor_cost  # No booking fee or transport for labor only
        else:
            total_cost = booking_fee + labor_cost + transport_cost
        
        # Additional fees
        if stairs:
            total_cost += 50
        if piano:
            total_cost += 150  # Piano surcharge
        if long_carry:
            total_cost += 75
        if assembly:
            total_cost += 100
        
        st.metric("Estimated Cost", f"${total_cost:.0f}")
        st.metric("Team Size", f"{team_size} movers")
        st.metric("Est. Duration", f"{estimated_hours:.0f} hours")
        
        # Breakdown
        st.markdown("**Cost Breakdown:**")
        if moving_type != "Labor Only (I have truck)":
            st.write(f"• Booking fee: ${booking_fee:.0f}")
            st.write(f"• Transport: ${transport_cost:.0f}")
        st.write(f"• Labor: ${labor_cost:.0f}")
        
        # Insurance info
        st.info("💼 Basic liability coverage included")
    
    # Book moving help button
    if st.button("📦 Book Moving Help", type="primary", use_container_width=True):
        if origin_location and destination_location:
            st.session_state.booking_details = {
                'service_type': 'Moving Help',
                'moving_type': moving_type,
                'origin': origin_location,
                'destination': destination_location,
                'home_size': home_size,
                'move_date': str(move_date),
                'move_time': move_time,
                'cost_estimate': f"${total_cost:.0f}",
                'special_requirements': special_requirements
            }
            st.session_state.booking_stage = 'booking_confirmation'
            st.rerun()
        else:
            st.error("Please provide both origin and destination addresses")

def show_other_tasks_form():
    st.markdown("## ⚡ Other Tasks")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Task category
        task_category = st.selectbox("🔧 Task Category", 
                                   ["Furniture Assembly", "Tech Setup", "Pet Services", "Errands & Shopping", 
                                    "Organization", "Event Help", "Custom Task"])
        
        # Smart address input with autocomplete
        task_location = smart_address_input("📍 Task Location", "Where is the task?", "task_location")
        
        # Task description
        st.markdown("### Task Description")
        task_description = st.text_area("Describe what you need help with", 
                                       placeholder="Be as detailed as possible about the task...")
        
        # Task requirements
        st.markdown("### Requirements")
        col_req1, col_req2 = st.columns(2)
        
        with col_req1:
            tools_needed = st.checkbox("Worker should bring tools")
            experience_required = st.checkbox("Specific experience required")
            background_check = st.checkbox("Background check required")
        
        with col_req2:
            supplies_needed = st.checkbox("Worker should bring supplies")
            insurance_required = st.checkbox("Insurance required")
            references_needed = st.checkbox("References preferred")
        
        # Additional details
        additional_details = st.text_area("Additional Details", 
                                        placeholder="Access instructions, special requirements, etc.")
        
        # Scheduling
        st.markdown("### Scheduling")
        availability = st.radio("⏰ When do you need this done?", 
                               ["Today", "This Week", "Next Week", "Flexible"])
        
        if availability in ["This Week", "Next Week"]:
            preferred_days = st.multiselect("Preferred Days", 
                                          ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"])
            preferred_time = st.selectbox("Preferred Time", 
                                        ["Morning", "Afternoon", "Evening", "Anytime"])
        
        # Budget
        budget = st.selectbox("💰 Budget", ["$25-50", "$50-100", "$100-200", "$200+", "Get Quote"])
    
    # Pittsburgh pricing model: $25/hour for general chores
    hourly_rates = {
        "Furniture Assembly": 25,  # Flat $50 for typical job (2 hours)
        "Tech Setup": 30,         # Higher skill rate
        "Pet Services": 20,       # Lower rate for pet sitting
        "Errands & Shopping": 18,  # Shopping and errands
        "Organization": 22,       # Organizing tasks
        "Event Help": 20,         # Event assistance
        "Custom Task": 25         # General hourly rate
    }
    
    estimated_cost = hourly_rates.get(task_category, 25)
    
    with col2:
        # Service-specific provider map
        st.markdown('<div class="section-header">Available Taskers</div>', unsafe_allow_html=True)
        
        # Show task providers on map
        providers = get_service_providers()['other_tasks']
        available_providers = [p for p in providers if p['status'] == 'available']
        
        if available_providers:
            fig = create_provider_map('other_tasks', providers)
            st.plotly_chart(fig, use_container_width=True)
            
            # Provider list
            st.markdown("**Skilled Taskers:**")
            for provider in available_providers[:2]:
                status_class = "status-online" if provider['status'] == 'available' else "status-busy"
                provider_html = f"""
                <div class="provider-card">
                    <strong>{provider['name']}</strong> ⭐ {provider['rating']}<br>
                    <span class="{status_class}">{provider['skills']} • {provider['eta']}</span>
                </div>
                """
                st.markdown(provider_html, unsafe_allow_html=True)
        
        # Task estimate
        st.markdown("### Task Estimate")
        
        if task_description:
            st.metric("Est. Cost", f"${estimated_cost}/hr")
            st.metric("Duration", "1-3 hours")
            
            # Skills required
            if task_category == "Furniture Assembly":
                st.success("✓ Tools provided")
            elif task_category == "Tech Setup":
                st.success("✓ Tech-savvy workers")
            elif task_category == "Pet Services":
                st.success("✓ Pet experience verified")
        else:
            st.info("Enter task details to see estimate")
    
    # Book task button
    if st.button("⚡ Post Task", type="primary", use_container_width=True):
        if task_location and task_description:
            st.session_state.booking_details = {
                'service_type': 'Other Tasks',
                'category': task_category,
                'location': task_location,
                'description': task_description,
                'budget': budget,
                'availability': availability,
                'cost_estimate': f"${estimated_cost}/hr",
                'additional_details': additional_details
            }
            st.session_state.booking_stage = 'booking_confirmation'
            st.rerun()
        else:
            st.error("Please provide task location and description")

def show_booking_confirmation():
    st.markdown("## 📋 Booking Confirmation")
    
    details = st.session_state.booking_details
    
    # Booking summary
    st.markdown("### Booking Summary")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.info(f"**Service:** {details['service_type']}")
        
        if 'pickup' in details:
            st.write(f"**From:** {details['pickup']}")
        if 'dropoff' in details:
            st.write(f"**To:** {details['dropoff']}")
        if 'location' in details:
            st.write(f"**Location:** {details['location']}")
        if 'origin' in details:
            st.write(f"**From:** {details['origin']}")
            st.write(f"**To:** {details['destination']}")
        
        if 'description' in details:
            st.write(f"**Description:** {details['description']}")
        if 'category' in details:
            st.write(f"**Category:** {details['category']}")
        
        if 'cost_estimate' in details:
            st.write(f"**Estimated Cost:** {details['cost_estimate']}")
    
    with col2:
        st.markdown("### Payment Method")
        payment_method = st.selectbox("💳", ["Credit Card ****1234", "PayPal", "Apple Pay", "Google Pay"])
        
        # Tip option
        tip_amount = st.selectbox("💡 Tip", ["No tip", "15%", "20%", "25%", "Custom"])
    
    # Service provider assignment
    st.markdown("### Your Service Provider")
    if details['service_type'] == 'Ride-Hailing':
        st.info("🔍 Finding the best driver near you...")
    else:
        st.info("🔍 Matching you with qualified service providers...")
    
    # Terms and confirmation
    st.markdown("### Terms & Conditions")
    agree_terms = st.checkbox("I agree to the Terms of Service and Privacy Policy")
    
    # Confirm booking buttons
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("← Modify Booking", use_container_width=True):
            st.session_state.booking_stage = 'service_details'
            st.rerun()
    
    with col2:
        if st.button("✅ Confirm Booking", type="primary", use_container_width=True):
            if agree_terms:
                # Start GPS tracking when booking is confirmed
                service_type = st.session_state.current_service
                provider_name = "Mike Rodriguez" if service_type == 'ride_hailing' else "Service Provider"
                start_tracking_simulation(service_type, provider_name)
                st.session_state.booking_stage = 'booking_status'
                st.rerun()
            else:
                st.error("Please agree to the terms and conditions")

def show_booking_status():
    st.markdown("""
    <div class="service-header">
        <h2 style="margin: 0; color: #1e293b;">🎉 Booking Confirmed!</h2>
        <p style="color: #64748b; margin: 5px 0 0 0;">Your service has been successfully booked</p>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("<div style='margin: 20px 0;'></div>", unsafe_allow_html=True)
    
    # Update provider location if tracking is active
    if st.session_state.tracking_active:
        update_provider_location()
    
    # Booking details
    booking_id = f"AS{datetime.now().strftime('%Y%m%d%H%M')}"
    service_type = st.session_state.current_service
    
    # Get provider location and status
    provider_location = st.session_state.provider_location
    provider_status = 'En Route'
    eta_text = '5 min'
    
    if provider_location:
        if provider_location['status'] == 'arriving':
            provider_status = 'Arriving Soon'
            eta_text = 'Less than 1 min'
        elif provider_location['status'] == 'arrived':
            provider_status = 'Arrived'
            eta_text = 'Here now!'
        elif 'eta' in provider_location:
            eta_text = f"{provider_location['eta']} min"
    
    # Mock provider details
    providers = {
        'ride_hailing': {'name': 'Mike Rodriguez', 'rating': 4.9, 'vehicle': 'Toyota Camry - ABC 123'},
        'deliveries': {'name': 'Sarah Kim', 'rating': 4.8, 'vehicle': 'Honda Civic - DEF 456'},
        'home_services': {'name': 'David Wilson', 'rating': 4.9, 'vehicle': 'Service Van - GHI 789'},
        'moving_help': {'name': 'Alex Johnson & Team', 'rating': 4.7, 'vehicle': 'Moving Truck - JKL 012'},
        'other_tasks': {'name': 'Jennifer Davis', 'rating': 4.8, 'vehicle': 'Personal Vehicle'}
    }
    
    provider = providers.get(service_type, providers['other_tasks'])
    
    # Real-time status and ETA
    status_color = '#10b981' if provider_status != 'Arrived' else '#667eea'
    status_icon = '🚗' if provider_status != 'Arrived' else '📍'
    
    col1, col2 = st.columns([1, 3])
    with col1:
        st.markdown(f"""
        <div style="
            background: linear-gradient(135deg, {status_color}, {status_color}ee);
            color: white;
            padding: 15px;
            border-radius: 12px;
            text-align: center;
            font-weight: 600;
        ">
            {status_icon} {provider_status}
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div style="padding: 15px 0;">
            <h3 style="color: #1e293b; margin: 0;">{provider['name']}</h3>
            <p style="color: #64748b; margin: 5px 0;">⭐ {provider['rating']} • ETA: {eta_text}</p>
            <p style="color: #64748b; margin: 0;">{provider['vehicle']}</p>
        </div>
        """, unsafe_allow_html=True)
    
    # Live GPS Tracking Map
    st.markdown("<div style='margin: 20px 0;'></div>", unsafe_allow_html=True)
    st.markdown("""
    <div style="
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        padding: 15px;
        margin-bottom: 20px;
    ">
        <h4 style="color: #1e293b; margin: 0 0 15px 0;">📍 Live GPS Tracking</h4>
    </div>
    """, unsafe_allow_html=True)
    
    # Create and display live tracking map
    if st.session_state.tracking_active and provider_location:
        user_loc = st.session_state.user_location
        destination_loc = None
        
        # Add destination for rides and deliveries
        if service_type in ['ride_hailing', 'deliveries'] and 'dropoff_address' in st.session_state.booking_details:
            # Use a mock destination coordinate near Pittsburgh
            destination_loc = {'lat': 40.4500, 'lng': -79.9900}  # Example destination
        
        live_map = create_live_tracking_map(service_type, provider_location, user_loc, destination_loc)
        st.plotly_chart(live_map, use_container_width=True)
        
        # Live updates info
        st.markdown(f"""
        <div style="
            background: #ecfdf5;
            border: 1px solid #10b981;
            border-radius: 8px;
            padding: 10px;
            margin-top: 10px;
            text-align: center;
            color: #065f46;
        ">
            🔄 Location updates automatically • Last update: {datetime.now().strftime('%I:%M:%S %p')}
        </div>
        """, unsafe_allow_html=True)
        
        # Manual refresh button for live tracking
        if provider_location['status'] != 'arrived':
            if st.button("🔄 Refresh Location", type="secondary", use_container_width=True):
                st.rerun()
    
    # Booking summary
    st.markdown("<div style='margin: 30px 0;'></div>", unsafe_allow_html=True)
    st.markdown(f"""
    <div style="
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        padding: 20px;
    ">
        <h4 style="color: #1e293b; margin: 0 0 15px 0;">📋 Booking Details</h4>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
            <div>
                <strong>Booking ID:</strong><br>
                <span style="color: #667eea; font-family: monospace;">{booking_id}</span>
            </div>
            <div>
                <strong>Service:</strong><br>
                {service_type.replace('_', ' ').title()}
            </div>
            <div>
                <strong>Booking Time:</strong><br>
                {datetime.now().strftime('%I:%M %p')}
            </div>
            <div>
                <strong>Status:</strong><br>
                <span style="color: #10b981; font-weight: 600;">Confirmed & Tracking</span>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Action buttons
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("🔄 Book Another Service", use_container_width=True):
            st.session_state.booking_stage = 'service_selection'
            st.session_state.current_service = None
            st.session_state.booking_details = {}
            st.session_state.tracking_active = False
            st.session_state.provider_location = None
            st.rerun()
    
    with col2:
        if st.button("📋 View All Bookings", use_container_width=True):
            st.info("Feature coming soon!")
    
    with col3:
        if st.button("❌ Cancel Booking", use_container_width=True):
            st.session_state.tracking_active = False
            st.session_state.provider_location = None
            st.error("Booking cancellation initiated")

if __name__ == "__main__":
    main()
