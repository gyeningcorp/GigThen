"""
AllServ Main Application - Real-time booking platform with database integration
"""
import streamlit as st
from datetime import datetime, timedelta
import time
import random
import json
import hashlib
import os
from database import get_db, User, Provider, Booking, Notification, init_sample_providers
from utils.pricing_utils import (
    calculate_ride_fare, 
    calculate_delivery_cost,
    calculate_home_service_cost,
    calculate_moving_cost
)
from utils.payment_utils import PaymentProcessor, calculate_pricing_breakdown, format_currency
import math

# Pittsburgh locations data
PITTSBURGH_LOCATIONS = [
    {"name": "Downtown Pittsburgh", "lat": 40.4406, "lng": -79.9959},
    {"name": "Pittsburgh Airport", "lat": 40.4943, "lng": -80.2659},
    {"name": "University of Pittsburgh", "lat": 40.4444, "lng": -79.9608},
    {"name": "Carnegie Mellon University", "lat": 40.4432, "lng": -79.9428},
]

def get_suggestions(query):
    """Get location suggestions"""
    if not query:
        return []
    q = query.lower()
    return [loc["name"] for loc in PITTSBURGH_LOCATIONS if q in loc["name"].lower()][:5]

def calculate_distance(lat1, lng1, lat2, lng2):
    """Calculate distance between coordinates in miles"""
    R = 3959
    dlat = math.radians(lat2 - lat1)
    dlng = math.radians(lng2 - lng1)
    a = (math.sin(dlat / 2) * math.sin(dlat / 2) +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
         math.sin(dlng / 2) * math.sin(dlng / 2))
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c

# Initialize database
init_sample_providers()

# Page config
st.set_page_config(
    page_title="AllServ - Real-Time Platform",
    page_icon="🚗",
    layout="wide"
)

# Initialize session state
if 'user' not in st.session_state:
    st.session_state.user = None
if 'current_booking' not in st.session_state:
    st.session_state.current_booking = None
if 'stage' not in st.session_state:
    st.session_state.stage = 'login'
if 'notifications' not in st.session_state:
    st.session_state.notifications = []
if 'tracking_active' not in st.session_state:
    st.session_state.tracking_active = False

def generate_booking_id():
    """Generate unique booking ID"""
    timestamp = datetime.now().isoformat()
    return hashlib.md5(timestamp.encode()).hexdigest()[:12].upper()

def hash_password(password):
    """Hash password for storage"""
    return hashlib.sha256(password.encode()).hexdigest()

def authenticate_user(email, password, user_type):
    """Authenticate user login"""
    db = next(get_db())
    user = db.query(User).filter_by(
        email=email,
        user_type=user_type
    ).first()
    
    if user and user.password_hash == hash_password(password):
        st.session_state.user = user
        st.session_state.stage = 'service_selection' if user_type == 'customer' else 'provider_dashboard'
        db.close()
        return True
    
    db.close()
    return False

def create_user_account(email, name, phone, password, user_type, services=None, vehicle_type=None, vehicle_info=None):
    """Create new user account"""
    db = next(get_db())
    
    # Check if user already exists
    existing_user = db.query(User).filter_by(email=email).first()
    if existing_user:
        db.close()
        return False
    
    # Create user
    user = User(
        email=email,
        name=name,
        phone=phone,
        user_type=user_type,
        password_hash=hash_password(password)
    )
    db.add(user)
    db.flush()
    
    # If provider, create provider profile
    if user_type == "provider" and services:
        # Get coordinates for service area (default to downtown)
        provider = Provider(
            user_id=user.id,
            services=json.dumps(services),
            vehicle_type=vehicle_type if vehicle_type != "None" else None,
            vehicle_info=vehicle_info,
            rating=5.0,
            total_jobs=0,
            is_available=True,
            current_lat=40.4406 + random.uniform(-0.05, 0.05),
            current_lng=-79.9959 + random.uniform(-0.05, 0.05)
        )
        db.add(provider)
    
    db.commit()
    db.close()
    return True

def login_user(email, name, user_type="customer"):
    """Login or create user (legacy function for backwards compatibility)"""
    db = next(get_db())
    user = db.query(User).filter_by(email=email).first()
    
    if not user:
        user = User(
            email=email, 
            name=name, 
            user_type=user_type,
            password_hash=hash_password("defaultpass")  # Default password for legacy users
        )
        db.add(user)
        db.commit()
        db.refresh(user)
    
    st.session_state.user = user
    st.session_state.stage = 'service_selection' if user_type == 'customer' else 'provider_dashboard'
    db.close()

def find_available_provider(service_type, lat, lng):
    """Find nearest available provider for service"""
    db = next(get_db())
    
    # Get all available providers offering this service
    providers = db.query(Provider).filter(
        Provider.is_available == True,
        Provider.services.contains(service_type)
    ).all()
    
    if not providers:
        db.close()
        return None
    
    # Find nearest provider
    nearest = None
    min_distance = float('inf')
    
    for provider in providers:
        if provider.current_lat and provider.current_lng:
            dist = calculate_distance(lat, lng, provider.current_lat, provider.current_lng)
            if dist < min_distance:
                min_distance = dist
                nearest = provider
    
    db.close()
    return nearest

def create_booking(service_type, pickup_address, pickup_lat, pickup_lng, 
                  dropoff_address=None, dropoff_lat=None, dropoff_lng=None, 
                  service_details=None):
    """Create new booking in database"""
    db = next(get_db())
    
    # Calculate pricing
    if service_type == 'ride_hailing':
        distance = calculate_distance(pickup_lat, pickup_lng, dropoff_lat, dropoff_lng)
        pricing = calculate_ride_fare(distance_miles=distance, time_minutes=int(distance * 3))
    elif service_type == 'deliveries':
        distance = calculate_distance(pickup_lat, pickup_lng, dropoff_lat, dropoff_lng) if dropoff_lat else 3
        pricing = calculate_delivery_cost(distance_miles=distance)
    elif service_type == 'home_services':
        pricing = calculate_home_service_cost("Cleaning", "Medium")
    else:
        pricing = {"customer_price": 50, "provider_payout": 40, "platform_commission": 10}
    
    # Create booking
    booking = Booking(
        booking_id=generate_booking_id(),
        customer_id=st.session_state.user.id,
        service_type=service_type,
        status="pending",
        pickup_address=pickup_address,
        pickup_lat=pickup_lat,
        pickup_lng=pickup_lng,
        dropoff_address=dropoff_address,
        dropoff_lat=dropoff_lat,
        dropoff_lng=dropoff_lng,
        service_details=json.dumps(service_details) if service_details else None,
        estimated_price=pricing["customer_price"],
        provider_payout=pricing["provider_payout"],
        platform_fee=pricing["platform_commission"]
    )
    
    db.add(booking)
    db.commit()
    db.refresh(booking)
    
    # Find and assign provider
    provider = find_available_provider(service_type, pickup_lat, pickup_lng)
    if provider:
        booking.provider_id = provider.user_id
        booking.status = "accepted"
        booking.accepted_at = datetime.utcnow()
        db.commit()
        
        # Add notification
        notification = Notification(
            booking_id=booking.id,
            user_id=st.session_state.user.id,
            message=f"Provider {provider.user.name} accepted your booking",
            notification_type="success"
        )
        db.add(notification)
        db.commit()
    
    db.close()
    return booking

def update_booking_status(booking_id, new_status):
    """Update booking status in database"""
    db = next(get_db())
    booking = db.query(Booking).filter_by(id=booking_id).first()
    
    if booking:
        booking.status = new_status
        if new_status == "en_route":
            booking.started_at = datetime.utcnow()
        elif new_status == "completed":
            booking.completed_at = datetime.utcnow()
            booking.final_price = booking.estimated_price
        
        db.commit()
        
        # Add notification
        messages = {
            "en_route": "Provider is on the way to you",
            "arrived": "Provider has arrived at your location",
            "completed": "Service completed successfully"
        }
        
        if new_status in messages:
            notification = Notification(
                booking_id=booking.id,
                user_id=booking.customer_id,
                message=messages[new_status],
                notification_type="info" if new_status != "completed" else "success"
            )
            db.add(notification)
            db.commit()
    
    db.close()

def get_user_notifications(user_id, limit=10):
    """Get recent notifications for user"""
    db = next(get_db())
    notifications = db.query(Notification).filter_by(
        user_id=user_id
    ).order_by(Notification.created_at.desc()).limit(limit).all()
    db.close()
    return notifications

def show_login():
    """Show login/signup page"""
    st.title("🚗 Welcome to AllServ")
    st.write("Your real-time on-demand service platform")
    
    # Main tabs for Login vs Sign Up
    main_tab1, main_tab2 = st.tabs(["Login", "Sign Up"])
    
    with main_tab1:
        # Login section
        tab1, tab2 = st.tabs(["Customer Login", "Provider Login"])
        
        with tab1:
            st.markdown("### Customer Login")
            email = st.text_input("Email", key="customer_login_email")
            password = st.text_input("Password", type="password", key="customer_login_password")
            
            if st.button("Login as Customer", type="primary", use_container_width=True):
                if email and password:
                    if authenticate_user(email, password, "customer"):
                        st.success("Login successful!")
                        st.rerun()
                    else:
                        st.error("Invalid email or password")
                else:
                    st.error("Please enter email and password")
        
        with tab2:
            st.markdown("### Gig Worker Login")
            email = st.text_input("Email", key="provider_login_email")
            password = st.text_input("Password", type="password", key="provider_login_password")
            
            if st.button("Login as Provider", type="primary", use_container_width=True):
                if email and password:
                    if authenticate_user(email, password, "provider"):
                        st.success("Login successful!")
                        st.rerun()
                    else:
                        st.error("Invalid email or password")
                else:
                    st.error("Please enter email and password")
    
    with main_tab2:
        # Sign up section
        st.markdown("### Create Your Account")
        
        # Choose account type
        account_type = st.radio(
            "I want to:",
            ["Book services (Customer)", "Provide services (Gig Worker)"],
            key="signup_type"
        )
        
        is_provider = "Gig Worker" in account_type
        
        # Sign up form
        col1, col2 = st.columns(2)
        with col1:
            first_name = st.text_input("First Name", key="signup_first_name")
            email = st.text_input("Email", key="signup_email")
            phone = st.text_input("Phone Number", key="signup_phone")
        
        with col2:
            last_name = st.text_input("Last Name", key="signup_last_name")
            password = st.text_input("Password", type="password", key="signup_password")
            confirm_password = st.text_input("Confirm Password", type="password", key="signup_confirm_password")
        
        # Provider-specific fields
        if is_provider:
            st.markdown("### Service Provider Details")
            
            col1, col2 = st.columns(2)
            with col1:
                services = st.multiselect(
                    "Services you provide:",
                    ["ride_hailing", "deliveries", "home_services", "moving_help", "other_tasks"],
                    key="provider_services"
                )
                
                vehicle_type = st.selectbox(
                    "Vehicle Type (if applicable):",
                    ["None", "Standard", "Premium", "XL", "Truck"],
                    key="provider_vehicle_type"
                )
            
            with col2:
                if vehicle_type != "None":
                    vehicle_info = st.text_input(
                        "Vehicle Details (Make, Model, Color, License)",
                        placeholder="e.g., Toyota Camry - Gray - ABC 123",
                        key="provider_vehicle_info"
                    )
                else:
                    vehicle_info = None
                
                # Location for service area
                service_area = st.selectbox(
                    "Primary Service Area:",
                    ["Downtown Pittsburgh", "North Side", "South Side", "East End", "West End"],
                    key="provider_service_area"
                )
        
        # Terms and conditions
        agree_terms = st.checkbox("I agree to the Terms of Service and Privacy Policy")
        
        # Sign up button
        if st.button("Create Account", type="primary", use_container_width=True):
            # Validation
            if not all([first_name, last_name, email, phone, password]):
                st.error("Please fill in all required fields")
            elif password != confirm_password:
                st.error("Passwords do not match")
            elif len(password) < 6:
                st.error("Password must be at least 6 characters long")
            elif not agree_terms:
                st.error("Please agree to the Terms of Service")
            elif is_provider and not services:
                st.error("Please select at least one service you provide")
            else:
                # Create account
                full_name = f"{first_name} {last_name}"
                user_type = "provider" if is_provider else "customer"
                
                if create_user_account(
                    email=email,
                    name=full_name,
                    phone=phone,
                    password=password,
                    user_type=user_type,
                    services=services if is_provider else None,
                    vehicle_type=vehicle_type if is_provider else None,
                    vehicle_info=vehicle_info if is_provider else None
                ):
                    st.success("Account created successfully! Please login.")
                    st.balloons()
                    time.sleep(2)
                    st.rerun()
                else:
                    st.error("An account with this email already exists")

def show_customer_interface():
    """Show customer booking interface"""
    # Header
    col1, col2, col3 = st.columns([2, 1, 1])
    with col1:
        st.title(f"Welcome, {st.session_state.user.name}")
    with col2:
        current_time = datetime.now().strftime("%I:%M:%S %p")
        st.info(f"🕒 {current_time}")
    with col3:
        if st.button("Logout"):
            st.session_state.user = None
            st.session_state.stage = 'login'
            st.rerun()
    
    # Show notifications
    notifications = get_user_notifications(st.session_state.user.id)
    if notifications:
        with st.sidebar:
            st.markdown("### 🔔 Notifications")
            for notif in notifications[:5]:
                time_str = notif.created_at.strftime("%I:%M %p")
                if notif.notification_type == "success":
                    st.success(f"{notif.message} - {time_str}")
                else:
                    st.info(f"{notif.message} - {time_str}")
    
    # Service selection
    if not st.session_state.current_booking:
        st.markdown("### Choose a Service")
        
        col1, col2, col3, col4, col5 = st.columns(5)
        
        with col1:
            if st.button("🚗 Ride-Hailing", use_container_width=True):
                st.session_state.stage = 'booking_details'
                st.session_state.service_type = 'ride_hailing'
                st.rerun()
        
        with col2:
            if st.button("📦 Deliveries", use_container_width=True):
                st.session_state.stage = 'booking_details'
                st.session_state.service_type = 'deliveries'
                st.rerun()
        
        with col3:
            if st.button("🏠 Home Services", use_container_width=True):
                st.session_state.stage = 'booking_details'
                st.session_state.service_type = 'home_services'
                st.rerun()
        
        with col4:
            if st.button("📦 Moving Help", use_container_width=True):
                st.session_state.stage = 'booking_details'
                st.session_state.service_type = 'moving_help'
                st.rerun()
        
        with col5:
            if st.button("🔧 Other Tasks", use_container_width=True):
                st.session_state.stage = 'booking_details'
                st.session_state.service_type = 'other_tasks'
                st.rerun()
        
        # Show recent bookings
        st.markdown("### Recent Bookings")
        db = next(get_db())
        recent_bookings = db.query(Booking).filter_by(
            customer_id=st.session_state.user.id
        ).order_by(Booking.created_at.desc()).limit(5).all()
        
        if recent_bookings:
            for booking in recent_bookings:
                with st.expander(f"{booking.service_type} - {booking.booking_id}"):
                    st.write(f"**Status:** {booking.status}")
                    st.write(f"**Price:** ${booking.estimated_price:.2f}")
                    st.write(f"**Date:** {booking.created_at.strftime('%Y-%m-%d %I:%M %p')}")
                    if booking.provider:
                        st.write(f"**Provider:** {booking.provider.name}")
        else:
            st.info("No recent bookings")
        
        db.close()
    
    # Active booking tracking
    else:
        show_active_booking()

def show_booking_details():
    """Show booking details form"""
    st.markdown(f"### {st.session_state.service_type.replace('_', ' ').title()} Booking")
    
    # Pickup location
    pickup = st.text_input("Pickup Address", "Downtown Pittsburgh")
    pickup_suggestions = get_suggestions(pickup) if pickup else []
    
    if pickup_suggestions:
        selected_pickup = st.selectbox("Suggestions:", [""] + pickup_suggestions)
        if selected_pickup:
            pickup = selected_pickup
    
    # Get coordinates for pickup
    pickup_location = next((loc for loc in PITTSBURGH_LOCATIONS if loc["name"] == pickup), None)
    pickup_lat = pickup_location["lat"] if pickup_location else 40.4406
    pickup_lng = pickup_location["lng"] if pickup_location else -79.9959
    
    # Dropoff for rides/deliveries
    dropoff = None
    dropoff_lat = None
    dropoff_lng = None
    
    if st.session_state.service_type in ['ride_hailing', 'deliveries']:
        dropoff = st.text_input("Dropoff Address", "Pittsburgh Airport")
        dropoff_suggestions = get_suggestions(dropoff) if dropoff else []
        
        if dropoff_suggestions:
            selected_dropoff = st.selectbox("Suggestions:", [""] + dropoff_suggestions, key="dropoff_select")
            if selected_dropoff:
                dropoff = selected_dropoff
        
        dropoff_location = next((loc for loc in PITTSBURGH_LOCATIONS if loc["name"] == dropoff), None)
        dropoff_lat = dropoff_location["lat"] if dropoff_location else 40.4943
        dropoff_lng = dropoff_location["lng"] if dropoff_location else -80.2659
    
    # Calculate and show pricing
    st.markdown("### Estimated Pricing")
    
    if st.session_state.service_type == 'ride_hailing':
        distance = calculate_distance(pickup_lat, pickup_lng, dropoff_lat, dropoff_lng)
        pricing = calculate_ride_fare(distance_miles=distance, time_minutes=int(distance * 3))
    elif st.session_state.service_type == 'deliveries':
        distance = calculate_distance(pickup_lat, pickup_lng, dropoff_lat, dropoff_lng) if dropoff_lat else 3
        pricing = calculate_delivery_cost(distance_miles=distance)
    elif st.session_state.service_type == 'home_services':
        pricing = calculate_home_service_cost("Cleaning", "Medium")
    else:
        pricing = {"customer_price": 50, "provider_payout": 40, "platform_commission": 10}
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Your Price", f"${pricing['customer_price']:.2f}")
    with col2:
        st.metric("Provider Earns", f"${pricing['provider_payout']:.2f}")
    with col3:
        st.metric("Service Fee", f"${pricing['platform_commission']:.2f}")
    
    # Action buttons
    col1, col2 = st.columns(2)
    with col1:
        if st.button("← Back", use_container_width=True):
            st.session_state.stage = 'service_selection'
            st.rerun()
    
    with col2:
        if st.button("Confirm Booking →", type="primary", use_container_width=True):
            # Create booking in database
            booking = create_booking(
                st.session_state.service_type,
                pickup, pickup_lat, pickup_lng,
                dropoff, dropoff_lat, dropoff_lng
            )
            
            st.session_state.current_booking = booking
            st.session_state.stage = 'tracking'
            st.session_state.tracking_active = True
            st.rerun()

def show_active_booking():
    """Show active booking with real-time tracking"""
    booking = st.session_state.current_booking
    
    st.markdown("### 📍 Live Tracking")
    
    # Simulate provider movement
    if st.session_state.tracking_active:
        elapsed = (datetime.now() - booking.created_at).seconds
        
        # Update status based on time
        if elapsed > 5 and booking.status == "accepted":
            update_booking_status(booking.id, "en_route")
            booking.status = "en_route"
        elif elapsed > 20 and booking.status == "en_route":
            update_booking_status(booking.id, "arrived")
            booking.status = "arrived"
        elif elapsed > 30 and booking.status == "arrived":
            update_booking_status(booking.id, "completed")
            booking.status = "completed"
            st.session_state.tracking_active = False
    
    # Display booking info
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Booking ID", booking.booking_id)
    with col2:
        st.metric("Status", booking.status.replace('_', ' ').title())
    with col3:
        st.metric("Price", f"${booking.estimated_price:.2f}")
    with col4:
        if booking.provider:
            db = next(get_db())
            provider = db.query(Provider).filter_by(user_id=booking.provider_id).first()
            st.metric("Provider", booking.provider.name)
            db.close()
    
    # Progress bar
    progress_map = {
        "pending": 10,
        "accepted": 25,
        "en_route": 50,
        "arrived": 75,
        "completed": 100
    }
    progress = progress_map.get(booking.status, 0)
    st.progress(progress / 100, text=f"Status: {booking.status.replace('_', ' ').title()}")
    
    # Provider details if assigned
    if booking.provider:
        st.markdown("### Provider Information")
        db = next(get_db())
        provider = db.query(Provider).filter_by(user_id=booking.provider_id).first()
        
        if provider:
            col1, col2, col3 = st.columns(3)
            with col1:
                st.write(f"**Name:** {booking.provider.name}")
                st.write(f"**Rating:** ⭐ {provider.rating} ({provider.total_jobs} jobs)")
            with col2:
                if provider.vehicle_info:
                    st.write(f"**Vehicle:** {provider.vehicle_info}")
            with col3:
                st.write(f"**Phone:** {booking.provider.phone}")
        
        db.close()
    
    # Action buttons
    if booking.status == "completed":
        if st.button("Book Another Service", use_container_width=True):
            st.session_state.current_booking = None
            st.session_state.stage = 'service_selection'
            st.session_state.tracking_active = False
            st.rerun()
    else:
        if st.button("Cancel Booking", use_container_width=True):
            update_booking_status(booking.id, "cancelled")
            st.session_state.current_booking = None
            st.session_state.stage = 'service_selection'
            st.session_state.tracking_active = False
            st.rerun()
    
    # Auto-refresh for real-time updates
    if st.session_state.tracking_active:
        time.sleep(3)
        st.rerun()

def show_provider_dashboard():
    """Show provider/gig worker dashboard"""
    st.title(f"Provider Dashboard - {st.session_state.user.name}")
    
    # Logout button
    if st.button("Logout", key="provider_logout"):
        st.session_state.user = None
        st.session_state.stage = 'login'
        st.rerun()
    
    # Get provider profile
    db = next(get_db())
    provider = db.query(Provider).filter_by(user_id=st.session_state.user.id).first()
    
    if not provider:
        st.warning("Provider profile not found. Please contact support.")
        db.close()
        return
    
    # Availability toggle
    col1, col2, col3 = st.columns(3)
    with col1:
        is_available = st.toggle("Available for Jobs", value=provider.is_available)
        if is_available != provider.is_available:
            provider.is_available = is_available
            db.commit()
            st.success("Availability updated")
    
    with col2:
        st.metric("Rating", f"⭐ {provider.rating}")
    
    with col3:
        st.metric("Total Jobs", provider.total_jobs)
    
    # Available bookings
    st.markdown("### Available Jobs")
    
    available_bookings = db.query(Booking).filter(
        Booking.status == "pending",
        Booking.service_type.in_(json.loads(provider.services))
    ).order_by(Booking.created_at.desc()).all()
    
    if available_bookings:
        for booking in available_bookings:
            with st.expander(f"{booking.service_type} - ${booking.estimated_price:.2f}"):
                st.write(f"**Pickup:** {booking.pickup_address}")
                if booking.dropoff_address:
                    st.write(f"**Dropoff:** {booking.dropoff_address}")
                st.write(f"**Your Earnings:** ${booking.provider_payout:.2f}")
                
                if st.button(f"Accept Job {booking.booking_id}", use_container_width=True):
                    booking.provider_id = st.session_state.user.id
                    booking.status = "accepted"
                    booking.accepted_at = datetime.utcnow()
                    db.commit()
                    st.success(f"Job {booking.booking_id} accepted!")
                    st.rerun()
    else:
        st.info("No available jobs matching your services")
    
    # Active jobs
    st.markdown("### Your Active Jobs")
    
    active_bookings = db.query(Booking).filter(
        Booking.provider_id == st.session_state.user.id,
        Booking.status.in_(["accepted", "en_route", "arrived"])
    ).all()
    
    if active_bookings:
        for booking in active_bookings:
            with st.expander(f"Active: {booking.booking_id}"):
                st.write(f"**Service:** {booking.service_type}")
                st.write(f"**Status:** {booking.status}")
                st.write(f"**Customer:** {booking.customer.name}")
                st.write(f"**Pickup:** {booking.pickup_address}")
                if booking.dropoff_address:
                    st.write(f"**Dropoff:** {booking.dropoff_address}")
                st.write(f"**Your Earnings:** ${booking.provider_payout:.2f}")
                
                # Status update buttons
                col1, col2, col3 = st.columns(3)
                with col1:
                    if booking.status == "accepted" and st.button(f"Start Job", key=f"start_{booking.id}"):
                        update_booking_status(booking.id, "en_route")
                        st.rerun()
                with col2:
                    if booking.status == "en_route" and st.button(f"Arrived", key=f"arrived_{booking.id}"):
                        update_booking_status(booking.id, "arrived")
                        st.rerun()
                with col3:
                    if booking.status == "arrived" and st.button(f"Complete", key=f"complete_{booking.id}"):
                        update_booking_status(booking.id, "completed")
                        provider.total_jobs += 1
                        db.commit()
                        st.rerun()
    else:
        st.info("No active jobs")
    
    # Earnings summary
    st.markdown("### Today's Earnings")
    
    today = datetime.now().date()
    today_bookings = db.query(Booking).filter(
        Booking.provider_id == st.session_state.user.id,
        Booking.status == "completed",
        Booking.completed_at >= today
    ).all()
    
    total_earnings = sum(b.provider_payout for b in today_bookings if b.provider_payout)
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Jobs Completed", len(today_bookings))
    with col2:
        st.metric("Total Earnings", f"${total_earnings:.2f}")
    with col3:
        avg_earning = total_earnings / len(today_bookings) if today_bookings else 0
        st.metric("Average per Job", f"${avg_earning:.2f}")
    
    db.close()

def main():
    """Main application flow"""
    if st.session_state.stage == 'login':
        show_login()
    elif st.session_state.stage == 'service_selection' and st.session_state.user:
        show_customer_interface()
    elif st.session_state.stage == 'booking_details':
        show_booking_details()
    elif st.session_state.stage == 'payment':
        show_payment_page()
    elif st.session_state.stage == 'tracking':
        show_customer_interface()
    elif st.session_state.stage == 'provider_dashboard':
        show_provider_dashboard()
    else:
        show_login()

def show_payment_page():
    """Display payment page with Stripe integration"""
    if 'booking_details' not in st.session_state:
        st.error("No booking details found. Please start a new booking.")
        if st.button("Start New Booking"):
            st.session_state.stage = 'service_selection'
            st.rerun()
        return
    
    booking = st.session_state.booking_details
    
    st.title("💳 Complete Payment")
    st.write(f"**Booking ID:** {booking.get('booking_id', 'N/A')}")
    
    # Display booking summary
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("### Booking Summary")
        st.write(f"**Service:** {booking.get('service_type', '').replace('_', ' ').title()}")
        st.write(f"**From:** {booking.get('pickup_address', 'N/A')}")
        if booking.get('dropoff_address'):
            st.write(f"**To:** {booking.get('dropoff_address')}")
    
    with col2:
        # Pricing breakdown
        service_type = booking.get('service_type', 'other_tasks')
        total_cost = booking.get('final_price', booking.get('estimated_price', 0))
        
        breakdown = calculate_pricing_breakdown(total_cost, service_type)
        
        st.markdown("### Payment Breakdown")
        st.write(f"**Service Total:** ${total_cost:.2f}")
        st.write(f"**Platform Fee ({breakdown['fee_percentage']:.1f}%):** ${breakdown['platform_fee']/100:.2f}")
        st.write(f"**Provider Earnings:** ${breakdown['provider_earnings']/100:.2f}")
        
        st.markdown("---")
        st.markdown(f"**Your Total:** ${total_cost:.2f}")
    
    st.markdown("---")
    
    # Payment methods
    st.markdown("### Choose Payment Method")
    
    payment_method = st.radio(
        "How would you like to pay?",
        ["Credit Card", "Cash (Pay driver directly)"],
        key="payment_method"
    )
    
    if payment_method == "Credit Card":
        # Stripe payment integration
        processor = PaymentProcessor()
        
        st.markdown("### Card Payment")
        st.info("🔒 Secure payment powered by Stripe")
        
        # Simulate Stripe Elements (in real app, would use Stripe.js)
        with st.form("payment_form"):
            col1, col2 = st.columns(2)
            with col1:
                card_number = st.text_input("Card Number", placeholder="4242 4242 4242 4242")
                expiry_date = st.text_input("MM/YY", placeholder="12/25")
            with col2:
                cvv = st.text_input("CVV", placeholder="123", type="password")
                cardholder_name = st.text_input("Cardholder Name")
            
            billing_zip = st.text_input("Billing ZIP Code")
            
            # Terms acceptance
            agree_terms = st.checkbox("I agree to the payment terms and conditions")
            
            payment_submitted = st.form_submit_button(
                "💳 Pay Now", 
                type="primary",
                use_container_width=True
            )
            
            if payment_submitted:
                if not all([card_number, expiry_date, cvv, cardholder_name, billing_zip]):
                    st.error("Please fill in all payment details")
                elif not agree_terms:
                    st.error("Please agree to the payment terms")
                elif len(card_number.replace(" ", "")) < 15:
                    st.error("Please enter a valid card number")
                else:
                    # Process payment with Stripe
                    with st.spinner("Processing payment..."):
                        payment_intent = processor.create_payment_intent(
                            amount_cents=int(total_cost * 100),
                            customer_email=st.session_state.user.email,
                            provider_email=booking.get('provider_email', ''),
                            booking_id=booking.get('booking_id', ''),
                            service_type=service_type
                        )
                        
                        if payment_intent:
                            # Update booking with payment info
                            update_booking_payment(
                                booking.get('booking_id'),
                                payment_intent['payment_intent_id'],
                                breakdown['provider_earnings'] / 100,
                                breakdown['platform_fee'] / 100,
                                "processing"
                            )
                            
                            st.success("✅ Payment processed successfully!")
                            st.balloons()
                            
                            # Move to confirmation
                            st.session_state.stage = 'tracking'
                            st.session_state.payment_completed = True
                            time.sleep(2)
                            st.rerun()
                        else:
                            st.error("Payment failed. Please try again.")
    
    elif payment_method == "Cash":
        st.markdown("### Cash Payment")
        st.info("💵 You'll pay your driver directly in cash")
        
        if st.button("Confirm Cash Payment", type="primary", use_container_width=True):
            # Update booking for cash payment
            update_booking_payment(
                booking.get('booking_id'),
                None,
                breakdown['provider_earnings'] / 100,
                breakdown['platform_fee'] / 100,
                "cash_pending"
            )
            
            st.success("✅ Cash payment confirmed! Your driver will collect payment.")
            st.session_state.stage = 'tracking'
            st.session_state.payment_completed = True
            time.sleep(2)
            st.rerun()
    
    # Back button
    if st.button("← Back to Booking Details"):
        st.session_state.stage = 'booking_details'
        st.rerun()

def update_booking_payment(booking_id, payment_intent_id, provider_earnings, platform_fee, payment_status):
    """Update booking with payment information"""
    db = next(get_db())
    booking = db.query(Booking).filter_by(booking_id=booking_id).first()
    
    if booking:
        booking.payment_intent_id = payment_intent_id
        booking.provider_payout = provider_earnings
        booking.platform_fee = platform_fee
        booking.payment_status = payment_status
        db.commit()
    
    db.close()

if __name__ == "__main__":
    main()